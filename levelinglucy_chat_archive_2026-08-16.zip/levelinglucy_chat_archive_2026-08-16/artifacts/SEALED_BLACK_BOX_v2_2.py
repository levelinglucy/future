#!/usr/bin/env python3
# SEALED_BLACK_BOX_v2_2.py
# Complete single-file front door: SEALED Core v2.2 + SealedVault + hardened Gatekeeper v2.2.
# Generated locally from the preserved modular originals; no GitHub files were modified.

"""
sealed_core.py — SEALED Core v2.1 (complete reconstructed build)

Provenance
----------
Reconstructed from the public levelinglucy/Sealed-core lineage:
- complete V1 implementation: Sealed-core.py
- hardened but abbreviated V2 snapshot: Sealed core V2

This carries forward the V1 routing/private methods and applies the V2 changes
that are explicit in the public snapshot: 600k PBKDF2, V2 salt,
OWNER/HELPER modes, redaction, lifecycle methods, strict validation,
environment-secret support, filesystem permissions, enhanced fingerprinting,
and atomic persistence.

v2.2 vault extension added during reconstruction
-------------------------------------------
- one encrypted state generation instead of independently-written tickets,
  metrics, and intents files;
- one transaction + one persist per logical mutation;
- same-directory tempfile + fsync + os.replace + directory fsync;
- advisory cross-process store lock;
- HELPER-specific intent redaction;
- normalized/validated timestamps and bounded input sizes;
- deduplicated near/breached SLA warnings;
- intent IDs and state schema/generation metadata;
- best-effort key/state memory clearing;
- built-in self-test.
- SealedVault for arbitrary files, images, folders, and disk-image/back-up files.

No network code is present. Outbound actions are drafts stored as local intents.

Dependency:
    pip install cryptography

Environment (recommended):
    export SEALED_OWNER_SECRET='a long local passphrase'
    export SEALED_HOST_ID='optional-stable-host-id-for-VMs'

Run integrity/lifecycle tests:
    python sealed_core.py --self-test

This build can black-box arbitrary files directly, and can black-box folders by
sealing them as encrypted tar.gz bundles. For a whole live computer, use OS
full-disk encryption; SEALED is better treated as an additional application-layer
black box, or used to encrypt machine backups / disk image files.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import hmac
import json
import os
import platform
import re
import secrets
import tempfile
import tarfile
import uuid
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM


STATE_SCHEMA = "SEALED_STATE_V2_2"
ENVELOPE_SCHEMA = "SEALED_ENVELOPE_V2_2"
VAULT_OBJECT_SCHEMA = "SEALED_VAULT_OBJECT_V1"
PBKDF2_ITERATIONS = 600_000
DEFAULT_STORAGE_DIR = "sealed_storage"

MAX_SUBJECT_CHARS = 500
MAX_BODY_CHARS = 100_000
MAX_EMAIL_CHARS = 320
MAX_SOURCE_CHARS = 80
MAX_TIMESTAMP_CHARS = 80
MAX_METRICS = 50_000
MAX_INTENTS = 50_000
MAX_VAULT_ITEMS = 50_000
DEFAULT_VAULT_CHUNK_SIZE = 1024 * 1024


def _safe_chmod(path: os.PathLike | str, mode: int) -> None:
    try:
        os.chmod(path, mode)
    except (OSError, AttributeError):
        pass


def _get_machine_fingerprint() -> str:
    parts: List[str] = []

    host = platform.node().strip()
    if host:
        parts.append("host=" + host)

    try:
        parts.append("uuidnode=" + format(uuid.getnode(), "012x"))
    except Exception:
        pass

    net_root = Path("/sys/class/net")
    if net_root.is_dir():
        macs: List[str] = []
        try:
            for iface in sorted(net_root.iterdir(), key=lambda p: p.name):
                try:
                    value = (iface / "address").read_text(encoding="utf-8").strip().lower()
                    if value:
                        macs.append(value)
                except OSError:
                    continue
        except OSError:
            pass
        if macs:
            parts.append("macs=" + ",".join(macs))

    host_id = os.environ.get("SEALED_HOST_ID", "").strip()
    if host_id:
        parts.append("host_id=" + host_id)

    if not parts:
        raise RuntimeError("Unable to derive a stable machine fingerprint")

    return hashlib.sha256("|".join(parts).encode("utf-8")).hexdigest()


def _derive_master_key(owner_passphrase: str, machine_fp: str) -> bytearray:
    if not isinstance(owner_passphrase, str) or not owner_passphrase:
        raise ValueError("owner passphrase is required")
    if len(owner_passphrase) < 12:
        raise ValueError("owner passphrase must be at least 12 characters")

    salt = ("SEALED_CORE_STATIC_SALT_v2__" + machine_fp).encode("utf-8")
    key = hashlib.pbkdf2_hmac(
        "sha256",
        owner_passphrase.encode("utf-8"),
        salt,
        PBKDF2_ITERATIONS,
        dklen=32,
    )
    return bytearray(key)


def _derive_subkey(parent_key: bytearray | bytes, label: str) -> bytes:
    """Deterministic local subkey derivation from the SEALED master key."""
    if not isinstance(label, str) or not label:
        raise ValueError("subkey label required")
    return hmac.new(bytes(parent_key), label.encode("utf-8"), hashlib.sha256).digest()


def _canonical_json_bytes(data: Any) -> bytes:
    return json.dumps(
        data,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    ).encode("utf-8")


def _encrypt_blob(key: bytearray | bytes, data: Any) -> dict:
    aesgcm = AESGCM(bytes(key))
    nonce = os.urandom(12)
    ciphertext = aesgcm.encrypt(nonce, _canonical_json_bytes(data), None)
    return {"nonce_hex": nonce.hex(), "cipher_hex": ciphertext.hex()}


def _decrypt_blob(key: bytearray | bytes, enc: dict) -> Any:
    if not isinstance(enc, dict):
        raise ValueError("encrypted envelope must be an object")

    nonce_hex = enc.get("nonce_hex", enc.get("nonce_b64"))
    cipher_hex = enc.get("cipher_hex", enc.get("cipher_b64"))
    if not isinstance(nonce_hex, str) or not isinstance(cipher_hex, str):
        raise ValueError("encrypted envelope missing nonce/ciphertext")

    aesgcm = AESGCM(bytes(key))
    plaintext = aesgcm.decrypt(bytes.fromhex(nonce_hex), bytes.fromhex(cipher_hex), None)
    return json.loads(plaintext.decode("utf-8"))


def _hmac_sign(key: bytearray | bytes, data: Any) -> str:
    return hmac.new(bytes(key), _canonical_json_bytes(data), hashlib.sha256).hexdigest()


def _hmac_verify(key: bytearray | bytes, data: Any, signature: str) -> bool:
    return isinstance(signature, str) and hmac.compare_digest(_hmac_sign(key, data), signature)


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _format_utc(dt: datetime) -> str:
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _parse_timestamp(value: str) -> datetime:
    text = value.strip()
    if not text:
        return _utc_now()
    if len(text) > MAX_TIMESTAMP_CHARS:
        raise ValueError("timestamp too long")
    try:
        dt = datetime.fromisoformat(text[:-1] + "+00:00") if text.endswith("Z") else datetime.fromisoformat(text)
    except ValueError as exc:
        raise ValueError("timestamp must be ISO-8601") from exc
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


class _StoreFileLock:
    """Advisory lock for cooperating SEALED processes."""

    def __init__(self, path: Path):
        self.path = path
        self.handle = None
        self._backend = None

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.handle = open(self.path, "a+b")
        _safe_chmod(self.path, 0o600)

        try:
            import fcntl  # type: ignore
            fcntl.flock(self.handle.fileno(), fcntl.LOCK_EX)
            self._backend = "fcntl"
        except ImportError:
            try:
                import msvcrt  # type: ignore
                self.handle.seek(0)
                if self.handle.read(1) == b"":
                    self.handle.write(b"0")
                    self.handle.flush()
                self.handle.seek(0)
                msvcrt.locking(self.handle.fileno(), msvcrt.LK_LOCK, 1)
                self._backend = "msvcrt"
            except ImportError as exc:
                self.handle.close()
                self.handle = None
                raise RuntimeError("No supported local file-lock backend") from exc
        return self

    def __exit__(self, exc_type, exc, tb):
        if self.handle is None:
            return False
        try:
            if self._backend == "fcntl":
                import fcntl  # type: ignore
                fcntl.flock(self.handle.fileno(), fcntl.LOCK_UN)
            elif self._backend == "msvcrt":
                import msvcrt  # type: ignore
                self.handle.seek(0)
                msvcrt.locking(self.handle.fileno(), msvcrt.LK_UNLCK, 1)
        finally:
            self.handle.close()
            self.handle = None
        return False


def _fsync_directory(path: Path) -> None:
    if os.name == "nt":
        return
    try:
        fd = os.open(str(path), os.O_RDONLY)
    except OSError:
        return
    try:
        os.fsync(fd)
    except OSError:
        pass
    finally:
        os.close(fd)


def _atomic_json_write(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    _safe_chmod(path.parent, 0o700)
    fd, temp_name = tempfile.mkstemp(prefix="." + path.name + ".", suffix=".tmp", dir=str(path.parent))
    temp_path = Path(temp_name)
    try:
        _safe_chmod(temp_path, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, separators=(",", ":"), ensure_ascii=False)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_path, path)
        _safe_chmod(path, 0o600)
        _fsync_directory(path.parent)
    except Exception:
        try:
            temp_path.unlink()
        except OSError:
            pass
        raise


class SealedStore:
    """One encrypted logical state generation, with cross-process serialization."""

    def __init__(self, master_key: bytearray, storage_dir: str = DEFAULT_STORAGE_DIR):
        self.key = master_key
        self.dir = Path(storage_dir).expanduser().resolve()
        self.dir.mkdir(parents=True, exist_ok=True)
        _safe_chmod(self.dir, 0o700)
        self.state_path = self.dir / "state.json"
        self.lock_path = self.dir / ".sealed.lock"
        self._state: Dict[str, Any] = self._new_state()
        self._transaction_depth = 0

        with _StoreFileLock(self.lock_path):
            self._state = self._load_state_locked()

    def _new_state(self) -> Dict[str, Any]:
        now = _format_utc(_utc_now())
        return {
            "schema": STATE_SCHEMA,
            "generation": 0,
            "created_at": now,
            "updated_at": now,
            "tickets": {},
            "metrics": [],
            "intents": [],
            "vault_items": {},
        }

    def _validate_state(self, state: Any) -> Dict[str, Any]:
        if not isinstance(state, dict):
            raise ValueError("sealed state root must be an object")
        schema = state.get("schema")
        if schema not in (STATE_SCHEMA, "SEALED_STATE_V2_1", None):
            raise ValueError(f"unsupported sealed state schema: {schema!r}")

        tickets = state.get("tickets", {})
        metrics = state.get("metrics", [])
        intents = state.get("intents", [])
        vault_items = state.get("vault_items", {})
        if not isinstance(tickets, dict):
            raise ValueError("state.tickets must be an object")
        if not isinstance(metrics, list):
            raise ValueError("state.metrics must be a list")
        if not isinstance(intents, list):
            raise ValueError("state.intents must be a list")
        if not isinstance(vault_items, dict):
            raise ValueError("state.vault_items must be an object")

        normalized = dict(state)
        normalized["schema"] = STATE_SCHEMA
        normalized.setdefault("generation", 0)
        normalized.setdefault("created_at", _format_utc(_utc_now()))
        normalized.setdefault("updated_at", normalized["created_at"])
        normalized["tickets"] = tickets
        normalized["metrics"] = metrics[-MAX_METRICS:]
        normalized["intents"] = intents[-MAX_INTENTS:]
        normalized["vault_items"] = vault_items
        return normalized

    def _decode_envelope(self, raw: Any) -> Any:
        if not isinstance(raw, dict) or "enc" not in raw or "sig" not in raw:
            raise ValueError("tampered or invalid sealed envelope")
        decrypted = _decrypt_blob(self.key, raw["enc"])
        if not _hmac_verify(self.key, decrypted, raw["sig"]):
            raise ValueError("integrity check failed: data may be tampered")
        return decrypted

    def _read_encrypted_file(self, path: Path) -> Any:
        with path.open("r", encoding="utf-8") as handle:
            return self._decode_envelope(json.load(handle))

    def _load_legacy_v2_files_locked(self) -> Optional[Dict[str, Any]]:
        mapping = {
            "tickets": ("tickets.json", {}),
            "metrics": ("metrics.json", []),
            "intents": ("intents.json", []),
        }
        if not any((self.dir / fname).exists() for fname, _ in mapping.values()):
            return None

        state = self._new_state()
        for key, (fname, default) in mapping.items():
            file_path = self.dir / fname
            state[key] = self._read_encrypted_file(file_path) if file_path.exists() else copy.deepcopy(default)
        state["migrated_from"] = "public-v2-three-file-layout"
        return self._validate_state(state)

    def _load_state_locked(self) -> Dict[str, Any]:
        if self.state_path.exists():
            return self._validate_state(self._read_encrypted_file(self.state_path))
        legacy = self._load_legacy_v2_files_locked()
        return legacy if legacy is not None else self._new_state()

    def _persist_state_locked(self) -> None:
        self._state["schema"] = STATE_SCHEMA
        self._state["generation"] = int(self._state.get("generation", 0)) + 1
        self._state["updated_at"] = _format_utc(_utc_now())
        self._state["metrics"] = self._state.get("metrics", [])[-MAX_METRICS:]
        self._state["intents"] = self._state.get("intents", [])[-MAX_INTENTS:]
        envelope = {
            "schema": ENVELOPE_SCHEMA,
            "enc": _encrypt_blob(self.key, self._state),
            "sig": _hmac_sign(self.key, self._state),
        }
        _atomic_json_write(self.state_path, envelope)

    @contextmanager
    def transaction(self) -> Iterator["SealedStore"]:
        if self._transaction_depth > 0:
            self._transaction_depth += 1
            try:
                yield self
            finally:
                self._transaction_depth -= 1
            return

        with _StoreFileLock(self.lock_path):
            self._state = self._load_state_locked()
            before = copy.deepcopy(self._state)
            self._transaction_depth = 1
            try:
                yield self
                self._persist_state_locked()
            except Exception:
                self._state = before
                raise
            finally:
                self._transaction_depth = 0

    def _refresh_for_read(self) -> None:
        if self._transaction_depth > 0:
            return
        with _StoreFileLock(self.lock_path):
            self._state = self._load_state_locked()

    def _auto_mutation(self, callback) -> None:
        if self._transaction_depth > 0:
            callback()
        else:
            with self.transaction():
                callback()

    @property
    def generation(self) -> int:
        self._refresh_for_read()
        return int(self._state.get("generation", 0))

    def list_open_tickets(self) -> List[dict]:
        self._refresh_for_read()
        return [
            copy.deepcopy(ticket)
            for ticket in self._state["tickets"].values()
            if ticket.get("status") in ("OPEN", "ACKNOWLEDGED")
        ]

    def get_ticket(self, ticket_id: str) -> Optional[dict]:
        self._refresh_for_read()
        ticket = self._state["tickets"].get(ticket_id)
        return copy.deepcopy(ticket) if ticket is not None else None

    def put_ticket(self, ticket: dict) -> None:
        ticket_id = ticket.get("ticket_id")
        if not isinstance(ticket_id, str) or not ticket_id:
            raise ValueError("ticket_id required")

        def mutate():
            self._state["tickets"][ticket_id] = copy.deepcopy(ticket)
        self._auto_mutation(mutate)

    def append_metric(self, metric: dict) -> None:
        def mutate():
            self._state["metrics"].append(copy.deepcopy(metric))
        self._auto_mutation(mutate)

    def append_intent(self, intent: dict) -> None:
        def mutate():
            self._state["intents"].append(copy.deepcopy(intent))
        self._auto_mutation(mutate)

    def list_intents(self) -> List[dict]:
        self._refresh_for_read()
        return copy.deepcopy(self._state["intents"])

    def metrics_count(self) -> int:
        self._refresh_for_read()
        return len(self._state["metrics"])

    def list_vault_items(self) -> List[dict]:
        self._refresh_for_read()
        return [copy.deepcopy(item) for item in self._state["vault_items"].values()]

    def get_vault_item(self, object_id: str) -> Optional[dict]:
        self._refresh_for_read()
        item = self._state["vault_items"].get(object_id)
        return copy.deepcopy(item) if item is not None else None

    def put_vault_item(self, item: dict) -> None:
        object_id = item.get("object_id")
        if not isinstance(object_id, str) or not object_id:
            raise ValueError("object_id required")

        def mutate():
            vault_items = self._state["vault_items"]
            if object_id not in vault_items and len(vault_items) >= MAX_VAULT_ITEMS:
                raise ValueError("vault item limit reached")
            vault_items[object_id] = copy.deepcopy(item)
        self._auto_mutation(mutate)

    def delete_vault_item(self, object_id: str) -> bool:
        def mutate() -> bool:
            vault_items = self._state["vault_items"]
            if object_id in vault_items:
                del vault_items[object_id]
                return True
            return False
        if self._transaction_depth > 0:
            return mutate()
        with self.transaction():
            return mutate()

    def close(self) -> None:
        try:
            self._state.clear()
        finally:
            for i in range(len(self.key)):
                self.key[i] = 0


class SealedVault:
    """Chunked authenticated encryption for arbitrary files and directory bundles."""

    MAGIC = b"SEALEDVAULT22\x00"

    def __init__(self, store: SealedStore, master_key: bytearray | bytes, storage_dir: str = DEFAULT_STORAGE_DIR):
        self.store = store
        self.vault_key = bytearray(_derive_subkey(master_key, "SEALED_VAULT_V1"))
        self.root = Path(storage_dir).expanduser().resolve() / "vault"
        self.objects_dir = self.root / "objects"
        self.tmp_dir = self.root / "tmp"
        self.root.mkdir(parents=True, exist_ok=True)
        self.objects_dir.mkdir(parents=True, exist_ok=True)
        self.tmp_dir.mkdir(parents=True, exist_ok=True)
        _safe_chmod(self.root, 0o700)
        _safe_chmod(self.objects_dir, 0o700)
        _safe_chmod(self.tmp_dir, 0o700)

    @staticmethod
    def _object_id() -> str:
        return "OBJ-" + uuid.uuid4().hex.upper()

    @staticmethod
    def _sanitize_label(label: Optional[str]) -> Optional[str]:
        if label is None:
            return None
        if not isinstance(label, str):
            raise ValueError("label must be a string")
        label = label.strip()
        if len(label) > 500:
            raise ValueError("label exceeds 500 characters")
        return label or None

    @staticmethod
    def _validate_metadata(metadata: Optional[dict]) -> dict:
        if metadata is None:
            return {}
        if not isinstance(metadata, dict):
            raise ValueError("metadata must be an object")
        return copy.deepcopy(metadata)

    @staticmethod
    def _safe_extract_tar(archive_path: Path, destination_root: Path) -> None:
        destination_root = destination_root.resolve()
        destination_root.mkdir(parents=True, exist_ok=True)
        with tarfile.open(archive_path, "r:*") as tf:
            for member in tf.getmembers():
                if member.issym() or member.islnk():
                    raise ValueError("symlinks are not allowed in sealed directory bundles")
                target = (destination_root / member.name).resolve()
                if os.path.commonpath([str(destination_root), str(target)]) != str(destination_root):
                    raise ValueError("tar member escapes destination root")
            extract_kwargs = {}
            if "filter" in tarfile.TarFile.extractall.__code__.co_varnames:
                extract_kwargs["filter"] = "data"
            tf.extractall(destination_root, **extract_kwargs)

    def list_items(self) -> List[dict]:
        items = self.store.list_vault_items()
        return sorted(items, key=lambda item: (item.get("created_at", ""), item.get("object_id", "")))

    def get_item(self, object_id: str) -> Optional[dict]:
        return self.store.get_vault_item(object_id)

    def seal_path(self, input_path: str | os.PathLike, label: Optional[str] = None, metadata: Optional[dict] = None) -> dict:
        path = Path(input_path).expanduser().resolve()
        if path.is_dir():
            return self.seal_directory(path, label=label, metadata=metadata)
        return self.seal_file(path, label=label, metadata=metadata)

    def seal_file(
        self,
        input_path: str | os.PathLike,
        *,
        label: Optional[str] = None,
        metadata: Optional[dict] = None,
        kind: str = "file",
        source_name_override: Optional[str] = None,
        source_path_hint_override: Optional[str] = None,
        chunk_size: int = DEFAULT_VAULT_CHUNK_SIZE,
    ) -> dict:
        source = Path(input_path).expanduser().resolve()
        if not source.is_file():
            raise ValueError("seal_file requires a regular file")
        if chunk_size <= 0:
            raise ValueError("chunk_size must be positive")

        stat = source.stat()
        object_id = self._object_id()
        source_name = source_name_override or source.name
        record = {
            "object_id": object_id,
            "schema": VAULT_OBJECT_SCHEMA,
            "kind": kind,
            "label": self._sanitize_label(label),
            "source_name": source_name,
            "source_path_hint": source_path_hint_override or str(source),
            "created_at": _format_utc(_utc_now()),
            "size_bytes": int(stat.st_size),
            "chunk_size": int(chunk_size),
            "chunk_count": int((stat.st_size + chunk_size - 1) // chunk_size) if stat.st_size else 0,
            "sha256": None,
            "metadata": self._validate_metadata(metadata),
            "container_filename": f"{object_id}.svlt",
        }

        destination = self.objects_dir / record["container_filename"]
        fd, tmp_name = tempfile.mkstemp(prefix=f".{object_id}.", suffix=".tmp", dir=str(self.tmp_dir))
        tmp_path = Path(tmp_name)
        digest = hashlib.sha256()

        try:
            _safe_chmod(tmp_path, 0o600)
            with open(source, "rb") as src, os.fdopen(fd, "wb") as out:
                header = dict(record)
                header["source_path_hint"] = None
                enc_header = _encrypt_blob(self.vault_key, header)
                header_bytes = json.dumps(enc_header, separators=(",", ":")).encode("utf-8")
                out.write(self.MAGIC)
                out.write(len(header_bytes).to_bytes(8, "big"))
                out.write(header_bytes)

                aesgcm = AESGCM(bytes(self.vault_key))
                seq = 0
                while True:
                    chunk = src.read(chunk_size)
                    if not chunk:
                        break
                    digest.update(chunk)
                    nonce = os.urandom(12)
                    aad = f"{object_id}:{seq}".encode("utf-8")
                    cipher = aesgcm.encrypt(nonce, chunk, aad)
                    out.write(len(cipher).to_bytes(8, "big"))
                    out.write(nonce)
                    out.write(cipher)
                    seq += 1

                out.flush()
                os.fsync(out.fileno())

            record["sha256"] = digest.hexdigest()
            os.replace(tmp_path, destination)
            _safe_chmod(destination, 0o600)
            _fsync_directory(destination.parent)
            self._refresh_record_header(destination, record)

            try:
                with self.store.transaction():
                    self.store.put_vault_item(record)
                    self.store.append_metric({
                        "metric_type": "VAULT_ITEM_SEALED",
                        "ts": _format_utc(_utc_now()),
                        "object_id": object_id,
                        "kind": kind,
                        "size_bytes": record["size_bytes"],
                    })
            except Exception:
                try:
                    destination.unlink()
                except OSError:
                    pass
                raise

            return copy.deepcopy(record)
        except Exception:
            try:
                tmp_path.unlink()
            except OSError:
                pass
            raise

    def _refresh_record_header(self, container_path: Path, record: dict) -> None:
        # Re-write only the encrypted metadata header so the stored SHA-256 is exact.
        fd, tmp_name = tempfile.mkstemp(prefix=f".{record['object_id']}.rehdr.", suffix=".tmp", dir=str(self.tmp_dir))
        tmp_path = Path(tmp_name)
        try:
            _safe_chmod(tmp_path, 0o600)
            with open(container_path, "rb") as src, os.fdopen(fd, "wb") as out:
                magic = src.read(len(self.MAGIC))
                if magic != self.MAGIC:
                    raise ValueError("invalid vault container magic")
                header_len = int.from_bytes(src.read(8), "big")
                _ = src.read(header_len)
                header = dict(record)
                header["source_path_hint"] = None
                enc_header = _encrypt_blob(self.vault_key, header)
                header_bytes = json.dumps(enc_header, separators=(",", ":")).encode("utf-8")
                out.write(self.MAGIC)
                out.write(len(header_bytes).to_bytes(8, "big"))
                out.write(header_bytes)
                while True:
                    block = src.read(1024 * 1024)
                    if not block:
                        break
                    out.write(block)
                out.flush()
                os.fsync(out.fileno())
            os.replace(tmp_path, container_path)
            _safe_chmod(container_path, 0o600)
            _fsync_directory(container_path.parent)
        except Exception:
            try:
                tmp_path.unlink()
            except OSError:
                pass
            raise

    def _load_container_header(self, container_path: Path) -> dict:
        with open(container_path, "rb") as handle:
            magic = handle.read(len(self.MAGIC))
            if magic != self.MAGIC:
                raise ValueError("invalid vault container magic")
            header_len_raw = handle.read(8)
            if len(header_len_raw) != 8:
                raise ValueError("truncated vault header length")
            header_len = int.from_bytes(header_len_raw, "big")
            if header_len <= 0 or header_len > 10_000_000:
                raise ValueError("invalid vault header length")
            header_bytes = handle.read(header_len)
            if len(header_bytes) != header_len:
                raise ValueError("truncated vault header")
        header_env = json.loads(header_bytes.decode("utf-8"))
        header = _decrypt_blob(self.vault_key, header_env)
        if not isinstance(header, dict):
            raise ValueError("vault header must decrypt to an object")
        return header

    def _resolve_file_output(self, record: dict, output_path: Optional[str | os.PathLike]) -> Path:
        if output_path is None:
            return Path.cwd() / record["source_name"]
        path = Path(output_path).expanduser()
        if path.exists() and path.is_dir():
            return path / record["source_name"]
        if str(output_path).endswith(os.sep):
            return path / record["source_name"]
        return path

    def unseal_file(self, object_id: str, output_path: Optional[str | os.PathLike] = None, overwrite: bool = False) -> Path:
        record = self.store.get_vault_item(object_id)
        if record is None:
            raise ValueError("unknown vault object_id")
        container_path = self.objects_dir / record["container_filename"]
        if not container_path.is_file():
            raise FileNotFoundError("sealed container file missing")

        header = self._load_container_header(container_path)
        if header.get("object_id") != record.get("object_id"):
            raise ValueError("vault header/object index mismatch")

        destination = self._resolve_file_output(record, output_path).expanduser().resolve()
        if destination.exists() and not overwrite:
            raise FileExistsError(f"destination exists: {destination}")
        destination.parent.mkdir(parents=True, exist_ok=True)

        fd, tmp_name = tempfile.mkstemp(prefix=".unseal.", suffix=".tmp", dir=str(destination.parent))
        tmp_path = Path(tmp_name)
        digest = hashlib.sha256()
        total = 0
        try:
            _safe_chmod(tmp_path, 0o600)
            aesgcm = AESGCM(bytes(self.vault_key))
            with open(container_path, "rb") as src, os.fdopen(fd, "wb") as out:
                src.seek(len(self.MAGIC))
                header_len = int.from_bytes(src.read(8), "big")
                src.seek(header_len, os.SEEK_CUR)

                for seq in range(int(header.get("chunk_count", 0))):
                    cipher_len_raw = src.read(8)
                    if len(cipher_len_raw) != 8:
                        raise ValueError("truncated vault chunk length")
                    cipher_len = int.from_bytes(cipher_len_raw, "big")
                    nonce = src.read(12)
                    if len(nonce) != 12:
                        raise ValueError("truncated vault chunk nonce")
                    cipher = src.read(cipher_len)
                    if len(cipher) != cipher_len:
                        raise ValueError("truncated vault chunk ciphertext")
                    aad = f"{record['object_id']}:{seq}".encode("utf-8")
                    chunk = aesgcm.decrypt(nonce, cipher, aad)
                    digest.update(chunk)
                    out.write(chunk)
                    total += len(chunk)

                out.flush()
                os.fsync(out.fileno())

                extra = src.read(1)
                if extra not in (b"",):
                    raise ValueError("unexpected trailing bytes in vault container")

            if total != int(record.get("size_bytes", -1)):
                raise ValueError("restored size does not match vault metadata")
            if digest.hexdigest() != record.get("sha256"):
                raise ValueError("restored sha256 does not match vault metadata")

            os.replace(tmp_path, destination)
            _safe_chmod(destination, 0o600)
            _fsync_directory(destination.parent)

            with self.store.transaction():
                self.store.append_metric({
                    "metric_type": "VAULT_ITEM_UNSEALED",
                    "ts": _format_utc(_utc_now()),
                    "object_id": record["object_id"],
                })
            return destination
        except Exception:
            try:
                tmp_path.unlink()
            except OSError:
                pass
            raise

    def seal_directory(self, input_dir: str | os.PathLike, *, label: Optional[str] = None, metadata: Optional[dict] = None) -> dict:
        source_dir = Path(input_dir).expanduser().resolve()
        if not source_dir.is_dir():
            raise ValueError("seal_directory requires a directory")

        fd, temp_name = tempfile.mkstemp(prefix=".bundle.", suffix=".tar.gz", dir=str(self.tmp_dir))
        os.close(fd)
        temp_tar = Path(temp_name)
        try:
            with tarfile.open(temp_tar, "w:gz") as tf:
                tf.add(source_dir, arcname=source_dir.name)
            meta = self._validate_metadata(metadata)
            meta.setdefault("original_directory_name", source_dir.name)
            meta.setdefault("bundle_format", "tar.gz")
            return self.seal_file(
                temp_tar,
                label=label,
                metadata=meta,
                kind="directory_bundle",
                source_name_override=f"{source_dir.name}.tar.gz",
                source_path_hint_override=str(source_dir),
            )
        finally:
            try:
                temp_tar.unlink()
            except OSError:
                pass

    def restore_directory(self, object_id: str, output_dir: str | os.PathLike, overwrite: bool = False) -> Path:
        record = self.store.get_vault_item(object_id)
        if record is None:
            raise ValueError("unknown vault object_id")
        if record.get("kind") != "directory_bundle":
            raise ValueError("vault object is not a directory bundle")

        output_root = Path(output_dir).expanduser().resolve()
        output_root.mkdir(parents=True, exist_ok=True)

        temp_archive = self.tmp_dir / f"{object_id}.restore.tar.gz"
        try:
            self.unseal_file(object_id, temp_archive, overwrite=True)
            root_name = record.get("metadata", {}).get("original_directory_name") or record["source_name"].removesuffix(".tar.gz")
            candidate_root = output_root / root_name
            if candidate_root.exists() and not overwrite:
                raise FileExistsError(f"restore destination exists: {candidate_root}")
            self._safe_extract_tar(temp_archive, output_root)
            with self.store.transaction():
                self.store.append_metric({
                    "metric_type": "VAULT_DIR_RESTORED",
                    "ts": _format_utc(_utc_now()),
                    "object_id": object_id,
                })
            return candidate_root
        finally:
            try:
                temp_archive.unlink()
            except OSError:
                pass

    def close(self) -> None:
        for i in range(len(self.vault_key)):
            self.vault_key[i] = 0


class SealedCore:
    ROUTES = {
        "INCIDENT": {
            "match_keywords": [
                "down", "outage", "cannot login", "critical", "prod",
                "production", "urgent", "asap", "blocker",
            ],
            "owner_email": "oncall@local.system",
            "target_first_response_minutes": 5,
            "human_label": "Prod Emergency",
            "escalate_dm": "oncall@local.system",
        },
        "SUPPORT": {
            "match_keywords": [
                "help", "support", "bug", "issue", "question",
                "not working", "confused",
            ],
            "owner_email": "support@local.system",
            "target_first_response_minutes": 60,
            "human_label": "Support Request",
            "escalate_dm": None,
        },
        "BILLING": {
            "match_keywords": [
                "invoice", "refund", "charge", "charged", "billing",
                "payment failed", "receipt",
            ],
            "owner_email": "finance@local.system",
            "target_first_response_minutes": 120,
            "human_label": "Billing / Money",
            "escalate_dm": "finance@local.system",
        },
    }

    def __init__(
        self,
        owner_passphrase: Optional[str] = None,
        mode: str = "OWNER",
        storage_dir: str = DEFAULT_STORAGE_DIR,
    ):
        if owner_passphrase is None:
            owner_passphrase = os.environ.get("SEALED_OWNER_SECRET")
        if not owner_passphrase:
            raise RuntimeError(
                "owner passphrase required; pass owner_passphrase=... or set SEALED_OWNER_SECRET"
            )

        self.mode = str(mode).upper()
        if self.mode not in ("OWNER", "HELPER"):
            raise ValueError("mode must be OWNER or HELPER")

        machine_fp = _get_machine_fingerprint()
        self.master_key = _derive_master_key(owner_passphrase, machine_fp)
        self.store = SealedStore(self.master_key, storage_dir=storage_dir)
        self.vault = SealedVault(self.store, self.master_key, storage_dir=storage_dir)
        self.routes = copy.deepcopy(self.ROUTES)
        self.default_route = "SUPPORT"
        self.sla_warning_minutes_before_deadline = 5

    def handle(self, raw_event: dict) -> dict:
        normalized = self._normalize(raw_event)
        route_name = self._classify(normalized)
        ticket = self._create_ticket_obj(normalized, route_name)

        with self.store.transaction():
            self.store.put_ticket(ticket)
            self.store.append_metric({
                "metric_type": "TICKET_CREATED",
                "ts": self._now_iso(),
                "ticket_id": ticket["ticket_id"],
                "route": ticket["route"],
                "urgency": ticket["urgency"],
            })
            self._queue_local_alert_intent(ticket)
            self._queue_autoreply_intent(ticket)

        return {
            "ticket_id": ticket["ticket_id"],
            "route": ticket["route"],
            "owner": ticket["owner_email"],
            "sla_deadline": ticket["sla_deadline_iso"],
            "status": ticket["status"],
        }

    def acknowledge_ticket(self, ticket_id: str) -> bool:
        ticket_id = self._validate_ticket_id(ticket_id)
        with self.store.transaction():
            ticket = self.store.get_ticket(ticket_id)
            if not ticket or ticket.get("status") == "CLOSED":
                return False
            ticket["status"] = "ACKNOWLEDGED"
            ticket["last_human_touch_iso"] = self._now_iso()
            self.store.put_ticket(ticket)
            self.store.append_metric({
                "metric_type": "TICKET_ACKNOWLEDGED",
                "ts": self._now_iso(),
                "ticket_id": ticket_id,
            })
        return True

    def close_ticket(self, ticket_id: str) -> bool:
        ticket_id = self._validate_ticket_id(ticket_id)
        with self.store.transaction():
            ticket = self.store.get_ticket(ticket_id)
            if not ticket:
                return False
            if ticket.get("status") == "CLOSED":
                return True
            ticket["status"] = "CLOSED"
            ticket["last_human_touch_iso"] = self._now_iso()
            self.store.put_ticket(ticket)
            self.store.append_metric({
                "metric_type": "TICKET_CLOSED",
                "ts": self._now_iso(),
                "ticket_id": ticket_id,
            })
        return True

    def get_ticket_detail(self, ticket_id: str) -> Optional[dict]:
        ticket_id = self._validate_ticket_id(ticket_id)
        ticket = self.store.get_ticket(ticket_id)
        return self._redact_ticket(ticket) if ticket else None

    def list_open_summary(self) -> List[dict]:
        return [self._redact_ticket(ticket) for ticket in self.store.list_open_tickets()]

    def debug_snapshot(self) -> dict:
        return self.diagnostic_dump()

    def list_vault_summary(self) -> List[dict]:
        return [self._redact_vault_item(item) for item in self.vault.list_items()]

    def get_vault_item(self, object_id: str) -> Optional[dict]:
        item = self.vault.get_item(object_id)
        return self._redact_vault_item(item) if item else None

    def seal_file(self, input_path: str | os.PathLike, label: Optional[str] = None, metadata: Optional[dict] = None) -> dict:
        return self._redact_vault_item(self.vault.seal_file(input_path, label=label, metadata=metadata))

    def seal_directory(self, input_dir: str | os.PathLike, label: Optional[str] = None, metadata: Optional[dict] = None) -> dict:
        return self._redact_vault_item(self.vault.seal_directory(input_dir, label=label, metadata=metadata))

    def seal_path(self, input_path: str | os.PathLike, label: Optional[str] = None, metadata: Optional[dict] = None) -> dict:
        return self._redact_vault_item(self.vault.seal_path(input_path, label=label, metadata=metadata))

    def unseal_file(self, object_id: str, output_path: Optional[str | os.PathLike] = None, overwrite: bool = False) -> str:
        return str(self.vault.unseal_file(object_id, output_path=output_path, overwrite=overwrite))

    def restore_directory(self, object_id: str, output_dir: str | os.PathLike, overwrite: bool = False) -> str:
        return str(self.vault.restore_directory(object_id, output_dir=output_dir, overwrite=overwrite))

    def diagnostic_dump(self) -> dict:
        open_tickets = self.store.list_open_tickets()
        intents = self.store.list_intents()
        vault_items = self.vault.list_items()
        return {
            "timestamp": self._now_iso(),
            "schema": STATE_SCHEMA,
            "generation": self.store.generation,
            "mode": self.mode,
            "open_ticket_ids": [t["ticket_id"] for t in open_tickets],
            "open_ticket_count": len(open_tickets),
            "intent_queue_count": len(intents),
            "recent_intents_preview": [self._redact_intent(i) for i in intents[-5:]],
            "metrics_count": self.store.metrics_count(),
            "vault_item_count": len(vault_items),
            "recent_vault_items_preview": [self._redact_vault_item(i) for i in vault_items[-5:]],
        }

    def watchdog_scan(self) -> int:
        warnings_created = 0
        now_dt = _utc_now()
        warn_delta = timedelta(minutes=self.sla_warning_minutes_before_deadline)

        with self.store.transaction():
            for summary in self.store.list_open_tickets():
                ticket = self.store.get_ticket(summary["ticket_id"])
                if not ticket:
                    continue

                sla_dt = _parse_timestamp(ticket["sla_deadline_iso"])
                desired_state: Optional[str] = None
                if now_dt >= sla_dt:
                    desired_state = "BREACHED"
                elif now_dt >= sla_dt - warn_delta:
                    desired_state = "NEAR"

                if not desired_state or ticket.get("sla_warning_state") == desired_state:
                    continue

                ticket["sla_warning_state"] = desired_state
                ticket["sla_warning_last_iso"] = self._now_iso()
                self.store.put_ticket(ticket)
                self.store.append_intent({
                    "intent_id": self._generate_intent_id(),
                    "intent_type": "SLA_WARNING_LOCAL",
                    "warning_state": desired_state,
                    "for_owner": ticket["owner_email"],
                    "ticket_id": ticket["ticket_id"],
                    "created_at": self._now_iso(),
                    "warning_preview": (
                        f"SLA {desired_state} {ticket['ticket_id']}\n"
                        f"Owner: {ticket['owner_email']}\n"
                        f"Subject: {ticket['subject']}\n"
                        f"SLA Deadline: {ticket['sla_deadline_iso']}\n"
                        f"Status: {ticket['status']}"
                    ),
                })
                warnings_created += 1

        return warnings_created

    def close(self) -> None:
        try:
            self.vault.close()
        finally:
            try:
                self.store.close()
            finally:
                self.master_key = bytearray()

    def __enter__(self) -> "SealedCore":
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()
        return False

    @staticmethod
    def _mask_email(email: str) -> str:
        if not isinstance(email, str) or "@" not in email:
            return "[REDACTED]"
        user, domain = email.split("@", 1)
        return f"{user[:2] if user else ''}***@{domain}"

    def _redact_ticket(self, ticket: dict) -> dict:
        if self.mode == "OWNER":
            return copy.deepcopy(ticket)

        allowed = {
            "ticket_id", "route", "owner_email", "status", "received_at_iso",
            "sla_deadline_iso", "target_first_response_minutes", "urgency",
            "last_human_touch_iso", "source", "sla_warning_state", "sla_warning_last_iso",
        }
        redacted = {key: copy.deepcopy(value) for key, value in ticket.items() if key in allowed}
        redacted["sender_email"] = self._mask_email(ticket.get("sender_email", ""))
        redacted["sender_name"] = "[REDACTED]"
        redacted["subject"] = "[REDACTED]"
        return redacted

    def _redact_intent(self, intent: dict) -> dict:
        if self.mode == "OWNER":
            return copy.deepcopy(intent)

        safe_keys = {"intent_id", "intent_type", "created_at", "ticket_id", "for_owner", "warning_state"}
        redacted = {key: copy.deepcopy(value) for key, value in intent.items() if key in safe_keys}
        if "to" in intent:
            redacted["to"] = self._mask_email(intent.get("to", ""))
        if any(key in intent for key in ("message_preview", "body_preview", "warning_preview")):
            redacted["content"] = "[REDACTED]"
        if "subject" in intent:
            redacted["subject"] = "[REDACTED]"
        return redacted

    def _redact_vault_item(self, item: Optional[dict]) -> Optional[dict]:
        if item is None:
            return None
        if self.mode == "OWNER":
            return copy.deepcopy(item)
        safe_keys = {"object_id", "schema", "kind", "created_at", "size_bytes", "chunk_size", "chunk_count", "container_filename"}
        redacted = {key: copy.deepcopy(value) for key, value in item.items() if key in safe_keys}
        redacted["label"] = "[REDACTED]" if item.get("label") else None
        redacted["source_name"] = "[REDACTED]"
        redacted["source_path_hint"] = "[REDACTED]" if item.get("source_path_hint") else None
        if item.get("metadata"):
            redacted["metadata"] = "[REDACTED]"
        if item.get("sha256"):
            redacted["sha256"] = item["sha256"][:12] + "..."
        return redacted

    @staticmethod
    def _bounded_text(value: Any, field: str, limit: int, *, default: str = "") -> str:
        if value is None:
            return default
        if not isinstance(value, str):
            raise ValueError(f"{field} must be a string")
        text = value.strip()
        if len(text) > limit:
            raise ValueError(f"{field} exceeds {limit} characters")
        if "\x00" in text:
            raise ValueError(f"{field} contains NUL")
        return text

    def _normalize(self, raw: dict) -> dict:
        if not isinstance(raw, dict):
            raise ValueError("event must be an object")

        subject = self._bounded_text(raw.get("subject"), "subject", MAX_SUBJECT_CHARS)
        body = self._bounded_text(raw.get("body"), "body", MAX_BODY_CHARS)
        sender = self._bounded_text(raw.get("from_email"), "from_email", MAX_EMAIL_CHARS).lower()
        source = self._bounded_text(raw.get("source"), "source", MAX_SOURCE_CHARS, default="unknown") or "unknown"

        timestamp = raw.get("timestamp")
        if timestamp is not None and not isinstance(timestamp, str):
            raise ValueError("timestamp must be a string")
        received_at_iso = self._normalize_timestamp(timestamp)
        fulltext_lower = (subject + "\n" + body).lower()

        return {
            "subject": subject,
            "body": body,
            "sender_email": sender,
            "sender_name": self._infer_sender_name(sender),
            "received_at_iso": received_at_iso,
            "source": source,
            "urgency": self._infer_urgency(fulltext_lower),
            "fulltext_lower": fulltext_lower,
        }

    def _classify(self, norm: dict) -> str:
        text = norm["fulltext_lower"]
        for route_name, cfg in self.routes.items():
            for keyword in cfg["match_keywords"]:
                if keyword in text:
                    return route_name
        return self.default_route

    def _create_ticket_obj(self, norm: dict, route_name: str) -> dict:
        if route_name not in self.routes:
            raise ValueError("unknown route")
        cfg = self.routes[route_name]
        ticket_id = self._generate_ticket_id(route_name)
        received_at_iso = norm["received_at_iso"]
        sla_deadline_iso = self._compute_sla_deadline_iso(received_at_iso, cfg["target_first_response_minutes"])

        return {
            "ticket_id": ticket_id,
            "route": route_name,
            "owner_email": cfg["owner_email"],
            "status": "OPEN",
            "source": norm["source"],
            "received_at_iso": received_at_iso,
            "sla_deadline_iso": sla_deadline_iso,
            "target_first_response_minutes": cfg["target_first_response_minutes"],
            "subject": norm["subject"],
            "snippet": self._summarize(norm["body"], limit=200),
            "urgency": norm["urgency"],
            "sender_email": norm["sender_email"],
            "sender_name": norm["sender_name"],
            "last_human_touch_iso": None,
            "sla_warning_state": None,
            "sla_warning_last_iso": None,
        }

    def _queue_local_alert_intent(self, ticket: dict) -> None:
        alert_text = (
            f"[{ticket['ticket_id']}] {ticket['route']} {ticket['urgency']}\n"
            f"From: {ticket['sender_email']} ({ticket['sender_name']})\n"
            f"Subject: {ticket['subject']}\n"
            f"Snippet: {ticket['snippet']}\n"
            f"Owner: {ticket['owner_email']}\n"
            f"SLA: {ticket['target_first_response_minutes']}m (deadline {ticket['sla_deadline_iso']})"
        )
        self.store.append_intent({
            "intent_id": self._generate_intent_id(),
            "intent_type": "LOCAL_ALERT_DRAFT",
            "for_owner": ticket["owner_email"],
            "created_at": self._now_iso(),
            "ticket_id": ticket["ticket_id"],
            "message_preview": alert_text,
        })

    def _queue_local_alert_intents(self, ticket: dict) -> None:
        self._queue_local_alert_intent(ticket)

    def _queue_autoreply_intent(self, ticket: dict) -> None:
        reply_body = (
            f"Hi {ticket['sender_name'] or 'there'},\n\n"
            f"Your request has been logged as {ticket['ticket_id']} and assigned to {ticket['owner_email']}.\n"
            f"Our target first response is ~{ticket['target_first_response_minutes']} minutes.\n\n"
            "- automated local system\n"
        )
        self.store.append_intent({
            "intent_id": self._generate_intent_id(),
            "intent_type": "OUTBOUND_EMAIL_DRAFT",
            "to": ticket["sender_email"],
            "subject": f"[{ticket['ticket_id']}] Acknowledged",
            "body_preview": reply_body,
            "created_at": self._now_iso(),
            "ticket_id": ticket["ticket_id"],
        })

    @staticmethod
    def _summarize(text: str, limit: int = 160) -> str:
        return " ".join(text.split())[:limit]

    @staticmethod
    def _validate_ticket_id(ticket_id: Any) -> str:
        if not isinstance(ticket_id, str):
            raise ValueError("ticket_id must be a string")
        value = ticket_id.strip().upper()
        if not re.fullmatch(r"[A-Z]{3}-\d{8}-\d{6}-[A-F0-9]{6}", value):
            raise ValueError("invalid ticket_id format")
        return value

    def _generate_ticket_id(self, route_name: str) -> str:
        timestamp = _utc_now().strftime("%Y%m%d-%H%M%S")
        return f"{route_name[:3].upper()}-{timestamp}-{uuid.uuid4().hex[:6].upper()}"

    @staticmethod
    def _generate_intent_id() -> str:
        return "INT-" + uuid.uuid4().hex.upper()

    def _compute_sla_deadline_iso(self, start_iso: str, minutes: int) -> str:
        return _format_utc(_parse_timestamp(start_iso) + timedelta(minutes=int(minutes)))

    @staticmethod
    def _parse_iso(value: str) -> datetime:
        return _parse_timestamp(value)

    @staticmethod
    def _now_iso() -> str:
        return _format_utc(_utc_now())

    @staticmethod
    def _normalize_timestamp(value: Optional[str]) -> str:
        return _format_utc(_parse_timestamp(value)) if value else _format_utc(_utc_now())

    @staticmethod
    def _infer_sender_name(email_addr: str) -> str:
        local_part = email_addr.split("@", 1)[0] if "@" in email_addr else email_addr
        tokens = local_part.replace(".", " ").replace("_", " ").split()
        tokens = [token.capitalize() for token in tokens if token]
        return " ".join(tokens) if tokens else local_part

    @staticmethod
    def _infer_urgency(text_lower: str) -> str:
        markers = [
            "urgent", "asap", "cannot login", "down", "outage", "critical",
            "prod", "production", "blocker", "right now",
        ]
        return "critical" if any(marker in text_lower for marker in markers) else "normal"


def _run_self_tests() -> int:
    import tempfile as _tempfile

    secret = "self-test-owner-passphrase-32-chars"
    checks: List[tuple[str, bool, str]] = []

    def record(name: str, fn) -> None:
        try:
            fn()
        except Exception as exc:
            checks.append((name, False, f"{type(exc).__name__}: {exc}"))
        else:
            checks.append((name, True, ""))

    with _tempfile.TemporaryDirectory(prefix="sealed-core-selftest-") as temp_root:
        storage = str(Path(temp_root) / "sealed_storage")
        ticket_holder: Dict[str, str] = {}
        vault_holder: Dict[str, str] = {}

        def create_ticket_test():
            core = SealedCore(secret, storage_dir=storage)
            result = core.handle({
                "source": "self-test",
                "subject": "Production outage",
                "body": "Production is down and this is critical.",
                "from_email": "alice@example.com",
                "timestamp": "2026-08-11T10:00:00Z",
            })
            assert result["route"] == "INCIDENT"
            assert result["status"] == "OPEN"
            ticket_holder["id"] = result["ticket_id"]
            diag = core.diagnostic_dump()
            assert diag["open_ticket_count"] == 1
            assert diag["intent_queue_count"] == 2
            assert (Path(storage) / "state.json").is_file()
            core.close()

        record("atomic create + encrypted state", create_ticket_test)

        def persistence_test():
            core = SealedCore(secret, storage_dir=storage)
            detail = core.get_ticket_detail(ticket_holder["id"])
            assert detail is not None and detail["sender_email"] == "alice@example.com"
            assert core.acknowledge_ticket(ticket_holder["id"]) is True
            core.close()

            reopened = SealedCore(secret, storage_dir=storage)
            assert reopened.get_ticket_detail(ticket_holder["id"])["status"] == "ACKNOWLEDGED"
            reopened.close()

        record("lifecycle persists across reopen", persistence_test)

        def helper_redaction_test():
            helper = SealedCore(secret, mode="HELPER", storage_dir=storage)
            detail = helper.get_ticket_detail(ticket_holder["id"])
            assert detail is not None
            assert detail["subject"] == "[REDACTED]"
            assert detail["sender_name"] == "[REDACTED]"
            assert detail["sender_email"].endswith("@example.com")
            assert "snippet" not in detail
            for intent in helper.diagnostic_dump()["recent_intents_preview"]:
                assert "message_preview" not in intent
                assert "body_preview" not in intent
            helper.close()

        record("HELPER redaction", helper_redaction_test)

        def rollback_test():
            core = SealedCore(secret, storage_dir=storage)
            before = core.store.metrics_count()
            try:
                with core.store.transaction():
                    core.store.append_metric({"metric_type": "ROLLBACK_TEST"})
                    raise RuntimeError("intentional rollback")
            except RuntimeError:
                pass
            assert core.store.metrics_count() == before
            core.close()

        record("transaction rollback", rollback_test)

        def close_test():
            core = SealedCore(secret, storage_dir=storage)
            assert core.close_ticket(ticket_holder["id"]) is True
            assert core.get_ticket_detail(ticket_holder["id"])["status"] == "CLOSED"
            assert core.list_open_summary() == []
            core.close()

        record("close lifecycle", close_test)

        def vault_file_roundtrip_test():
            source = Path(temp_root) / "plain.txt"
            original = "secret pixels and thoughts\nline two\n"
            source.write_text(original, encoding="utf-8")
            core = SealedCore(secret, storage_dir=storage)
            sealed = core.seal_file(source, label="plain-text")
            vault_holder["file_id"] = sealed["object_id"]
            restored = Path(temp_root) / "restored_plain.txt"
            result_path = Path(core.unseal_file(sealed["object_id"], restored, overwrite=True))
            assert result_path.read_text(encoding="utf-8") == original
            assert core.diagnostic_dump()["vault_item_count"] >= 1
            core.close()

        record("vault file seal/unseal", vault_file_roundtrip_test)

        def vault_directory_roundtrip_test():
            source_dir = Path(temp_root) / "source_dir"
            nested = source_dir / "nested"
            nested.mkdir(parents=True, exist_ok=True)
            (source_dir / "a.txt").write_text("alpha", encoding="utf-8")
            (nested / "b.txt").write_text("beta", encoding="utf-8")

            core = SealedCore(secret, storage_dir=storage)
            sealed = core.seal_directory(source_dir, label="dir-bundle")
            vault_holder["dir_id"] = sealed["object_id"]
            restore_root = Path(temp_root) / "restored_dirs"
            restored_path = Path(core.restore_directory(sealed["object_id"], restore_root, overwrite=True))
            assert (restored_path / "a.txt").read_text(encoding="utf-8") == "alpha"
            assert (restored_path / "nested" / "b.txt").read_text(encoding="utf-8") == "beta"
            core.close()

        record("vault directory seal/restore", vault_directory_roundtrip_test)

        def helper_vault_redaction_test():
            helper = SealedCore(secret, mode="HELPER", storage_dir=storage)
            item = helper.get_vault_item(vault_holder["file_id"])
            assert item is not None
            assert item["source_name"] == "[REDACTED]"
            assert item["label"] == "[REDACTED]"
            helper.close()

        record("vault HELPER redaction", helper_vault_redaction_test)

        def tamper_test():
            tamper_storage = str(Path(temp_root) / "tamper_store")
            core = SealedCore(secret, storage_dir=tamper_storage)
            core.handle({"subject": "help", "body": "test", "from_email": "test@example.com"})
            core.close()

            state_path = Path(tamper_storage) / "state.json"
            raw = json.loads(state_path.read_text(encoding="utf-8"))
            cipher = raw["enc"]["cipher_hex"]
            raw["enc"]["cipher_hex"] = cipher[:-1] + ("0" if cipher[-1] != "0" else "1")
            state_path.write_text(json.dumps(raw), encoding="utf-8")

            failed_closed = False
            try:
                SealedCore(secret, storage_dir=tamper_storage)
            except (InvalidTag, ValueError):
                failed_closed = True
            assert failed_closed

        record("tamper detection fails closed", tamper_test)

    print("SEALED Core v2.2 self-test")
    print("=" * 30)
    passed = 0
    for name, ok, detail in checks:
        if ok:
            passed += 1
            print(f"PASS  {name}")
        else:
            print(f"FAIL  {name}: {detail}")
    print(f"\n{passed}/{len(checks)} passed")
    return 0 if passed == len(checks) else 1


def _core_cli_main() -> int:
    parser = argparse.ArgumentParser(description="SEALED Core v2.2 local-only core + SealedVault")
    parser.add_argument("--self-test", action="store_true", help="run isolated lifecycle/integrity tests")
    parser.add_argument("--diagnostic", action="store_true", help="print local diagnostic snapshot")
    parser.add_argument("--watchdog", action="store_true", help="run one local SLA watchdog scan")
    parser.add_argument("--list-vault", action="store_true", help="list sealed vault items")
    parser.add_argument("--seal-file", metavar="PATH", help="seal a single file or image")
    parser.add_argument("--seal-dir", metavar="PATH", help="seal a directory as an encrypted tar.gz bundle")
    parser.add_argument("--unseal-file", metavar="OBJECT_ID", help="restore one sealed file by object id")
    parser.add_argument("--restore-dir", metavar="OBJECT_ID", help="restore one sealed directory bundle by object id")
    parser.add_argument("--out", metavar="PATH", help="output file or directory path for restore operations")
    parser.add_argument("--label", metavar="TEXT", help="optional label for seal operations")
    parser.add_argument("--overwrite", action="store_true", help="allow restore operations to overwrite destinations")
    parser.add_argument("--storage-dir", default=DEFAULT_STORAGE_DIR)
    args = parser.parse_args()

    if args.self_test:
        return _run_self_tests()

    if not any([args.diagnostic, args.watchdog, args.list_vault, args.seal_file, args.seal_dir, args.unseal_file, args.restore_dir]):
        parser.print_help()
        return 0

    with SealedCore(storage_dir=args.storage_dir) as core:
        if args.watchdog:
            print(json.dumps({"warnings_created": core.watchdog_scan()}, indent=2))
        if args.diagnostic:
            print(json.dumps(core.diagnostic_dump(), indent=2, ensure_ascii=False))
        if args.list_vault:
            print(json.dumps(core.list_vault_summary(), indent=2, ensure_ascii=False))
        if args.seal_file:
            print(json.dumps(core.seal_file(args.seal_file, label=args.label), indent=2, ensure_ascii=False))
        if args.seal_dir:
            print(json.dumps(core.seal_directory(args.seal_dir, label=args.label), indent=2, ensure_ascii=False))
        if args.unseal_file:
            print(json.dumps({"restored_to": core.unseal_file(args.unseal_file, output_path=args.out, overwrite=args.overwrite)}, indent=2, ensure_ascii=False))
        if args.restore_dir:
            if not args.out:
                raise SystemExit("--restore-dir requires --out DESTINATION_DIRECTORY")
            print(json.dumps({"restored_to": core.restore_directory(args.restore_dir, args.out, overwrite=args.overwrite)}, indent=2, ensure_ascii=False))
    return 0




# ===== HARDENED LOCAL GATEKEEPER =====
"""
gatekeeper_v2_2.py — local-only authenticated policy layer for SEALED Core v2.2

Design:
- caller supplies principal_id, never a trusted role;
- server-side principal registry binds principal -> role/scope;
- per-principal HMAC signatures over canonical JSON;
- timestamp skew + encrypted nonce registry blocks replay;
- write actions require idempotency keys;
- idempotent retries return the original result;
- external acknowledgers are constrained to their own ticket scope;
- explicit output allowlists; no raw-object passthrough;
- no network listener and no remote I/O.

Secrets:
    SEALED_OWNER_SECRET      required by sealed_core.py
    SEALED_PRINCIPALS_JSON   JSON object mapping principal IDs to config

Example SEALED_PRINCIPALS_JSON:
{
  "owner-local": {
    "role": "OWNER",
    "secret": "replace-with-a-long-random-secret",
    "scope_id": "owner"
  },
  "helper-local": {
    "role": "HELPER",
    "secret": "another-long-random-secret",
    "scope_id": "staff"
  }
}

Request shape:
{
  "principal_id": "owner-local",
  "timestamp": "2026-08-11T11:52:00Z",
  "nonce": "random-unique-string",
  "action": "LIST_OPEN_SUMMARY",
  "payload": {},
  "idempotency_key": null,
  "signature": "hex-hmac-sha256"
}
"""

import copy
import hashlib
import hmac
import json
import os
import re
import secrets
from datetime import timedelta
from pathlib import Path
from typing import Any, Dict, Optional



GATEKEEPER_SCHEMA = "SEALED_GATEKEEPER_STATE_V2_2"
MAX_CLOCK_SKEW_SECONDS = 300
NONCE_RETENTION_SECONDS = 3600
MAX_NONCES = 20_000
MAX_IDEMPOTENCY = 20_000
DEFAULT_STORAGE_DIR = "sealed_storage"

ROLES = {"OWNER", "HELPER", "EXTERNAL_CREATE", "EXTERNAL_ACK"}

POLICY = {
    "NEW_TICKET": {
        "roles": {"OWNER", "EXTERNAL_CREATE"},
        "write": True,
        "view": "receipt",
    },
    "ACK_TICKET": {
        "roles": {"OWNER", "EXTERNAL_ACK"},
        "write": True,
        "view": "redacted",
    },
    "CLOSE_TICKET": {
        "roles": {"OWNER"},
        "write": True,
        "view": "redacted",
    },
    "GET_TICKET_DETAIL": {
        "roles": {"OWNER", "HELPER", "EXTERNAL_ACK"},
        "write": False,
        "view": "role",
    },
    "LIST_OPEN_SUMMARY": {
        "roles": {"OWNER", "HELPER", "EXTERNAL_ACK"},
        "write": False,
        "view": "role",
    },
    "SEAL_FILE": {
        "roles": {"OWNER"},
        "write": True,
        "view": "vault_receipt",
    },
    "SEAL_DIR": {
        "roles": {"OWNER"},
        "write": True,
        "view": "vault_receipt",
    },
    "LIST_VAULT": {
        "roles": {"OWNER", "HELPER"},
        "write": False,
        "view": "role",
    },
    "UNSEAL_FILE": {
        "roles": {"OWNER"},
        "write": True,
        "view": "path_receipt",
    },
    "RESTORE_DIR": {
        "roles": {"OWNER"},
        "write": True,
        "view": "path_receipt",
    },
}


def _load_principal_registry() -> Dict[str, dict]:
    raw = os.environ.get("SEALED_PRINCIPALS_JSON")
    if not raw:
        raise RuntimeError("SEALED_PRINCIPALS_JSON environment variable required")
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise RuntimeError("SEALED_PRINCIPALS_JSON must be valid JSON") from exc
    if not isinstance(data, dict) or not data:
        raise RuntimeError("principal registry must be a non-empty object")

    normalized: Dict[str, dict] = {}
    for principal_id, cfg in data.items():
        if not isinstance(principal_id, str) or not re.fullmatch(r"[A-Za-z0-9_.:@-]{1,128}", principal_id):
            raise RuntimeError(f"invalid principal_id: {principal_id!r}")
        if not isinstance(cfg, dict):
            raise RuntimeError(f"principal {principal_id!r} config must be an object")
        role = str(cfg.get("role", "")).upper()
        secret = cfg.get("secret")
        scope_id = str(cfg.get("scope_id", principal_id))
        if role not in ROLES:
            raise RuntimeError(f"principal {principal_id!r} has invalid role")
        if not isinstance(secret, str) or len(secret) < 24:
            raise RuntimeError(f"principal {principal_id!r} secret must be at least 24 characters")
        if not re.fullmatch(r"[A-Za-z0-9_.:@-]{1,128}", scope_id):
            raise RuntimeError(f"principal {principal_id!r} has invalid scope_id")
        normalized[principal_id] = {
            "role": role,
            "secret": secret,
            "scope_id": scope_id,
        }
    return normalized


def canonical_request_for_signing(request: dict) -> dict:
    return {
        "principal_id": request.get("principal_id"),
        "timestamp": request.get("timestamp"),
        "nonce": request.get("nonce"),
        "action": request.get("action"),
        "payload": request.get("payload", {}),
        "idempotency_key": request.get("idempotency_key"),
    }


def build_signed_request(
    principal_id: str,
    secret: str,
    action: str,
    payload: Optional[dict] = None,
    idempotency_key: Optional[str] = None,
) -> dict:
    request = {
        "principal_id": principal_id,
        "timestamp": _format_utc(_utc_now()),
        "nonce": secrets.token_urlsafe(24),
        "action": action.upper(),
        "payload": payload or {},
        "idempotency_key": idempotency_key,
    }
    request["signature"] = sign_request(request, secret)
    return request


def sign_request(request: dict, secret: str) -> str:
    return hmac.new(
        secret.encode("utf-8"),
        _canonical_json_bytes(canonical_request_for_signing(request)),
        hashlib.sha256,
    ).hexdigest()


class GatekeeperState:
    def __init__(self, owner_secret: str, storage_dir: str = DEFAULT_STORAGE_DIR):
        machine_fp = _get_machine_fingerprint()
        master = _derive_master_key(owner_secret, machine_fp)
        try:
            self.key = bytearray(_derive_subkey(master, "SEALED_GATEKEEPER_V2_2"))
        finally:
            for i in range(len(master)):
                master[i] = 0

        self.dir = Path(storage_dir).expanduser().resolve()
        self.dir.mkdir(parents=True, exist_ok=True)
        self.path = self.dir / "gatekeeper_state.json"
        self.lock_path = self.dir / ".gatekeeper.lock"

    @staticmethod
    def _new_state() -> dict:
        return {
            "schema": GATEKEEPER_SCHEMA,
            "updated_at": _format_utc(_utc_now()),
            "nonces": {},
            "idempotency": {},
            "ticket_scopes": {},
        }

    def _load_locked(self) -> dict:
        if not self.path.exists():
            return self._new_state()
        raw = json.loads(self.path.read_text(encoding="utf-8"))
        if not isinstance(raw, dict) or "enc" not in raw:
            raise ValueError("invalid gatekeeper state envelope")
        state = _decrypt_blob(self.key, raw["enc"])
        if not isinstance(state, dict) or state.get("schema") != GATEKEEPER_SCHEMA:
            raise ValueError("invalid gatekeeper state")
        state.setdefault("nonces", {})
        state.setdefault("idempotency", {})
        state.setdefault("ticket_scopes", {})
        return state

    def _save_locked(self, state: dict) -> None:
        state["schema"] = GATEKEEPER_SCHEMA
        state["updated_at"] = _format_utc(_utc_now())
        _atomic_json_write(self.path, {
            "schema": GATEKEEPER_SCHEMA,
            "enc": _encrypt_blob(self.key, state),
        })

    def _prune(self, state: dict) -> None:
        cutoff = _utc_now() - timedelta(seconds=NONCE_RETENTION_SECONDS)
        fresh = {}
        for key, ts in state.get("nonces", {}).items():
            try:
                if _parse_timestamp(ts) >= cutoff:
                    fresh[key] = ts
            except Exception:
                continue
        if len(fresh) > MAX_NONCES:
            ordered = sorted(fresh.items(), key=lambda kv: kv[1], reverse=True)[:MAX_NONCES]
            fresh = dict(ordered)
        state["nonces"] = fresh

        idem = state.get("idempotency", {})
        if len(idem) > MAX_IDEMPOTENCY:
            ordered = sorted(idem.items(), key=lambda kv: kv[1].get("created_at", ""), reverse=True)[:MAX_IDEMPOTENCY]
            state["idempotency"] = dict(ordered)

    def consume_nonce_and_check_idempotency(
        self,
        principal_id: str,
        nonce: str,
        request_hash: str,
        idempotency_key: Optional[str],
    ) -> Optional[dict]:
        nonce_key = f"{principal_id}:{nonce}"
        idem_key = f"{principal_id}:{idempotency_key}" if idempotency_key else None

        with _StoreFileLock(self.lock_path):
            state = self._load_locked()
            self._prune(state)

            if nonce_key in state["nonces"]:
                raise ValueError("REPLAYED_NONCE")
            state["nonces"][nonce_key] = _format_utc(_utc_now())

            prior = None
            if idem_key:
                prior = state["idempotency"].get(idem_key)
                if prior and prior.get("request_hash") != request_hash:
                    raise ValueError("IDEMPOTENCY_KEY_REUSED_FOR_DIFFERENT_REQUEST")

            self._save_locked(state)
            return copy.deepcopy(prior.get("result")) if prior else None

    def record_idempotent_result(
        self,
        principal_id: str,
        idempotency_key: str,
        request_hash: str,
        result: dict,
    ) -> None:
        idem_key = f"{principal_id}:{idempotency_key}"
        with _StoreFileLock(self.lock_path):
            state = self._load_locked()
            state["idempotency"][idem_key] = {
                "request_hash": request_hash,
                "created_at": _format_utc(_utc_now()),
                "result": copy.deepcopy(result),
            }
            self._save_locked(state)

    def bind_ticket_scope(self, ticket_id: str, scope_id: str) -> None:
        with _StoreFileLock(self.lock_path):
            state = self._load_locked()
            state["ticket_scopes"][ticket_id] = scope_id
            self._save_locked(state)

    def ticket_scope(self, ticket_id: str) -> Optional[str]:
        with _StoreFileLock(self.lock_path):
            state = self._load_locked()
            return state["ticket_scopes"].get(ticket_id)

    def close(self) -> None:
        for i in range(len(self.key)):
            self.key[i] = 0


class GatekeeperV22:
    def __init__(self, storage_dir: str = DEFAULT_STORAGE_DIR):
        self.owner_secret = os.environ.get("SEALED_OWNER_SECRET")
        if not self.owner_secret:
            raise RuntimeError("SEALED_OWNER_SECRET environment variable required")
        self.registry = _load_principal_registry()
        self.storage_dir = storage_dir
        self.state = GatekeeperState(self.owner_secret, storage_dir=storage_dir)

    @staticmethod
    def _business_hash(request: dict) -> str:
        # Nonce/timestamp are transport freshness, not business identity.
        operation = {
            "principal_id": request.get("principal_id"),
            "action": request.get("action"),
            "payload": request.get("payload", {}),
            "idempotency_key": request.get("idempotency_key"),
        }
        return hashlib.sha256(_canonical_json_bytes(operation)).hexdigest()

    @staticmethod
    def _validate_nonce(nonce: Any) -> str:
        if not isinstance(nonce, str) or not re.fullmatch(r"[A-Za-z0-9_.:@-]{16,256}", nonce):
            raise ValueError("INVALID_NONCE")
        return nonce

    @staticmethod
    def _validate_idempotency_key(value: Any) -> Optional[str]:
        if value is None:
            return None
        if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9_.:@-]{8,256}", value):
            raise ValueError("INVALID_IDEMPOTENCY_KEY")
        return value

    def _authenticate(self, request: dict) -> tuple[str, dict, dict, str, Optional[str], Optional[dict]]:
        if not isinstance(request, dict):
            raise ValueError("INVALID_REQUEST")

        principal_id = request.get("principal_id")
        if not isinstance(principal_id, str) or principal_id not in self.registry:
            raise ValueError("UNAUTHORIZED")
        principal = self.registry[principal_id]

        timestamp = request.get("timestamp")
        if not isinstance(timestamp, str):
            raise ValueError("INVALID_TIMESTAMP")
        request_time = _parse_timestamp(timestamp)
        if abs((_utc_now() - request_time).total_seconds()) > MAX_CLOCK_SKEW_SECONDS:
            raise ValueError("STALE_REQUEST")

        nonce = self._validate_nonce(request.get("nonce"))
        action = str(request.get("action", "")).upper()
        rule = POLICY.get(action)
        if not rule:
            raise ValueError("UNKNOWN_ACTION")
        if principal["role"] not in rule["roles"]:
            raise ValueError("ROLE_NOT_ALLOWED")

        payload = request.get("payload", {})
        if not isinstance(payload, dict):
            raise ValueError("INVALID_PAYLOAD")

        signature = request.get("signature")
        if not isinstance(signature, str):
            raise ValueError("UNAUTHORIZED")
        expected = sign_request(request, principal["secret"])
        if not hmac.compare_digest(expected, signature):
            raise ValueError("UNAUTHORIZED")

        idempotency_key = self._validate_idempotency_key(request.get("idempotency_key"))
        if rule["write"] and not idempotency_key:
            raise ValueError("IDEMPOTENCY_KEY_REQUIRED")

        request_hash = self._business_hash(request)
        prior = self.state.consume_nonce_and_check_idempotency(
            principal_id,
            nonce,
            request_hash,
            idempotency_key,
        )
        return action, principal, payload, request_hash, idempotency_key, prior

    def _core(self, principal: dict) -> SealedCore:
        mode = "OWNER" if principal["role"] == "OWNER" else "HELPER"
        return SealedCore(self.owner_secret, mode=mode, storage_dir=self.storage_dir)

    @staticmethod
    def _receipt(data: dict) -> dict:
        allowed = {"ticket_id", "route", "owner", "sla_deadline", "status"}
        return {key: copy.deepcopy(value) for key, value in data.items() if key in allowed}

    @staticmethod
    def _vault_receipt(data: dict) -> dict:
        allowed = {"object_id", "kind", "created_at", "size_bytes", "chunk_count", "sha256"}
        return {key: copy.deepcopy(value) for key, value in data.items() if key in allowed}

    @staticmethod
    def _path_receipt(path: str) -> dict:
        return {"restored_to": path}

    def _scope_check(self, principal: dict, ticket_id: str) -> None:
        if principal["role"] != "EXTERNAL_ACK":
            return
        scope = self.state.ticket_scope(ticket_id)
        if scope is None or scope != principal["scope_id"]:
            raise ValueError("SCOPE_NOT_ALLOWED")

    def _execute(self, action: str, principal: dict, payload: dict) -> dict:
        with self._core(principal) as core:
            if action == "NEW_TICKET":
                incoming = {
                    "source": payload.get("source", "external"),
                    "subject": payload.get("subject", ""),
                    "body": payload.get("body", ""),
                    "from_email": payload.get("from_email", "unknown@example.com"),
                    "timestamp": payload.get("timestamp"),
                }
                result = core.handle(incoming)
                self.state.bind_ticket_scope(result["ticket_id"], principal["scope_id"])
                return self._receipt(result)

            if action == "ACK_TICKET":
                ticket_id = str(payload.get("ticket_id", ""))
                self._scope_check(principal, ticket_id)
                changed = core.acknowledge_ticket(ticket_id)
                detail = core.get_ticket_detail(ticket_id)
                return {"changed": changed, "ticket": detail}

            if action == "CLOSE_TICKET":
                ticket_id = str(payload.get("ticket_id", ""))
                changed = core.close_ticket(ticket_id)
                detail = core.get_ticket_detail(ticket_id)
                return {"changed": changed, "ticket": detail}

            if action == "GET_TICKET_DETAIL":
                ticket_id = str(payload.get("ticket_id", ""))
                self._scope_check(principal, ticket_id)
                return {"ticket": core.get_ticket_detail(ticket_id)}

            if action == "LIST_OPEN_SUMMARY":
                items = core.list_open_summary()
                if principal["role"] == "EXTERNAL_ACK":
                    items = [
                        item for item in items
                        if self.state.ticket_scope(item.get("ticket_id", "")) == principal["scope_id"]
                    ]
                return {"open": items, "time": core.debug_snapshot()["timestamp"]}

            if action == "SEAL_FILE":
                result = core.seal_file(
                    payload.get("path", ""),
                    label=payload.get("label"),
                    metadata=payload.get("metadata"),
                )
                return self._vault_receipt(result)

            if action == "SEAL_DIR":
                result = core.seal_directory(
                    payload.get("path", ""),
                    label=payload.get("label"),
                    metadata=payload.get("metadata"),
                )
                return self._vault_receipt(result)

            if action == "LIST_VAULT":
                return {"items": core.list_vault_summary()}

            if action == "UNSEAL_FILE":
                restored = core.unseal_file(
                    str(payload.get("object_id", "")),
                    output_path=payload.get("out"),
                    overwrite=bool(payload.get("overwrite", False)),
                )
                return self._path_receipt(restored)

            if action == "RESTORE_DIR":
                restored = core.restore_directory(
                    str(payload.get("object_id", "")),
                    str(payload.get("out", "")),
                    overwrite=bool(payload.get("overwrite", False)),
                )
                return self._path_receipt(restored)

        raise ValueError("NOT_IMPLEMENTED")

    def request(self, request: dict) -> dict:
        try:
            auth = self._authenticate(request)
            action, principal, payload, request_hash, idempotency_key, prior = auth
            if prior is not None:
                return copy.deepcopy(prior)

            result = {
                "ok": True,
                "action": action,
                "data": self._execute(action, principal, payload),
            }
            if idempotency_key:
                self.state.record_idempotent_result(
                    request["principal_id"],
                    idempotency_key,
                    request_hash,
                    result,
                )
            return result
        except ValueError as exc:
            return {"ok": False, "error": str(exc)}
        except Exception:
            # Deliberately avoid reflecting internal details to callers.
            return {"ok": False, "error": "INTERNAL_ERROR"}

    def close(self) -> None:
        self.state.close()


def gatekeeper_request(request: dict, storage_dir: str = DEFAULT_STORAGE_DIR) -> dict:
    gate = GatekeeperV22(storage_dir=storage_dir)
    try:
        return gate.request(request)
    finally:
        gate.close()




def main() -> int:
    parser = argparse.ArgumentParser(description="SEALED BLACK BOX v2.2 — easy monolithic front door")
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("self-test", help="run SEALED core/vault self-tests")

    p_diag = sub.add_parser("diagnostic", help="show local diagnostic snapshot")
    p_diag.add_argument("--storage-dir", default=DEFAULT_STORAGE_DIR)

    p_watch = sub.add_parser("watchdog", help="run SLA watchdog once")
    p_watch.add_argument("--storage-dir", default=DEFAULT_STORAGE_DIR)

    p_snap = sub.add_parser("snapshot", help="seal one file, image, backup, disk image, or directory")
    p_snap.add_argument("path")
    p_snap.add_argument("--label")
    p_snap.add_argument("--storage-dir", default=DEFAULT_STORAGE_DIR)

    p_list = sub.add_parser("list", help="list SealedVault items")
    p_list.add_argument("--storage-dir", default=DEFAULT_STORAGE_DIR)

    p_unseal = sub.add_parser("unseal", help="restore one sealed file")
    p_unseal.add_argument("object_id")
    p_unseal.add_argument("--out")
    p_unseal.add_argument("--overwrite", action="store_true")
    p_unseal.add_argument("--storage-dir", default=DEFAULT_STORAGE_DIR)

    p_restore = sub.add_parser("restore-dir", help="restore one sealed directory bundle")
    p_restore.add_argument("object_id")
    p_restore.add_argument("out")
    p_restore.add_argument("--overwrite", action="store_true")
    p_restore.add_argument("--storage-dir", default=DEFAULT_STORAGE_DIR)

    p_req = sub.add_parser("request", help="execute one signed gatekeeper request from a JSON file or '-' for stdin")
    p_req.add_argument("request_json")
    p_req.add_argument("--storage-dir", default=DEFAULT_STORAGE_DIR)

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        return 0

    if args.command == "self-test":
        return _run_self_tests()

    if args.command == "request":
        if args.request_json == "-":
            request = json.load(__import__("sys").stdin)
        else:
            request = json.loads(Path(args.request_json).read_text(encoding="utf-8"))
        print(json.dumps(gatekeeper_request(request, storage_dir=args.storage_dir), indent=2, ensure_ascii=False))
        return 0

    with SealedCore(storage_dir=args.storage_dir) as sealed:
        if args.command == "diagnostic":
            print(json.dumps(sealed.diagnostic_dump(), indent=2, ensure_ascii=False))
        elif args.command == "watchdog":
            print(json.dumps({"warnings_created": sealed.watchdog_scan()}, indent=2))
        elif args.command == "snapshot":
            result = sealed.seal_path(args.path, label=args.label)
            print(json.dumps(result, indent=2, ensure_ascii=False))
            print("\nSnapshot sealed. Original files were not deleted.")
        elif args.command == "list":
            print(json.dumps(sealed.list_vault_summary(), indent=2, ensure_ascii=False))
        elif args.command == "unseal":
            restored = sealed.unseal_file(args.object_id, output_path=args.out, overwrite=args.overwrite)
            print(json.dumps({"restored_to": restored}, indent=2, ensure_ascii=False))
        elif args.command == "restore-dir":
            restored = sealed.restore_directory(args.object_id, args.out, overwrite=args.overwrite)
            print(json.dumps({"restored_to": restored}, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
