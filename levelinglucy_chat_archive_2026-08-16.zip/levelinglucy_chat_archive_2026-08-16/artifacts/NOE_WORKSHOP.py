#!/usr/bin/env python3
"""
NOE_WORKSHOP.py

Assistant Shell v3 / Noe Workshop
---------------------------------
A local-first, single-file workshop for preserving and developing code,
notes, packets, theories, and project continuity with low cognitive load.

Design goals:
- preserve modular projects without swallowing them into one codebase;
- keep stable / candidate / archive identity durable across exports/imports;
- use UUIDs as persistent artifact identity and SQLite IDs only locally;
- keep a compact WORKSHOP_LEDGER so a later session can resume naturally;
- make bundle import/export transactional, schema-versioned, and portable;
- stay Pythonista-friendly while remaining usable from desktop Python CLI;
- never require network access.

The Pythonista UI is optional. The database core and CLI use only the
Python standard library.
"""

from __future__ import annotations

import argparse
import datetime as _dt
import json
import os
import shutil
import sqlite3
import tempfile
import uuid
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Union

try:  # Pythonista-only conveniences.
    import ui  # type: ignore
    import dialogs  # type: ignore
    import console  # type: ignore
    UI_AVAILABLE = True
except Exception:
    ui = None
    dialogs = None
    console = None
    UI_AVAILABLE = False


APP_NAME = "NOE WORKSHOP"
APP_VERSION = "3.0.0"
DB_SCHEMA_VERSION = 3
BUNDLE_SCHEMA = "NOE_WORKSHOP_BUNDLE_V3"
LEDGER_SCHEMA = "NOE_WORKSHOP_LEDGER_V1"

DOCUMENTS_DIR = Path(os.path.expanduser("~/Documents"))
APP_DIR = DOCUMENTS_DIR / "NOE_WORKSHOP"
DB_PATH = APP_DIR / "noe_workshop.db"
EXPORT_DIR = APP_DIR / "exports"
LEGACY_DB_PATH = DOCUMENTS_DIR / "assistant_shell_v2.db"


THEME = {
    "bg": "#05070a",
    "panel": "#0b1016",
    "panel_2": "#101823",
    "panel_3": "#0d141d",
    "border": "#223449",
    "text": "#d9f7ff",
    "muted": "#77a8b8",
    "accent": "#6bf7ff",
    "accent_2": "#84ffa6",
    "warn": "#ffd166",
    "danger": "#ff6b8f",
}

FONT_BODY = ("<system>", 14)
FONT_SMALL = ("<system>", 12)
FONT_TITLE = ("<system-bold>", 22)
FONT_SUBTITLE = ("<system-bold>", 16)
FONT_MONO = ("Menlo", 12)


def now_iso() -> str:
    """Timezone-explicit UTC timestamp, stable across machines."""
    return (
        _dt.datetime.now(_dt.timezone.utc)
        .replace(microsecond=0)
        .isoformat()
        .replace("+00:00", "Z")
    )


def compact_stamp() -> str:
    return _dt.datetime.now(_dt.timezone.utc).strftime("%Y%m%d_%H%M%S")


def new_uuid() -> str:
    return uuid.uuid4().hex


def safe_name(text: str) -> str:
    text = (text or "artifact").strip()
    keep = "".join(ch if ch.isalnum() or ch in "-_ ." else "_" for ch in text)
    keep = "_".join(keep.split())
    return keep or "artifact"


def json_text(obj: Any, pretty: bool = True) -> str:
    if pretty:
        return json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=True)
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":"), sort_keys=True)


def detect_extension(artifact_type: str) -> str:
    mapping = {
        "python_file": ".py",
        "patch": ".txt",
        "packet": ".json",
        "bug_report": ".txt",
        "note": ".txt",
        "analysis": ".md",
        "command": ".json",
        "theory": ".md",
    }
    return mapping.get(artifact_type, ".txt")


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def atomic_write_text(path: Path, text: str) -> None:
    """Write text using same-directory temporary file + atomic replacement."""
    path = Path(path)
    ensure_dir(path.parent)
    fd, temp_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent), text=True
    )
    temp_path = Path(temp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(text)
            handle.flush()
            try:
                os.fsync(handle.fileno())
            except OSError:
                pass
        os.replace(temp_path, path)
    except Exception:
        try:
            temp_path.unlink()
        except OSError:
            pass
        raise


def atomic_write_json(path: Path, value: Any) -> None:
    atomic_write_text(path, json_text(value, pretty=True) + "\n")


def decode_json_field(value: Any, expected_type: type, default: Any) -> Any:
    if isinstance(value, expected_type):
        return value
    if isinstance(value, str):
        try:
            decoded = json.loads(value)
        except Exception:
            return default
        if isinstance(decoded, expected_type):
            return decoded
    return default


def default_workspace() -> Dict[str, Any]:
    return {
        "selected_artifact_uuid": None,
        "active_project": "default",
        "next_action": "Paste an artifact into the dock.",
        "status": "idle",
    }


def default_version_rail() -> Dict[str, Any]:
    return {
        "stable_uuid": None,
        "candidate_uuid": None,
        "archive_uuids": [],
        "last_export_path": "",
    }


def default_ledger() -> Dict[str, Any]:
    return {
        "schema": LEDGER_SCHEMA,
        "updated_at": now_iso(),
        "status": "resting",
        "project": "",
        "repository": "",
        "path": "",
        "commit": "",
        "blob": "",
        "files_examined": [],
        "what_changed": [],
        "unresolved": [],
        "possible_next_threads": [],
        "leave_alone": [],
        "notes": [],
        "stable_artifact_uuid": None,
        "candidate_artifact_uuid": None,
        "github_modified": False,
    }


def prepare_default_storage() -> None:
    ensure_dir(APP_DIR)
    ensure_dir(EXPORT_DIR)
    # Preserve the old database rather than mutating it in place. On first v3
    # launch, make a working copy and migrate the copy.
    if not DB_PATH.exists() and LEGACY_DB_PATH.exists():
        shutil.copy2(LEGACY_DB_PATH, DB_PATH)


class DB:
    def __init__(self, path: Union[Path, str]):
        self.path = str(path)
        ensure_dir(Path(self.path).parent)
        self.conn = sqlite3.connect(self.path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys=ON")
        try:
            self.conn.execute("PRAGMA journal_mode=WAL")
        except sqlite3.DatabaseError:
            pass
        self.setup()

    def close(self) -> None:
        try:
            self.conn.close()
        except Exception:
            pass

    # ----- schema / migration ------------------------------------

    def setup(self) -> None:
        self.conn.execute(
            """
            CREATE TABLE IF NOT EXISTS artifacts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                artifact_uuid TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                title TEXT,
                artifact_type TEXT NOT NULL,
                bucket TEXT NOT NULL,
                content TEXT NOT NULL,
                source TEXT DEFAULT '',
                instructions TEXT DEFAULT '',
                tags_json TEXT DEFAULT '[]',
                meta_json TEXT DEFAULT '{}',
                project TEXT DEFAULT '',
                provenance_json TEXT DEFAULT '{}'
            )
            """
        )
        self.conn.execute(
            """
            CREATE TABLE IF NOT EXISTS shell_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT NOT NULL,
                level TEXT NOT NULL,
                message TEXT NOT NULL,
                details TEXT DEFAULT ''
            )
            """
        )
        self.conn.execute(
            """
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value_json TEXT NOT NULL
            )
            """
        )
        self.conn.commit()
        self._migrate_artifacts_table()
        self.ensure_defaults()

    def _columns(self, table: str) -> set[str]:
        return {row["name"] for row in self.conn.execute(f"PRAGMA table_info({table})")}

    def _migrate_artifacts_table(self) -> None:
        cols = self._columns("artifacts")
        additions = {
            "artifact_uuid": "TEXT",
            "project": "TEXT DEFAULT ''",
            "provenance_json": "TEXT DEFAULT '{}'",
        }
        for name, ddl in additions.items():
            if name not in cols:
                self.conn.execute(f"ALTER TABLE artifacts ADD COLUMN {name} {ddl}")
        rows = self.conn.execute(
            "SELECT id FROM artifacts WHERE artifact_uuid IS NULL OR TRIM(artifact_uuid)=''"
        ).fetchall()
        for row in rows:
            self.conn.execute(
                "UPDATE artifacts SET artifact_uuid=? WHERE id=?", (new_uuid(), row["id"])
            )
        self.conn.execute(
            "CREATE UNIQUE INDEX IF NOT EXISTS idx_artifacts_uuid ON artifacts(artifact_uuid)"
        )
        self.conn.commit()

    def ensure_defaults(self) -> None:
        self.set_setting("db_schema_version", DB_SCHEMA_VERSION)
        self._migrate_version_rail()
        self._migrate_workspace()
        if self.get_setting("workshop_ledger") is None:
            self.set_setting("workshop_ledger", default_ledger())
        if self.get_setting("ledger_history") is None:
            self.set_setting("ledger_history", [])

    def _migrate_version_rail(self) -> None:
        raw = self.get_setting("version_rail")
        if raw is None:
            self.set_setting("version_rail", default_version_rail())
            return
        if "stable_uuid" in raw or "candidate_uuid" in raw:
            merged = default_version_rail()
            merged.update(raw)
            merged["archive_uuids"] = list(dict.fromkeys(merged.get("archive_uuids", [])))
            self.set_setting("version_rail", merged)
            return

        def id_to_uuid(value: Any) -> Optional[str]:
            row = self.get_artifact(value)
            return row["artifact_uuid"] if row else None

        migrated = default_version_rail()
        migrated["stable_uuid"] = id_to_uuid(raw.get("stable_id"))
        migrated["candidate_uuid"] = id_to_uuid(raw.get("candidate_id"))
        migrated["archive_uuids"] = [
            u for u in (id_to_uuid(x) for x in raw.get("archive_ids", [])) if u
        ]
        migrated["last_export_path"] = raw.get("last_export_path", "")
        self.set_setting("version_rail", migrated)

    def _migrate_workspace(self) -> None:
        raw = self.get_setting("workspace")
        if raw is None:
            self.set_setting("workspace", default_workspace())
            return
        merged = default_workspace()
        merged.update(raw)
        if not merged.get("selected_artifact_uuid") and raw.get("selected_artifact_id"):
            row = self.get_artifact(raw.get("selected_artifact_id"))
            merged["selected_artifact_uuid"] = row["artifact_uuid"] if row else None
        merged.pop("selected_artifact_id", None)
        self.set_setting("workspace", merged)

    # ----- settings / logs ---------------------------------------

    def get_setting(self, key: str, default: Any = None) -> Any:
        row = self.conn.execute(
            "SELECT value_json FROM settings WHERE key=?", (key,)
        ).fetchone()
        if not row:
            return default
        try:
            return json.loads(row["value_json"])
        except Exception:
            return default

    def _set_setting_tx(self, key: str, value: Any) -> None:
        payload = json.dumps(value, ensure_ascii=False)
        self.conn.execute(
            """
            INSERT INTO settings (key, value_json)
            VALUES (?, ?)
            ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json
            """,
            (key, payload),
        )

    def set_setting(self, key: str, value: Any) -> None:
        self._set_setting_tx(key, value)
        self.conn.commit()

    def log(self, message: str, level: str = "info", details: str = "") -> None:
        self.conn.execute(
            """
            INSERT INTO shell_logs (created_at, level, message, details)
            VALUES (?, ?, ?, ?)
            """,
            (now_iso(), level, message, details),
        )
        self.conn.commit()

    def list_logs(self, limit: int = 100) -> List[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM shell_logs ORDER BY id DESC LIMIT ?", (int(limit),)
        ).fetchall()

    # ----- normalization -----------------------------------------

    def normalize_tags(self, tags: Any) -> List[str]:
        if not tags:
            return []
        if isinstance(tags, str):
            decoded = decode_json_field(tags, list, None)
            if decoded is not None:
                tags = decoded
            else:
                tags = [x.strip() for x in tags.replace("\n", ",").split(",")]
        if not isinstance(tags, (list, tuple, set)):
            return []
        out: List[str] = []
        seen = set()
        for item in tags:
            text = str(item or "").strip()
            if text and text not in seen:
                out.append(text)
                seen.add(text)
        return out

    def normalize_meta(self, meta: Any) -> Dict[str, Any]:
        if isinstance(meta, str):
            meta = decode_json_field(meta, dict, {})
        return dict(meta) if isinstance(meta, dict) else {}

    def normalize_provenance(self, provenance: Any) -> Dict[str, Any]:
        if isinstance(provenance, str):
            provenance = decode_json_field(provenance, dict, {})
        if not isinstance(provenance, dict):
            provenance = {}
        out = dict(provenance)
        for key in ("repository", "path", "commit", "blob"):
            out[key] = str(out.get(key, "") or "").strip()
        return out

    # ----- artifact operations -----------------------------------

    def _insert_artifact_tx(
        self,
        title: str,
        artifact_type: str,
        bucket: str,
        content: str,
        source: str = "",
        instructions: str = "",
        tags: Any = None,
        meta: Any = None,
        project: str = "",
        provenance: Any = None,
        artifact_uuid: Optional[str] = None,
        created_at: Optional[str] = None,
        updated_at: Optional[str] = None,
    ) -> tuple[int, str]:
        auuid = str(artifact_uuid or new_uuid())
        ts = now_iso()
        created = created_at or ts
        updated = updated_at or created
        tags_json = json.dumps(self.normalize_tags(tags), ensure_ascii=False)
        meta_json = json.dumps(self.normalize_meta(meta), ensure_ascii=False)
        prov_json = json.dumps(self.normalize_provenance(provenance), ensure_ascii=False)
        cursor = self.conn.execute(
            """
            INSERT INTO artifacts (
                artifact_uuid, created_at, updated_at, title, artifact_type,
                bucket, content, source, instructions, tags_json, meta_json,
                project, provenance_json
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                auuid,
                created,
                updated,
                (title or "").strip(),
                (artifact_type or "note").strip(),
                (bucket or "inbox").strip(),
                content or "",
                (source or "").strip(),
                (instructions or "").strip(),
                tags_json,
                meta_json,
                (project or "").strip(),
                prov_json,
            ),
        )
        return int(cursor.lastrowid), auuid

    def add_artifact(
        self,
        title: str,
        artifact_type: str,
        bucket: str,
        content: str,
        source: str = "",
        instructions: str = "",
        tags: Any = None,
        meta: Any = None,
        project: str = "",
        provenance: Any = None,
        artifact_uuid: Optional[str] = None,
    ) -> int:
        try:
            self.conn.execute("BEGIN")
            artifact_id, auuid = self._insert_artifact_tx(
                title,
                artifact_type,
                bucket,
                content,
                source,
                instructions,
                tags,
                meta,
                project,
                provenance,
                artifact_uuid,
            )
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        self.log(
            f"Artifact stored in {bucket}",
            details=f"id={artifact_id} uuid={auuid} type={artifact_type}",
        )
        return artifact_id

    def _update_artifact_tx(
        self,
        artifact_uuid: str,
        *,
        title: Optional[str] = None,
        artifact_type: Optional[str] = None,
        bucket: Optional[str] = None,
        content: Optional[str] = None,
        source: Optional[str] = None,
        instructions: Optional[str] = None,
        tags: Any = None,
        meta: Any = None,
        project: Optional[str] = None,
        provenance: Any = None,
    ) -> bool:
        row = self.get_artifact_by_uuid(artifact_uuid)
        if not row:
            return False
        current_meta = self.get_artifact_meta(row)
        if meta is not None:
            current_meta.update(self.normalize_meta(meta))
        current_prov = self.get_artifact_provenance(row)
        if provenance is not None:
            current_prov.update(self.normalize_provenance(provenance))
        values = {
            "title": row["title"] if title is None else title,
            "artifact_type": row["artifact_type"] if artifact_type is None else artifact_type,
            "bucket": row["bucket"] if bucket is None else bucket,
            "content": row["content"] if content is None else content,
            "source": row["source"] if source is None else source,
            "instructions": row["instructions"] if instructions is None else instructions,
            "tags_json": row["tags_json"]
            if tags is None
            else json.dumps(self.normalize_tags(tags), ensure_ascii=False),
            "meta_json": json.dumps(current_meta, ensure_ascii=False),
            "project": row["project"] if project is None else project,
            "provenance_json": json.dumps(current_prov, ensure_ascii=False),
        }
        self.conn.execute(
            """
            UPDATE artifacts
            SET updated_at=?, title=?, artifact_type=?, bucket=?, content=?, source=?,
                instructions=?, tags_json=?, meta_json=?, project=?, provenance_json=?
            WHERE artifact_uuid=?
            """,
            (
                now_iso(),
                values["title"],
                values["artifact_type"],
                values["bucket"],
                values["content"],
                values["source"],
                values["instructions"],
                values["tags_json"],
                values["meta_json"],
                values["project"],
                values["provenance_json"],
                artifact_uuid,
            ),
        )
        return True

    def update_artifact(self, artifact_id: int, **kwargs: Any) -> bool:
        row = self.get_artifact(artifact_id)
        if not row:
            return False
        ok = self._update_artifact_tx(row["artifact_uuid"], **kwargs)
        self.conn.commit()
        return ok

    def get_artifact(self, artifact_id: Any) -> Optional[sqlite3.Row]:
        if artifact_id in (None, ""):
            return None
        try:
            value = int(artifact_id)
        except (TypeError, ValueError):
            return None
        return self.conn.execute("SELECT * FROM artifacts WHERE id=?", (value,)).fetchone()

    def get_artifact_by_uuid(self, artifact_uuid: Any) -> Optional[sqlite3.Row]:
        if not artifact_uuid:
            return None
        return self.conn.execute(
            "SELECT * FROM artifacts WHERE artifact_uuid=?", (str(artifact_uuid),)
        ).fetchone()

    def artifact_uuid_for_id(self, artifact_id: Any) -> Optional[str]:
        row = self.get_artifact(artifact_id)
        return row["artifact_uuid"] if row else None

    def latest_artifact(self) -> Optional[sqlite3.Row]:
        return self.conn.execute("SELECT * FROM artifacts ORDER BY id DESC LIMIT 1").fetchone()

    def list_artifacts(
        self,
        bucket: Optional[str] = None,
        query: str = "",
        limit: int = 300,
        project: Optional[str] = None,
    ) -> List[sqlite3.Row]:
        sql = "SELECT * FROM artifacts"
        clauses: List[str] = []
        params: List[Any] = []
        if bucket:
            clauses.append("bucket=?")
            params.append(bucket)
        if project:
            clauses.append("project=?")
            params.append(project)
        if query.strip():
            q = f"%{query.strip()}%"
            clauses.append(
                "(title LIKE ? OR content LIKE ? OR source LIKE ? OR instructions LIKE ? OR project LIKE ?)"
            )
            params.extend([q, q, q, q, q])
        if clauses:
            sql += " WHERE " + " AND ".join(clauses)
        sql += " ORDER BY id DESC LIMIT ?"
        params.append(int(limit))
        return self.conn.execute(sql, params).fetchall()

    def get_artifact_meta(self, row: sqlite3.Row) -> Dict[str, Any]:
        return decode_json_field(row["meta_json"] or "{}", dict, {})

    def get_artifact_tags(self, row: sqlite3.Row) -> List[str]:
        return decode_json_field(row["tags_json"] or "[]", list, [])

    def get_artifact_provenance(self, row: sqlite3.Row) -> Dict[str, Any]:
        return decode_json_field(row["provenance_json"] or "{}", dict, {})

    def classify_artifact(self, text: str) -> str:
        value = (text or "").strip()
        if not value:
            return "note"
        if value.startswith("{") and (
            '"packet_type"' in value or '"project"' in value or '"WORKSHOP_LEDGER"' in value
        ):
            return "packet"
        if value.startswith("```") or "*** Begin Patch" in value or "diff --git" in value:
            return "patch"
        if (
            "Traceback (most recent call last)" in value
            or "SyntaxError" in value
            or "Exception:" in value
        ):
            return "bug_report"
        if "def " in value or "class " in value or "import " in value or "if __name__ ==" in value:
            return "python_file"
        if "hypothesis" in value.lower() or "theory" in value.lower():
            return "theory"
        if "TODO" in value or "next step" in value.lower() or "plan" in value.lower():
            return "analysis"
        return "note"

    def route_suggestion(self, artifact_type: str) -> str:
        mapping = {
            "python_file": "candidate",
            "patch": "candidate",
            "packet": "packet",
            "bug_report": "note",
            "analysis": "note",
            "theory": "note",
            "note": "inbox",
            "command": "note",
        }
        return mapping.get(artifact_type, "inbox")

    def summarize_artifact(self, row: Optional[sqlite3.Row], max_len: int = 140) -> Optional[Dict[str, Any]]:
        if not row:
            return None
        body = (row["content"] or "").replace("\n", " ").strip()
        if len(body) > max_len:
            body = body[: max_len - 3] + "..."
        provenance = self.get_artifact_provenance(row)
        return {
            "id": row["id"],
            "uuid": row["artifact_uuid"],
            "title": row["title"] or f"Artifact {row['id']}",
            "artifact_type": row["artifact_type"],
            "bucket": row["bucket"],
            "project": row["project"] or "",
            "summary": body,
            "source": row["source"] or "",
            "provenance": provenance,
        }

    def serialize_artifact(self, row: sqlite3.Row) -> Dict[str, Any]:
        return {
            "id": row["id"],  # local/debug only; UUID is portable identity.
            "artifact_uuid": row["artifact_uuid"],
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
            "title": row["title"],
            "artifact_type": row["artifact_type"],
            "bucket": row["bucket"],
            "content": row["content"],
            "source": row["source"],
            "instructions": row["instructions"],
            "tags": self.get_artifact_tags(row),
            "meta": self.get_artifact_meta(row),
            "project": row["project"] or "",
            "provenance": self.get_artifact_provenance(row),
        }

    # ----- version rail ------------------------------------------

    def version_rail(self) -> Dict[str, Any]:
        rail = default_version_rail()
        rail.update(self.get_setting("version_rail", {}) or {})
        rail["archive_uuids"] = list(dict.fromkeys(rail.get("archive_uuids", [])))
        return rail

    def set_candidate(self, artifact_id: int) -> None:
        row = self.get_artifact(artifact_id)
        if not row:
            raise ValueError("Artifact does not exist")
        auuid = row["artifact_uuid"]
        rail = self.version_rail()
        if rail.get("stable_uuid") == auuid:
            raise ValueError("Stable artifact cannot simultaneously be candidate")
        previous = rail.get("candidate_uuid")
        try:
            self.conn.execute("BEGIN")
            if previous and previous != auuid:
                prev_row = self.get_artifact_by_uuid(previous)
                if prev_row and prev_row["bucket"] == "candidate":
                    self._update_artifact_tx(previous, bucket="inbox")
            self._update_artifact_tx(auuid, bucket="candidate")
            rail["candidate_uuid"] = auuid
            rail["archive_uuids"] = [x for x in rail.get("archive_uuids", []) if x != auuid]
            self._set_setting_tx("version_rail", rail)
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        self.log("Candidate updated", details=f"id={artifact_id} uuid={auuid}")
        self._sync_ledger_rail()

    def set_stable_direct(self, artifact_id: int) -> None:
        row = self.get_artifact(artifact_id)
        if not row:
            raise ValueError("Artifact does not exist")
        new_stable = row["artifact_uuid"]
        rail = self.version_rail()
        old_stable = rail.get("stable_uuid")
        try:
            self.conn.execute("BEGIN")
            if old_stable and old_stable != new_stable:
                old_row = self.get_artifact_by_uuid(old_stable)
                if old_row:
                    self._update_artifact_tx(old_stable, bucket="archive")
                    archive = rail.setdefault("archive_uuids", [])
                    if old_stable not in archive:
                        archive.insert(0, old_stable)
            self._update_artifact_tx(new_stable, bucket="stable")
            rail["stable_uuid"] = new_stable
            if rail.get("candidate_uuid") == new_stable:
                rail["candidate_uuid"] = None
            rail["archive_uuids"] = [
                x for x in rail.get("archive_uuids", []) if x != new_stable
            ]
            self._set_setting_tx("version_rail", rail)
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        self.log("Stable updated", details=f"id={artifact_id} uuid={new_stable}")
        self._sync_ledger_rail()

    def promote_candidate_to_stable(self) -> tuple[bool, str]:
        rail = self.version_rail()
        candidate_uuid = rail.get("candidate_uuid")
        if not candidate_uuid:
            return False, "No candidate selected"
        row = self.get_artifact_by_uuid(candidate_uuid)
        if not row:
            return False, "Candidate reference is missing"
        self.set_stable_direct(row["id"])
        return True, f"Artifact {row['id']} promoted to stable"

    def archive_artifact(self, artifact_id: int, quiet: bool = False) -> None:
        row = self.get_artifact(artifact_id)
        if not row:
            raise ValueError("Artifact does not exist")
        auuid = row["artifact_uuid"]
        rail = self.version_rail()
        try:
            self.conn.execute("BEGIN")
            self._update_artifact_tx(auuid, bucket="archive")
            archive = rail.setdefault("archive_uuids", [])
            if auuid not in archive:
                archive.insert(0, auuid)
            if rail.get("candidate_uuid") == auuid:
                rail["candidate_uuid"] = None
            if rail.get("stable_uuid") == auuid:
                rail["stable_uuid"] = None
            self._set_setting_tx("version_rail", rail)
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        if not quiet:
            self.log("Artifact archived", details=f"id={artifact_id} uuid={auuid}")
        self._sync_ledger_rail()

    def validate_version_rail(self) -> Dict[str, Any]:
        rail = self.version_rail()
        problems: List[str] = []

        def check_ref(label: str, auuid: Any, expected_bucket: str) -> None:
            if not auuid:
                return
            row = self.get_artifact_by_uuid(auuid)
            if not row:
                problems.append(f"{label} UUID is missing: {auuid}")
            elif row["bucket"] != expected_bucket:
                problems.append(
                    f"{label} UUID {auuid} has bucket {row['bucket']!r}, expected {expected_bucket!r}"
                )

        check_ref("stable", rail.get("stable_uuid"), "stable")
        check_ref("candidate", rail.get("candidate_uuid"), "candidate")
        for auuid in rail.get("archive_uuids", []):
            check_ref("archive", auuid, "archive")

        if rail.get("stable_uuid") and rail.get("stable_uuid") == rail.get("candidate_uuid"):
            problems.append("Stable and candidate point to the same artifact UUID")

        tracked_stable = rail.get("stable_uuid")
        tracked_candidate = rail.get("candidate_uuid")
        for row in self.conn.execute("SELECT artifact_uuid, bucket FROM artifacts WHERE bucket IN ('stable','candidate')"):
            if row["bucket"] == "stable" and row["artifact_uuid"] != tracked_stable:
                problems.append(f"Untracked stable bucket: {row['artifact_uuid']}")
            if row["bucket"] == "candidate" and row["artifact_uuid"] != tracked_candidate:
                problems.append(f"Untracked candidate bucket: {row['artifact_uuid']}")

        return {"ok": not problems, "problems": problems, "rail": rail}

    # ----- workshop ledger ---------------------------------------

    def workshop_ledger(self) -> Dict[str, Any]:
        ledger = default_ledger()
        raw = self.get_setting("workshop_ledger", {}) or {}
        ledger.update(raw)
        ledger["schema"] = LEDGER_SCHEMA
        for key in (
            "files_examined",
            "what_changed",
            "unresolved",
            "possible_next_threads",
            "leave_alone",
            "notes",
        ):
            value = ledger.get(key, [])
            if isinstance(value, str):
                value = [line.strip() for line in value.splitlines() if line.strip()]
            ledger[key] = list(value) if isinstance(value, (list, tuple)) else []
        return ledger

    def set_workshop_ledger(self, value: Dict[str, Any], remember_previous: bool = True) -> None:
        previous = self.workshop_ledger()
        if remember_previous and previous.get("updated_at"):
            self.remember_ledger_snapshot(previous)
        ledger = default_ledger()
        ledger.update(value or {})
        ledger["schema"] = LEDGER_SCHEMA
        ledger["updated_at"] = now_iso()
        rail = self.version_rail()
        ledger["stable_artifact_uuid"] = rail.get("stable_uuid")
        ledger["candidate_artifact_uuid"] = rail.get("candidate_uuid")
        self.set_setting("workshop_ledger", ledger)

    def remember_ledger_snapshot(self, ledger: Optional[Dict[str, Any]] = None) -> None:
        ledger = dict(ledger or self.workshop_ledger())
        history = self.get_setting("ledger_history", []) or []
        if history and history[-1] == ledger:
            return
        history.append(ledger)
        self.set_setting("ledger_history", history[-100:])

    def _sync_ledger_rail(self) -> None:
        ledger = self.workshop_ledger()
        rail = self.version_rail()
        ledger["stable_artifact_uuid"] = rail.get("stable_uuid")
        ledger["candidate_artifact_uuid"] = rail.get("candidate_uuid")
        ledger["updated_at"] = now_iso()
        self.set_setting("workshop_ledger", ledger)

    def update_ledger(self, **changes: Any) -> Dict[str, Any]:
        ledger = self.workshop_ledger()
        ledger.update(changes)
        self.set_workshop_ledger(ledger)
        self.log("Workshop ledger updated", details=f"project={ledger.get('project','')}")
        return self.workshop_ledger()

    # ----- export / import ---------------------------------------

    def write_artifact_to_file(
        self, artifact_id: int, filename: Optional[str] = None, export_dir: Optional[Path] = None
    ) -> Optional[Path]:
        row = self.get_artifact(artifact_id)
        if not row:
            return None
        target_dir = Path(export_dir or EXPORT_DIR)
        ensure_dir(target_dir)
        title = row["title"] or f"artifact_{row['id']}"
        filename = filename or (safe_name(title) + detect_extension(row["artifact_type"]))
        path = target_dir / filename
        atomic_write_text(path, row["content"])
        rail = self.version_rail()
        rail["last_export_path"] = str(path)
        self.set_setting("version_rail", rail)
        self.log("Artifact exported to file", details=str(path))
        return path

    def export_bundle(self, export_dir: Optional[Path] = None) -> Path:
        target_dir = Path(export_dir or EXPORT_DIR)
        ensure_dir(target_dir)
        bundle_id = new_uuid()
        payload = {
            "schema": BUNDLE_SCHEMA,
            "bundle_id": bundle_id,
            "app": APP_NAME,
            "app_version": APP_VERSION,
            "exported_at": now_iso(),
            "version_rail": self.version_rail(),
            "workspace": self.get_setting("workspace", default_workspace()),
            "workshop_ledger": self.workshop_ledger(),
            "artifacts": [self.serialize_artifact(row) for row in self.list_artifacts(None, "", 100000)],
            "logs": [dict(row) for row in self.list_logs(250)],
        }
        path = target_dir / f"noe_workshop_bundle_{compact_stamp()}_{bundle_id[:8]}.json"
        atomic_write_json(path, payload)
        rail = self.version_rail()
        rail["last_export_path"] = str(path)
        self.set_setting("version_rail", rail)
        self.log("Bundle exported", details=str(path))
        return path

    def _import_artifact_fields(self, item: Dict[str, Any]) -> Dict[str, Any]:
        tags = item.get("tags")
        if tags is None:
            tags = decode_json_field(item.get("tags_json", []), list, [])
        meta = item.get("meta")
        if meta is None:
            meta = decode_json_field(item.get("meta_json", {}), dict, {})
        provenance = item.get("provenance")
        if provenance is None:
            provenance = decode_json_field(item.get("provenance_json", {}), dict, {})
        return {
            "title": item.get("title", ""),
            "artifact_type": item.get("artifact_type", "note"),
            "bucket": item.get("bucket", "inbox"),
            "content": item.get("content", ""),
            "source": item.get("source", ""),
            "instructions": item.get("instructions", ""),
            "tags": tags,
            "meta": meta,
            "project": item.get("project", ""),
            "provenance": provenance,
            "created_at": item.get("created_at"),
            "updated_at": item.get("updated_at"),
        }

    def import_bundle(self, filepath: Union[Path, str], mode: str = "merge") -> Dict[str, Any]:
        if mode not in ("merge", "replace"):
            raise ValueError("mode must be 'merge' or 'replace'")
        with open(filepath, "r", encoding="utf-8") as handle:
            payload = json.load(handle)
        if not isinstance(payload, dict):
            raise ValueError("Bundle root must be a JSON object")
        artifacts = payload.get("artifacts", [])
        if not isinstance(artifacts, list):
            raise ValueError("Bundle artifacts must be a list")

        old_id_to_uuid: Dict[int, str] = {}
        imported_uuid_map: Dict[str, str] = {}
        imported = 0
        skipped = 0

        current_rail = self.version_rail()
        current_workspace = self.get_setting("workspace", default_workspace())
        current_ledger = self.workshop_ledger()

        try:
            self.conn.execute("BEGIN")
            if mode == "replace":
                self.conn.execute("DELETE FROM artifacts")

            for item in artifacts:
                if not isinstance(item, dict):
                    raise ValueError("Every artifact in bundle must be an object")
                old_id = item.get("id")
                imported_uuid = str(item.get("artifact_uuid") or item.get("uuid") or "").strip()
                existing = self.get_artifact_by_uuid(imported_uuid) if imported_uuid else None
                if existing and mode == "merge":
                    actual_uuid = existing["artifact_uuid"]
                    skipped += 1
                else:
                    actual_uuid = imported_uuid or new_uuid()
                    fields = self._import_artifact_fields(item)
                    _new_id, actual_uuid = self._insert_artifact_tx(
                        fields["title"],
                        fields["artifact_type"],
                        fields["bucket"],
                        fields["content"],
                        fields["source"],
                        fields["instructions"],
                        fields["tags"],
                        fields["meta"],
                        fields["project"],
                        fields["provenance"],
                        actual_uuid,
                        fields["created_at"],
                        fields["updated_at"],
                    )
                    imported += 1
                if imported_uuid:
                    imported_uuid_map[imported_uuid] = actual_uuid
                try:
                    if old_id is not None:
                        old_id_to_uuid[int(old_id)] = actual_uuid
                except (TypeError, ValueError):
                    pass

            imported_rail_raw = payload.get("version_rail", {}) or {}

            def map_uuid(value: Any) -> Optional[str]:
                if not value:
                    return None
                text = str(value)
                mapped = imported_uuid_map.get(text, text)
                return mapped if self.get_artifact_by_uuid(mapped) else None

            def map_id(value: Any) -> Optional[str]:
                try:
                    return old_id_to_uuid.get(int(value))
                except (TypeError, ValueError):
                    return None

            imported_stable = map_uuid(imported_rail_raw.get("stable_uuid")) or map_id(
                imported_rail_raw.get("stable_id")
            )
            imported_candidate = map_uuid(imported_rail_raw.get("candidate_uuid")) or map_id(
                imported_rail_raw.get("candidate_id")
            )
            raw_archives = imported_rail_raw.get("archive_uuids")
            if raw_archives is None:
                raw_archives = imported_rail_raw.get("archive_ids", [])
                imported_archives = [u for u in (map_id(x) for x in raw_archives) if u]
            else:
                imported_archives = [u for u in (map_uuid(x) for x in raw_archives) if u]

            if mode == "replace":
                final_rail = default_version_rail()
                final_rail["stable_uuid"] = imported_stable
                final_rail["candidate_uuid"] = imported_candidate
                final_rail["archive_uuids"] = list(dict.fromkeys(imported_archives))
            else:
                final_rail = dict(current_rail)
                if not final_rail.get("stable_uuid"):
                    final_rail["stable_uuid"] = imported_stable
                if not final_rail.get("candidate_uuid"):
                    final_rail["candidate_uuid"] = imported_candidate
                final_rail["archive_uuids"] = list(
                    dict.fromkeys(final_rail.get("archive_uuids", []) + imported_archives)
                )

            # Make authoritative rail buckets agree with the restored rail.
            if final_rail.get("stable_uuid"):
                self._update_artifact_tx(final_rail["stable_uuid"], bucket="stable")
            if final_rail.get("candidate_uuid") and final_rail.get("candidate_uuid") != final_rail.get("stable_uuid"):
                self._update_artifact_tx(final_rail["candidate_uuid"], bucket="candidate")
            for auuid in final_rail.get("archive_uuids", []):
                if auuid not in (final_rail.get("stable_uuid"), final_rail.get("candidate_uuid")):
                    self._update_artifact_tx(auuid, bucket="archive")
            self._set_setting_tx("version_rail", final_rail)

            imported_ws = payload.get("workspace", {}) or {}
            selected_uuid = map_uuid(imported_ws.get("selected_artifact_uuid")) or map_id(
                imported_ws.get("selected_artifact_id")
            )
            if mode == "replace":
                final_ws = default_workspace()
                final_ws.update(imported_ws)
                final_ws["selected_artifact_uuid"] = selected_uuid
                final_ws.pop("selected_artifact_id", None)
            else:
                final_ws = dict(current_workspace)
                if not final_ws.get("selected_artifact_uuid"):
                    final_ws["selected_artifact_uuid"] = selected_uuid
            self._set_setting_tx("workspace", final_ws)

            imported_ledger = payload.get("workshop_ledger")
            if isinstance(imported_ledger, dict) and mode == "replace":
                final_ledger = default_ledger()
                final_ledger.update(imported_ledger)
                final_ledger["stable_artifact_uuid"] = final_rail.get("stable_uuid")
                final_ledger["candidate_artifact_uuid"] = final_rail.get("candidate_uuid")
                final_ledger["updated_at"] = now_iso()
                self._set_setting_tx("workshop_ledger", final_ledger)
            else:
                self._set_setting_tx("workshop_ledger", current_ledger)

            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise

        if isinstance(payload.get("workshop_ledger"), dict) and mode == "merge":
            self.remember_ledger_snapshot(payload["workshop_ledger"])
        self._sync_ledger_rail()
        self.log(
            "Bundle imported",
            details=f"path={filepath} mode={mode} imported={imported} skipped={skipped}",
        )
        return {
            "schema": payload.get("schema", "legacy-assistant-shell-bundle"),
            "mode": mode,
            "artifacts_imported": imported,
            "duplicates_skipped": skipped,
            "old_id_to_uuid": old_id_to_uuid,
            "uuid_map": imported_uuid_map,
            "version_rail": self.version_rail(),
        }

    # ----- packets / diagnostics ---------------------------------

    def build_session_packet(self) -> Dict[str, Any]:
        rail = self.version_rail()
        stable = self.get_artifact_by_uuid(rail.get("stable_uuid"))
        candidate = self.get_artifact_by_uuid(rail.get("candidate_uuid"))
        latest = self.latest_artifact()
        workspace = self.get_setting("workspace", default_workspace())
        return {
            "packet_type": "noe_workshop_session",
            "schema": "NOE_WORKSHOP_SESSION_V1",
            "project": workspace.get("active_project", "default"),
            "current_time": now_iso(),
            "node_status": workspace.get("status", "idle"),
            "next_action": workspace.get("next_action", ""),
            "stable": self.summarize_artifact(stable),
            "candidate": self.summarize_artifact(candidate),
            "latest_artifact": self.summarize_artifact(latest),
            "archive_count": len(rail.get("archive_uuids", [])),
            "workshop_ledger": self.workshop_ledger(),
            "recent_logs": [dict(row) for row in self.list_logs(10)],
        }

    def build_versions_packet(self) -> Dict[str, Any]:
        rail = self.version_rail()
        archive_rows = [
            self.get_artifact_by_uuid(x) for x in rail.get("archive_uuids", [])[:20]
        ]
        return {
            "packet_type": "noe_workshop_versions",
            "stable": self.summarize_artifact(self.get_artifact_by_uuid(rail.get("stable_uuid"))),
            "candidate": self.summarize_artifact(
                self.get_artifact_by_uuid(rail.get("candidate_uuid"))
            ),
            "archive": [self.summarize_artifact(row) for row in archive_rows if row],
        }

    def build_artifact_packet(self, artifact_id: int) -> Optional[Dict[str, Any]]:
        row = self.get_artifact(artifact_id)
        if not row:
            return None
        return {
            "packet_type": "noe_workshop_artifact",
            "artifact": self.serialize_artifact(row),
        }

    def build_workshop_packet(self) -> Dict[str, Any]:
        return {
            "packet_type": "workshop_ledger",
            "ledger": self.workshop_ledger(),
            "version_rail": self.version_rail(),
        }

    def diagnose(self) -> Dict[str, Any]:
        rail_report = self.validate_version_rail()
        ws = self.get_setting("workspace", default_workspace())
        problems = list(rail_report["problems"])
        selected = ws.get("selected_artifact_uuid")
        if selected and not self.get_artifact_by_uuid(selected):
            problems.append(f"Workspace selected artifact is missing: {selected}")
        rows_without_uuid = self.conn.execute(
            "SELECT COUNT(*) AS n FROM artifacts WHERE artifact_uuid IS NULL OR TRIM(artifact_uuid)=''"
        ).fetchone()["n"]
        if rows_without_uuid:
            problems.append(f"Artifacts without UUID: {rows_without_uuid}")
        return {
            "packet_type": "noe_workshop_diagnostics",
            "app_version": APP_VERSION,
            "db_schema_version": self.get_setting("db_schema_version"),
            "database": self.path,
            "artifact_count": self.conn.execute("SELECT COUNT(*) AS n FROM artifacts").fetchone()["n"],
            "version_rail": rail_report,
            "workspace": ws,
            "workshop_ledger": self.workshop_ledger(),
            "ok": not problems,
            "problems": problems,
        }


# --- UI helpers ----------------------------------------------------

BaseView = ui.View if UI_AVAILABLE else object


def panel(frame: tuple[float, float, float, float]):
    view = ui.View(frame=frame)
    view.background_color = THEME["panel"]
    view.border_width = 1
    view.border_color = THEME["border"]
    view.corner_radius = 12
    return view


def title_label(text: str, frame: tuple[float, float, float, float]):
    label = ui.Label(frame=frame)
    label.text = text
    label.font = FONT_TITLE
    label.text_color = THEME["text"]
    return label


def make_button(title: str, x: float, y: float, w: float, h: float, action: Any):
    button = ui.Button(title=title)
    button.frame = (x, y, w, h)
    button.action = action
    button.tint_color = THEME["accent"]
    button.border_width = 1
    button.border_color = THEME["border"]
    button.corner_radius = 9
    button.background_color = THEME["panel_2"]
    button.font = FONT_BODY
    return button


def style_tf(field: Any):
    field.border_width = 1
    field.border_color = THEME["border"]
    field.corner_radius = 9
    field.background_color = THEME["panel_2"]
    field.text_color = THEME["text"]
    field.tint_color = THEME["accent"]
    field.font = FONT_BODY
    return field


def style_tv(view: Any, mono: bool = False):
    view.border_width = 1
    view.border_color = THEME["border"]
    view.corner_radius = 9
    view.background_color = THEME["panel_2"]
    view.text_color = THEME["text"]
    view.tint_color = THEME["accent"]
    view.font = FONT_MONO if mono else FONT_BODY
    return view


class ArtifactListDS:
    def __init__(self, items: Iterable[sqlite3.Row], on_select: Any):
        self.items = list(items)
        self.on_select = on_select

    def tableview_number_of_rows(self, tableview: Any, section: int) -> int:
        return len(self.items)

    def tableview_cell_for_row(self, tableview: Any, section: int, row: int):
        item = self.items[row]
        cell = ui.TableViewCell("subtitle")
        cell.background_color = THEME["panel"]
        cell.text_label.text = item["title"] or f"Artifact {item['id']}"
        cell.text_label.text_color = THEME["text"]
        cell.detail_text_label.text = (
            f"#{item['id']} · {item['artifact_type']} · {item['bucket']} · {item['artifact_uuid'][:8]}"
        )
        cell.detail_text_label.text_color = THEME["muted"]
        cell.accessory_type = "disclosure_indicator"
        return cell

    def tableview_did_select(self, tableview: Any, section: int, row: int) -> None:
        self.on_select(self.items[row])


class ShellView(BaseView):
    def __init__(self, db_path: Path = DB_PATH):
        if not UI_AVAILABLE:
            raise RuntimeError("Pythonista ui/dialogs/console modules are not available")
        super().__init__(frame=(0, 0, 430, 760))
        self.db = DB(db_path)
        self.name = APP_NAME
        self.background_color = THEME["bg"]
        self.current_tab = "home"
        self.selected_artifact_id: Optional[int] = None
        self.current_packet_text = ""

        self.topbar = ui.View(frame=(0, 0, 430, 96))
        self.topbar.flex = "W"
        self.topbar.background_color = THEME["panel"]
        self.add_subview(self.topbar)

        self.title_lbl = ui.Label(frame=(12, 7, 240, 22))
        self.title_lbl.text = "NOE WORKSHOP"
        self.title_lbl.font = ("Menlo-Bold", 15)
        self.title_lbl.text_color = THEME["accent"]
        self.topbar.add_subview(self.title_lbl)

        self.status_lbl = ui.Label(frame=(270, 7, 145, 22))
        self.status_lbl.alignment = ui.ALIGN_RIGHT
        self.status_lbl.font = FONT_SMALL
        self.status_lbl.text_color = THEME["accent_2"]
        self.topbar.add_subview(self.status_lbl)

        self.tabs = ui.SegmentedControl(frame=(8, 48, 414, 34))
        self.tabs.segments = ["Home", "Dock", "Artifacts", "Versions", "Workshop", "Packets", "Logs"]
        self.tabs.selected_index = 0
        self.tabs.action = self.switch_tab
        self.tabs.tint_color = THEME["accent"]
        self.topbar.add_subview(self.tabs)

        self.home_view = self.build_home_view()
        self.dock_view = self.build_dock_view()
        self.artifacts_view = self.build_artifacts_view()
        self.versions_view = self.build_versions_view()
        self.workshop_view = self.build_workshop_view()
        self.packets_view = self.build_packets_view()
        self.logs_view = self.build_logs_view()
        self.views = {
            "home": self.home_view,
            "dock": self.dock_view,
            "artifacts": self.artifacts_view,
            "versions": self.versions_view,
            "workshop": self.workshop_view,
            "packets": self.packets_view,
            "logs": self.logs_view,
        }
        for view in self.views.values():
            view.frame = (0, 96, 430, 664)
            view.flex = "WH"
            self.add_subview(view)
        self.show_tab("home")
        self.refresh_all()

    def layout(self) -> None:
        self.topbar.width = self.width
        self.tabs.width = self.width - 16
        for view in self.views.values():
            view.frame = (0, 96, self.width, self.height - 96)

    def switch_tab(self, sender: Any) -> None:
        name = self.tabs.segments[self.tabs.selected_index].lower()
        self.show_tab(name)

    def show_tab(self, name: str) -> None:
        self.current_tab = name
        for key, view in self.views.items():
            view.hidden = key != name
        self.refresh_current()

    def refresh_status(self) -> None:
        ws = self.db.get_setting("workspace", default_workspace())
        self.status_lbl.text = ws.get("status", "idle").upper()
        self.status_lbl.text_color = (
            THEME["accent_2"] if ws.get("status") in ("idle", "stable", "resting") else THEME["warn"]
        )

    def set_workspace_status(self, status: str, next_action: Optional[str] = None) -> None:
        ws = self.db.get_setting("workspace", default_workspace())
        ws["status"] = status
        if next_action is not None:
            ws["next_action"] = next_action
        self.db.set_setting("workspace", ws)

    def refresh_all(self) -> None:
        self.refresh_status()
        self.refresh_home()
        self.refresh_dock_hint()
        self.refresh_artifacts()
        self.refresh_versions()
        self.refresh_workshop()
        self.refresh_packets()
        self.refresh_logs()

    def refresh_current(self) -> None:
        self.refresh_status()
        mapping = {
            "home": self.refresh_home,
            "dock": self.refresh_dock_hint,
            "artifacts": self.refresh_artifacts,
            "versions": self.refresh_versions,
            "workshop": self.refresh_workshop,
            "packets": self.refresh_packets,
            "logs": self.refresh_logs,
        }
        mapping[self.current_tab]()

    def make_card(self, parent: Any, x: float, y: float, w: float, h: float, title: str, accent: Optional[str] = None):
        box = panel((x, y, w, h))
        parent.add_subview(box)
        header = ui.Label(frame=(12, 8, w - 24, 22))
        header.text = title
        header.font = FONT_SUBTITLE
        header.text_color = accent or THEME["accent"]
        box.add_subview(header)
        return box

    def artifact_summary_lines(self, row: Optional[sqlite3.Row]) -> List[str]:
        if not row:
            return ["(none)"]
        tags = self.db.get_artifact_tags(row)
        summary = (row["content"] or "").replace("\n", " ").strip()
        if len(summary) > 90:
            summary = summary[:87] + "..."
        lines = [
            row["title"] or f"Artifact {row['id']}",
            f"#{row['id']} · {row['artifact_type']} · {row['bucket']} · {row['artifact_uuid'][:8]}",
        ]
        if tags:
            lines.append("tags: " + ", ".join(tags[:4]))
        lines.append(summary or "(empty)")
        return lines

    # ----- home ---------------------------------------------------

    def build_home_view(self):
        return ui.ScrollView(background_color=THEME["bg"])

    def refresh_home(self) -> None:
        sv = self.home_view
        for sub in list(sv.subviews):
            sv.remove_subview(sub)
        rail = self.db.version_rail()
        ws = self.db.get_setting("workspace", default_workspace())
        ledger = self.db.workshop_ledger()
        stable = self.db.get_artifact_by_uuid(rail.get("stable_uuid"))
        candidate = self.db.get_artifact_by_uuid(rail.get("candidate_uuid"))
        latest = self.db.latest_artifact()
        width = max(406, sv.width - 24)
        y = 12
        sv.add_subview(title_label("Symbiosis Lab", (12, y, width, 30)))
        y += 36

        box = self.make_card(sv, 12, y, width, 116, "Next Move", THEME["accent_2"])
        label = ui.Label(frame=(12, 36, width - 24, 38))
        label.number_of_lines = 2
        label.font = FONT_BODY
        label.text_color = THEME["text"]
        label.text = ws.get("next_action", "Paste an artifact into the dock.")
        box.add_subview(label)
        box.add_subview(make_button("Dock", 12, 80, 62, 26, self.home_open_dock))
        box.add_subview(make_button("Workshop", 82, 80, 88, 26, self.home_open_workshop))
        box.add_subview(make_button("Copy Session", 178, 80, 104, 26, self.copy_session_packet))
        box.add_subview(make_button("Export", 290, 80, 72, 26, self.export_bundle_ui))
        y += 128

        work = self.make_card(sv, 12, y, width, 112, "Workshop Thread")
        text = ui.Label(frame=(12, 36, width - 24, 62))
        text.number_of_lines = 4
        text.font = FONT_SMALL
        text.text_color = THEME["text"]
        text.text = (
            f"{ledger.get('project') or '(no project)'} · {ledger.get('status','resting')}\n"
            f"repo: {ledger.get('repository') or '-'}\n"
            f"path: {ledger.get('path') or '-'}\n"
            f"next: {(ledger.get('possible_next_threads') or ['(none)'])[0]}"
        )
        work.add_subview(text)
        y += 124

        for title, row in (("Stable Rail", stable), ("Candidate Rail", candidate), ("Latest Ingest", latest)):
            box = self.make_card(sv, 12, y, width, 106, title)
            yy = 36
            for index, line in enumerate(self.artifact_summary_lines(row)[:4]):
                label = ui.Label(frame=(12, yy, width - 24, 18))
                label.text = line
                label.font = FONT_BODY if index == 0 else FONT_SMALL
                label.text_color = THEME["text"] if index in (0, 3) else THEME["muted"]
                box.add_subview(label)
                yy += 18
            y += 118
        sv.content_size = (sv.width, y + 16)

    def home_open_dock(self, sender: Any) -> None:
        self.tabs.selected_index = 1
        self.show_tab("dock")

    def home_open_workshop(self, sender: Any) -> None:
        self.tabs.selected_index = 4
        self.show_tab("workshop")

    # ----- dock ---------------------------------------------------

    def build_dock_view(self):
        view = ui.ScrollView(background_color=THEME["bg"])
        view.add_subview(title_label("Artifact Dock", (12, 10, 260, 28)))
        view.title_tf = style_tf(ui.TextField(frame=(12, 46, 196, 32)))
        view.title_tf.placeholder = "Artifact title"
        view.add_subview(view.title_tf)
        view.project_tf = style_tf(ui.TextField(frame=(216, 46, 192, 32)))
        view.project_tf.placeholder = "Project"
        view.add_subview(view.project_tf)
        view.source_tf = style_tf(ui.TextField(frame=(12, 86, 396, 32)))
        view.source_tf.placeholder = "Source"
        view.add_subview(view.source_tf)
        view.instructions_tf = style_tf(ui.TextField(frame=(12, 126, 396, 32)))
        view.instructions_tf.placeholder = "Instruction / intent"
        view.add_subview(view.instructions_tf)
        view.tags_tf = style_tf(ui.TextField(frame=(12, 166, 396, 32)))
        view.tags_tf.placeholder = "Tags (comma separated)"
        view.add_subview(view.tags_tf)
        view.content_tv = style_tv(ui.TextView(frame=(12, 206, 396, 220)), mono=True)
        view.add_subview(view.content_tv)
        view.detect_lbl = ui.Label(frame=(12, 434, 396, 18))
        view.detect_lbl.font = FONT_SMALL
        view.detect_lbl.text_color = THEME["muted"]
        view.add_subview(view.detect_lbl)
        view.bucket_seg = ui.SegmentedControl(frame=(12, 460, 306, 32))
        view.bucket_seg.segments = ["inbox", "candidate", "stable", "note", "packet"]
        view.bucket_seg.selected_index = 0
        view.bucket_seg.tint_color = THEME["accent"]
        view.add_subview(view.bucket_seg)
        view.add_subview(make_button("Detect", 326, 460, 82, 32, self.detect_artifact))
        view.add_subview(make_button("Store", 12, 504, 76, 30, self.store_dock_artifact))
        view.add_subview(make_button("Candidate", 96, 504, 96, 30, self.store_candidate_shortcut))
        view.add_subview(make_button("Stable", 200, 504, 76, 30, self.store_stable_shortcut))
        view.add_subview(make_button("Clear", 284, 504, 70, 30, self.clear_dock))
        view.hint = ui.Label(frame=(12, 548, 396, 70))
        view.hint.number_of_lines = 4
        view.hint.text_color = THEME["text"]
        view.hint.font = FONT_SMALL
        view.add_subview(view.hint)
        view.content_size = (430, 640)
        return view

    def refresh_dock_hint(self) -> None:
        text = self.dock_view.content_tv.text.strip()
        if not text:
            self.dock_view.detect_lbl.text = "Paste a script, patch, packet, note, bug report, or theory."
            self.dock_view.hint.text = "The dock classifies pasted work but you remain free to override its route."
            return
        kind = self.db.classify_artifact(text)
        suggestion = self.db.route_suggestion(kind)
        self.dock_view.detect_lbl.text = f"Detected: {kind} · suggested: {suggestion}"
        self.dock_view.hint.text = (
            f"This looks like {kind}. Suggested destination: {suggestion}. "
            "Project and provenance can be filled later from the Workshop ledger."
        )

    def detect_artifact(self, sender: Any) -> None:
        self.refresh_dock_hint()
        console.hud_alert("Artifact scanned")

    def selected_bucket(self) -> str:
        seg = self.dock_view.bucket_seg
        return seg.segments[seg.selected_index]

    def clear_dock(self, sender: Any) -> None:
        for field in (
            self.dock_view.title_tf,
            self.dock_view.project_tf,
            self.dock_view.source_tf,
            self.dock_view.instructions_tf,
            self.dock_view.tags_tf,
        ):
            field.text = ""
        self.dock_view.content_tv.text = ""
        self.refresh_dock_hint()
        self.set_workspace_status("idle", "Paste an artifact into the dock.")

    def store_dock_artifact(self, sender: Any) -> None:
        self._store_dock_artifact(self.selected_bucket())

    def store_candidate_shortcut(self, sender: Any) -> None:
        self._store_dock_artifact("candidate")

    def store_stable_shortcut(self, sender: Any) -> None:
        self._store_dock_artifact("stable")

    def _store_dock_artifact(self, bucket: str) -> None:
        content = self.dock_view.content_tv.text
        if not content.strip():
            console.hud_alert("Dock is empty", "error")
            return
        detected = self.db.classify_artifact(content)
        title = self.dock_view.title_tf.text.strip() or f"{detected}_{compact_stamp()}"
        ledger = self.db.workshop_ledger()
        project = self.dock_view.project_tf.text.strip() or ledger.get("project", "")
        provenance = {
            "repository": ledger.get("repository", ""),
            "path": ledger.get("path", ""),
            "commit": ledger.get("commit", ""),
            "blob": ledger.get("blob", ""),
        }
        aid = self.db.add_artifact(
            title=title,
            artifact_type=detected,
            bucket=bucket,
            content=content,
            source=self.dock_view.source_tf.text,
            instructions=self.dock_view.instructions_tf.text,
            tags=self.dock_view.tags_tf.text,
            meta={"detected_type": detected, "stored_via": "dock"},
            project=project,
            provenance=provenance,
        )
        if bucket == "candidate":
            self.db.set_candidate(aid)
            self.set_workspace_status("staged", "Review the candidate rail or promote when ready.")
        elif bucket == "stable":
            self.db.set_stable_direct(aid)
            self.set_workspace_status("stable", "Stable rail updated. Export or continue naturally.")
        else:
            self.set_workspace_status("idle", f"Artifact #{aid} stored in {bucket}.")
        row = self.db.get_artifact(aid)
        ws = self.db.get_setting("workspace", default_workspace())
        ws["selected_artifact_uuid"] = row["artifact_uuid"] if row else None
        self.db.set_setting("workspace", ws)
        self.selected_artifact_id = aid
        self.refresh_all()
        console.hud_alert(f"Stored #{aid}")
        self.tabs.selected_index = 3
        self.show_tab("versions")

    # ----- artifacts ---------------------------------------------

    def build_artifacts_view(self):
        view = ui.View(background_color=THEME["bg"])
        view.add_subview(title_label("Artifacts", (12, 10, 200, 28)))
        view.search_tf = style_tf(ui.TextField(frame=(12, 48, 176, 32)))
        view.search_tf.placeholder = "Search"
        view.search_tf.action = self.refresh_artifacts
        view.add_subview(view.search_tf)
        view.filter_seg = ui.SegmentedControl(frame=(196, 48, 212, 32))
        view.filter_seg.segments = ["all", "candidate", "stable", "archive", "packet"]
        view.filter_seg.selected_index = 0
        view.filter_seg.action = self.refresh_artifacts
        view.filter_seg.tint_color = THEME["accent"]
        view.add_subview(view.filter_seg)
        view.table = ui.TableView(frame=(12, 90, 184, 472))
        view.add_subview(view.table)
        view.detail = style_tv(ui.TextView(frame=(204, 90, 204, 392)), mono=True)
        view.detail.editable = False
        view.add_subview(view.detail)
        view.add_subview(make_button("Copy pkt", 204, 492, 84, 30, self.copy_selected_packet))
        view.add_subview(make_button("Export", 296, 492, 70, 30, self.export_selected_artifact))
        view.add_subview(make_button("Archive", 204, 530, 84, 30, self.archive_selected_artifact))
        view.add_subview(make_button("Candidate", 296, 530, 84, 30, self.make_selected_candidate))
        return view

    def refresh_artifacts(self, sender: Any = None) -> None:
        query = self.artifacts_view.search_tf.text.strip()
        seg = self.artifacts_view.filter_seg
        bucket = seg.segments[seg.selected_index]
        rows = self.db.list_artifacts(None if bucket == "all" else bucket, query, 300)
        ds = ArtifactListDS(rows, self.select_artifact)
        self.artifacts_view._ds = ds
        self.artifacts_view.table.data_source = ds
        self.artifacts_view.table.delegate = ds
        self.artifacts_view.table.reload()
        if rows:
            self.select_artifact(rows[0])
        else:
            self.artifacts_view.detail.text = "(no artifacts)"

    def select_artifact(self, row: sqlite3.Row) -> None:
        self.selected_artifact_id = row["id"]
        ws = self.db.get_setting("workspace", default_workspace())
        ws["selected_artifact_uuid"] = row["artifact_uuid"]
        self.db.set_setting("workspace", ws)
        tags = self.db.get_artifact_tags(row)
        meta = self.db.get_artifact_meta(row)
        prov = self.db.get_artifact_provenance(row)
        display_title = row['title'] or f"Artifact {row['id']}"
        lines = [
            f"Title: {display_title}",
            f"Local ID: {row['id']}",
            f"UUID: {row['artifact_uuid']}",
            f"Type: {row['artifact_type']}",
            f"Bucket: {row['bucket']}",
            f"Project: {row['project'] or '-'}",
            f"Source: {row['source'] or '-'}",
            f"Updated: {row['updated_at']}",
            f"Tags: {', '.join(tags) if tags else '-'}",
            "",
            "Provenance:",
            json_text(prov),
            "",
            "Instructions:",
            row["instructions"] or "-",
            "",
            "Meta:",
            json_text(meta),
            "",
            "Content:",
            row["content"] or "",
        ]
        self.artifacts_view.detail.text = "\n".join(lines)

    def require_selected_artifact(self) -> Optional[sqlite3.Row]:
        if not self.selected_artifact_id:
            console.hud_alert("Select an artifact first", "error")
            return None
        row = self.db.get_artifact(self.selected_artifact_id)
        if not row:
            console.hud_alert("Artifact missing", "error")
            return None
        return row

    def copy_selected_packet(self, sender: Any) -> None:
        row = self.require_selected_artifact()
        if not row:
            return
        console.set_clipboard(json_text(self.db.build_artifact_packet(row["id"])))
        console.hud_alert("Packet copied")

    def export_selected_artifact(self, sender: Any) -> None:
        row = self.require_selected_artifact()
        if not row:
            return
        path = self.db.write_artifact_to_file(row["id"])
        if path:
            self.set_workspace_status("idle", f"Exported {path.name}")
            self.refresh_all()
            console.hud_alert("Exported")
            dialogs.share_text(str(path))

    def archive_selected_artifact(self, sender: Any) -> None:
        row = self.require_selected_artifact()
        if not row:
            return
        self.db.archive_artifact(row["id"])
        self.set_workspace_status("idle", "Selected artifact archived.")
        self.refresh_all()
        console.hud_alert("Archived")

    def make_selected_candidate(self, sender: Any) -> None:
        row = self.require_selected_artifact()
        if not row:
            return
        try:
            self.db.set_candidate(row["id"])
        except ValueError as exc:
            console.hud_alert(str(exc), "error")
            return
        self.set_workspace_status("staged", "Selected artifact set as candidate.")
        self.refresh_all()
        console.hud_alert("Candidate set")

    # ----- versions ----------------------------------------------

    def build_versions_view(self):
        return ui.ScrollView(background_color=THEME["bg"])

    def refresh_versions(self) -> None:
        sv = self.versions_view
        for sub in list(sv.subviews):
            sv.remove_subview(sub)
        rail = self.db.version_rail()
        stable = self.db.get_artifact_by_uuid(rail.get("stable_uuid"))
        candidate = self.db.get_artifact_by_uuid(rail.get("candidate_uuid"))
        archives = [self.db.get_artifact_by_uuid(x) for x in rail.get("archive_uuids", [])[:12]]
        archives = [row for row in archives if row]
        width = max(406, sv.width - 24)
        y = 12
        report = self.db.validate_version_rail()
        status = self.make_card(sv, 12, y, width, 70, "Rail Integrity", THEME["accent_2"] if report["ok"] else THEME["warn"])
        label = ui.Label(frame=(12, 36, width - 24, 22))
        label.text = "OK" if report["ok"] else "; ".join(report["problems"][:2])
        label.text_color = THEME["text"]
        label.font = FONT_SMALL
        status.add_subview(label)
        y += 82
        for title, row, accent in (
            ("Stable Rail", stable, THEME["accent_2"]),
            ("Candidate Rail", candidate, THEME["accent"]),
        ):
            box = self.make_card(sv, 12, y, width, 132, title, accent)
            yy = 36
            for index, line in enumerate(self.artifact_summary_lines(row)[:4]):
                label = ui.Label(frame=(12, yy, width - 24, 18))
                label.text = line
                label.font = FONT_BODY if index == 0 else FONT_SMALL
                label.text_color = THEME["text"] if index in (0, 3) else THEME["muted"]
                box.add_subview(label)
                yy += 18
            if row:
                open_btn = make_button("Open", 12, 98, 58, 24, self.version_open)
                open_btn.artifact_id = row["id"]
                box.add_subview(open_btn)
                export_btn = make_button("Export", 76, 98, 68, 24, self.version_export)
                export_btn.artifact_id = row["id"]
                box.add_subview(export_btn)
                if title == "Candidate Rail":
                    box.add_subview(make_button("Promote", 150, 98, 78, 24, self.promote_candidate))
                    archive_btn = make_button("Archive", 234, 98, 76, 24, self.version_archive)
                    archive_btn.artifact_id = row["id"]
                    box.add_subview(archive_btn)
            y += 144
        height = max(110, 46 + len(archives) * 22)
        box = self.make_card(sv, 12, y, width, height, "Archive")
        if archives:
            yy = 38
            for row in archives:
                label = ui.Label(frame=(12, yy, width - 24, 18))
                label.text = f"#{row['id']} · {row['artifact_uuid'][:8]} · {row['title'] or 'Artifact'}"
                label.font = FONT_SMALL
                label.text_color = THEME["text"]
                box.add_subview(label)
                yy += 22
        else:
            label = ui.Label(frame=(12, 42, width - 24, 20))
            label.text = "(archive empty)"
            label.text_color = THEME["muted"]
            box.add_subview(label)
        y += height + 12
        sv.content_size = (sv.width, y + 16)

    def version_open(self, sender: Any) -> None:
        row = self.db.get_artifact(sender.artifact_id)
        if row:
            self.select_artifact(row)
            self.tabs.selected_index = 2
            self.show_tab("artifacts")

    def version_export(self, sender: Any) -> None:
        row = self.db.get_artifact(sender.artifact_id)
        if row:
            path = self.db.write_artifact_to_file(row["id"])
            if path:
                dialogs.share_text(str(path))

    def version_archive(self, sender: Any) -> None:
        self.db.archive_artifact(sender.artifact_id)
        self.set_workspace_status("idle", "Candidate archived.")
        self.refresh_all()
        console.hud_alert("Archived")

    def promote_candidate(self, sender: Any) -> None:
        ok, message = self.db.promote_candidate_to_stable()
        if ok:
            self.set_workspace_status("stable", "Candidate promoted to stable.")
        self.refresh_all()
        console.hud_alert(message, "success" if ok else "error")

    # ----- workshop ----------------------------------------------

    def build_workshop_view(self):
        view = ui.ScrollView(background_color=THEME["bg"])
        view.add_subview(title_label("Workshop Ledger", (12, 10, 260, 28)))
        view.project_tf = style_tf(ui.TextField(frame=(12, 48, 190, 32)))
        view.project_tf.placeholder = "Project"
        view.add_subview(view.project_tf)
        view.status_tf = style_tf(ui.TextField(frame=(210, 48, 198, 32)))
        view.status_tf.placeholder = "Status: resting / active / stable"
        view.add_subview(view.status_tf)
        view.repo_tf = style_tf(ui.TextField(frame=(12, 88, 396, 32)))
        view.repo_tf.placeholder = "Repository (owner/name)"
        view.add_subview(view.repo_tf)
        view.path_tf = style_tf(ui.TextField(frame=(12, 128, 396, 32)))
        view.path_tf.placeholder = "Repository path"
        view.add_subview(view.path_tf)
        view.commit_tf = style_tf(ui.TextField(frame=(12, 168, 396, 32)))
        view.commit_tf.placeholder = "Commit"
        view.add_subview(view.commit_tf)
        view.blob_tf = style_tf(ui.TextField(frame=(12, 208, 396, 32)))
        view.blob_tf.placeholder = "Blob"
        view.add_subview(view.blob_tf)

        def labeled_tv(label_text: str, y: int):
            label = ui.Label(frame=(12, y, 180, 18))
            label.text = label_text
            label.font = FONT_SMALL
            label.text_color = THEME["accent"]
            view.add_subview(label)
            tv = style_tv(ui.TextView(frame=(12, y + 20, 396, 78)))
            view.add_subview(tv)
            return tv

        view.changed_tv = labeled_tv("What changed — one item per line", 250)
        view.unresolved_tv = labeled_tv("Unresolved", 356)
        view.next_tv = labeled_tv("Possible next threads", 462)
        view.notes_tv = labeled_tv("Notes / leave-alone boundary", 568)
        view.add_subview(make_button("Save Ledger", 12, 674, 104, 32, self.save_workshop_ledger))
        view.add_subview(make_button("Copy Ledger", 124, 674, 104, 32, self.copy_workshop_ledger))
        view.add_subview(make_button("Rest", 236, 674, 72, 32, self.rest_workshop))
        view.add_subview(make_button("Diagnose", 316, 674, 92, 32, self.copy_diagnostics))
        view.content_size = (430, 724)
        return view

    @staticmethod
    def _lines(text: str) -> List[str]:
        return [line.strip() for line in (text or "").splitlines() if line.strip()]

    def refresh_workshop(self) -> None:
        ledger = self.db.workshop_ledger()
        view = self.workshop_view
        view.project_tf.text = ledger.get("project", "")
        view.status_tf.text = ledger.get("status", "resting")
        view.repo_tf.text = ledger.get("repository", "")
        view.path_tf.text = ledger.get("path", "")
        view.commit_tf.text = ledger.get("commit", "")
        view.blob_tf.text = ledger.get("blob", "")
        view.changed_tv.text = "\n".join(ledger.get("what_changed", []))
        view.unresolved_tv.text = "\n".join(ledger.get("unresolved", []))
        view.next_tv.text = "\n".join(ledger.get("possible_next_threads", []))
        note_lines = list(ledger.get("notes", []))
        if ledger.get("leave_alone"):
            note_lines += ["LEAVE ALONE: " + x for x in ledger.get("leave_alone", [])]
        view.notes_tv.text = "\n".join(note_lines)

    def save_workshop_ledger(self, sender: Any) -> None:
        old = self.db.workshop_ledger()
        raw_notes = self._lines(self.workshop_view.notes_tv.text)
        leave_alone = [line[len("LEAVE ALONE:") :].strip() for line in raw_notes if line.startswith("LEAVE ALONE:")]
        notes = [line for line in raw_notes if not line.startswith("LEAVE ALONE:")]
        ledger = dict(old)
        ledger.update(
            {
                "project": self.workshop_view.project_tf.text.strip(),
                "status": self.workshop_view.status_tf.text.strip() or "resting",
                "repository": self.workshop_view.repo_tf.text.strip(),
                "path": self.workshop_view.path_tf.text.strip(),
                "commit": self.workshop_view.commit_tf.text.strip(),
                "blob": self.workshop_view.blob_tf.text.strip(),
                "what_changed": self._lines(self.workshop_view.changed_tv.text),
                "unresolved": self._lines(self.workshop_view.unresolved_tv.text),
                "possible_next_threads": self._lines(self.workshop_view.next_tv.text),
                "notes": notes,
                "leave_alone": leave_alone,
            }
        )
        self.db.set_workshop_ledger(ledger)
        ws = self.db.get_setting("workspace", default_workspace())
        ws["active_project"] = ledger.get("project") or ws.get("active_project", "default")
        if ledger.get("possible_next_threads"):
            ws["next_action"] = ledger["possible_next_threads"][0]
        ws["status"] = ledger.get("status", "resting")
        self.db.set_setting("workspace", ws)
        self.db.log("Workshop ledger saved", details=ledger.get("project", ""))
        self.refresh_all()
        console.hud_alert("Ledger saved")

    def copy_workshop_ledger(self, sender: Any) -> None:
        console.set_clipboard(json_text(self.db.build_workshop_packet()))
        console.hud_alert("Workshop ledger copied")

    def rest_workshop(self, sender: Any) -> None:
        ledger = self.db.workshop_ledger()
        ledger["status"] = "resting"
        self.db.set_workshop_ledger(ledger)
        self.set_workspace_status("resting", "Resume when a thread feels naturally worthwhile.")
        self.refresh_all()
        console.hud_alert("Workshop resting")

    def copy_diagnostics(self, sender: Any) -> None:
        report = self.db.diagnose()
        console.set_clipboard(json_text(report))
        console.hud_alert("Diagnostics copied", "success" if report["ok"] else "error")

    # ----- packets -----------------------------------------------

    def build_packets_view(self):
        view = ui.View(background_color=THEME["bg"])
        view.add_subview(title_label("Packets", (12, 10, 180, 28)))
        view.kind_seg = ui.SegmentedControl(frame=(12, 48, 396, 32))
        view.kind_seg.segments = ["session", "versions", "selected", "workshop", "diagnose"]
        view.kind_seg.selected_index = 0
        view.kind_seg.action = self.refresh_packets
        view.kind_seg.tint_color = THEME["accent"]
        view.add_subview(view.kind_seg)
        view.add_subview(make_button("Copy", 12, 88, 72, 30, self.copy_packet_button))
        view.add_subview(make_button("Save", 92, 88, 72, 30, self.save_packet_button))
        view.preview = style_tv(ui.TextView(frame=(12, 128, 396, 438)), mono=True)
        view.preview.editable = False
        view.add_subview(view.preview)
        return view

    def refresh_packets(self, sender: Any = None) -> None:
        kind = self.packets_view.kind_seg.segments[self.packets_view.kind_seg.selected_index]
        if kind == "session":
            payload = self.db.build_session_packet()
        elif kind == "versions":
            payload = self.db.build_versions_packet()
        elif kind == "workshop":
            payload = self.db.build_workshop_packet()
        elif kind == "diagnose":
            payload = self.db.diagnose()
        else:
            payload = (
                self.db.build_artifact_packet(self.selected_artifact_id)
                if self.selected_artifact_id
                else {"packet_type": "noe_workshop_artifact", "error": "No artifact selected"}
            )
        self.current_packet_text = json_text(payload)
        self.packets_view.preview.text = self.current_packet_text

    def copy_packet_button(self, sender: Any) -> None:
        if not self.current_packet_text:
            self.refresh_packets()
        console.set_clipboard(self.current_packet_text)
        self.db.log("Packet copied")
        self.refresh_logs()
        console.hud_alert("Packet copied")

    def save_packet_button(self, sender: Any) -> None:
        if not self.current_packet_text:
            self.refresh_packets()
        kind = self.packets_view.kind_seg.segments[self.packets_view.kind_seg.selected_index]
        path = EXPORT_DIR / f"{kind}_packet_{compact_stamp()}_{new_uuid()[:8]}.json"
        atomic_write_text(path, self.current_packet_text + "\n")
        self.db.log("Packet saved", details=str(path))
        self.refresh_logs()
        console.hud_alert("Packet saved")
        dialogs.share_text(str(path))

    def copy_session_packet(self, sender: Any) -> None:
        console.set_clipboard(json_text(self.db.build_session_packet()))
        self.db.log("Session packet copied")
        self.refresh_logs()
        console.hud_alert("Session packet copied")

    def export_bundle_ui(self, sender: Any) -> None:
        path = self.db.export_bundle()
        self.set_workspace_status("idle", f"Bundle exported: {path.name}")
        self.refresh_all()
        console.hud_alert("Bundle exported")
        dialogs.share_text(str(path))

    # ----- logs ---------------------------------------------------

    def build_logs_view(self):
        view = ui.View(background_color=THEME["bg"])
        view.add_subview(title_label("Logs", (12, 10, 160, 28)))
        view.add_subview(make_button("Refresh", 328, 10, 80, 32, self.refresh_logs))
        view.text = style_tv(ui.TextView(frame=(12, 52, 396, 514)), mono=True)
        view.text.editable = False
        view.add_subview(view.text)
        return view

    def refresh_logs(self, sender: Any = None) -> None:
        lines: List[str] = []
        for row in self.db.list_logs(120):
            lines.append(f"[{row['created_at']}] {row['level'].upper()}  {row['message']}")
            if row["details"]:
                lines.append(f"  {row['details']}")
            lines.append("")
        self.logs_view.text.text = "\n".join(lines) if lines else "(no logs yet)"


# --- self-test / CLI ----------------------------------------------


def run_self_test() -> Dict[str, Any]:
    results: List[str] = []
    with tempfile.TemporaryDirectory(prefix="noe_workshop_test_") as td:
        root = Path(td)
        source = DB(root / "source.db")
        try:
            a_id = source.add_artifact(
                "v1",
                "python_file",
                "candidate",
                'print("v1")',
                tags=["python", "bridge"],
                meta={"generation": 1},
                project="Test",
                provenance={"repository": "levelinglucy/test", "path": "v1.py", "commit": "abc"},
            )
            source.set_candidate(a_id)
            source.set_stable_direct(a_id)
            a = source.get_artifact(a_id)

            b_id = source.add_artifact(
                "v2",
                "python_file",
                "candidate",
                'print("v2")',
                tags=["python", "candidate"],
                meta={"generation": 2},
                project="Test",
            )
            source.set_candidate(b_id)
            ok, _ = source.promote_candidate_to_stable()
            assert ok
            b = source.get_artifact(b_id)
            rail = source.version_rail()
            assert rail["stable_uuid"] == b["artifact_uuid"]
            assert a["artifact_uuid"] in rail["archive_uuids"]
            assert source.get_artifact_by_uuid(a["artifact_uuid"])["bucket"] == "archive"
            results.append("stable promotion preserves archive history")

            source.update_ledger(
                project="Test",
                repository="levelinglucy/test",
                path="v2.py",
                commit="def",
                blob="123",
                status="stable",
                what_changed=["promoted v2"],
                unresolved=["none"],
                possible_next_threads=["rest"],
            )
            bundle = source.export_bundle(root)
            results.append("bundle export is schema-versioned and atomic")

            target = DB(root / "target.db")
            try:
                # Advance target local IDs so UUID-vs-ID restoration is tested.
                target.add_artifact("local", "note", "inbox", "existing")
                imported = target.import_bundle(bundle, mode="replace")
                assert imported["artifacts_imported"] == 2
                imported_rail = target.version_rail()
                assert imported_rail["stable_uuid"] == b["artifact_uuid"]
                assert a["artifact_uuid"] in imported_rail["archive_uuids"]
                restored_a = target.get_artifact_by_uuid(a["artifact_uuid"])
                assert target.get_artifact_tags(restored_a) == ["python", "bridge"]
                assert target.get_artifact_meta(restored_a) == {"generation": 1}
                assert target.workshop_ledger()["repository"] == "levelinglucy/test"
                results.append("bundle restore preserves UUID identity, tags, metadata, rail and ledger")

                report = target.diagnose()
                assert report["ok"], report["problems"]
                results.append("diagnostics report a coherent restored database")
            finally:
                target.close()
        finally:
            source.close()

    return {"ok": True, "tests": results, "count": len(results)}


def cli_main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="NOE WORKSHOP local-first artifact shell")
    parser.add_argument("--db", type=Path, default=DB_PATH, help="SQLite database path")
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--diagnose", action="store_true")
    parser.add_argument("--export-bundle", action="store_true")
    parser.add_argument("--import-bundle", type=Path)
    parser.add_argument("--replace", action="store_true", help="Replace artifact state during import")
    parser.add_argument(
        "--packet", choices=["session", "versions", "workshop", "diagnose"], help="Print a packet"
    )
    parser.add_argument("--list", action="store_true", help="List recent artifacts")
    parser.add_argument("--no-ui", action="store_true", help="Do not launch Pythonista UI")
    args = parser.parse_args(argv)

    if args.self_test:
        print(json_text(run_self_test()))
        return 0

    if args.db == DB_PATH:
        prepare_default_storage()
    db = DB(args.db)
    try:
        if args.import_bundle:
            result = db.import_bundle(args.import_bundle, mode="replace" if args.replace else "merge")
            print(json_text(result))
            return 0
        if args.export_bundle:
            print(str(db.export_bundle()))
            return 0
        if args.diagnose:
            report = db.diagnose()
            print(json_text(report))
            return 0 if report["ok"] else 1
        if args.packet:
            payload = {
                "session": db.build_session_packet,
                "versions": db.build_versions_packet,
                "workshop": db.build_workshop_packet,
                "diagnose": db.diagnose,
            }[args.packet]()
            print(json_text(payload))
            return 0
        if args.list:
            for row in db.list_artifacts(limit=100):
                print(
                    f"#{row['id']:>4} {row['artifact_uuid'][:8]} {row['bucket']:<9} "
                    f"{row['artifact_type']:<12} {row['project'] or '-':<14} {row['title'] or '(untitled)'}"
                )
            return 0
    finally:
        db.close()

    if UI_AVAILABLE and not args.no_ui:
        prepare_default_storage()
        ShellView(args.db).present("fullscreen")
        return 0

    parser.print_help()
    return 0


if __name__ == "__main__":
    raise SystemExit(cli_main())
