# levelinglucy / Chat Workshop Archive

Created: 2026-08-16
Conversation local timezone: Europe/London

This archive preserves the technical work and discoveries from the current chat.

## Important provenance note

ChatGPT does not expose a platform-native raw conversation export API to the assistant.
`CHAT_LOG_RECONSTRUCTED.md` is therefore a chronological reconstruction from the visible
conversation context available in this chat. It preserves the workshop sequence, user
instructions, project/file/commit identifiers, discoveries, decisions, and generated
artifacts, but it should not be represented as a raw server-side transcript with hidden
message IDs, internal metadata, or private reasoning.

No private chain-of-thought is included.

## Contents

- `CHAT_LOG_RECONSTRUCTED.md` — chronological reconstructed chat/workshop log.
- `DISCOVERIES_CATALOGUE.md` — consolidated project-by-project technical discoveries.
- `SOURCE_SNAPSHOTS.json` — repository/file/commit/blob index.
- `WORKSHOP_LEDGER.json` — structured workshop ledger.
- `ARTIFACT_MANIFEST.json` — hashes/sizes of generated local artifacts.
- `archive_sha256.txt` — SHA-256 manifest for the archive's files.
- `artifacts/` — generated scripts/bundles still present in the conversation runtime.

## Canonical recurring workshop instruction

Inspect the public GitHub account `levelinglucy` for new or changed python work. Exclude Roblox/Luau-specific projects and files. Bring useful source snapshots into this chat with the repository, file path, and commit identifier so the work is preserved here. Choose at most one non-Roblox Lua project per session when there is a worthwhile improvement, then post a bounded set of ideas, updated code, tests, or theory. Prefer low-cognitive-load monolithic uploaders or single-file setup paths while preserving modular originals. Maintain a compact `WORKSHOP_LEDGER` in every substantive update containing the last repository, files examined, commit, what changed, unresolved questions, and possible next threads. Rotate projects or stop cleanly when no natural improvement appears; never invent busywork. Do not modify GitHub or open pull requests unless Dylan separately asks and the connected account has write permission. If nothing has changed and no meaningful improvement is available, do not send a notification.

## GitHub mutation policy followed

No GitHub write, commit, branch, pull request, or deletion was performed by these workshop
inspection passes unless separately authorized. The work preserved here is analysis and
local candidate artifact generation.
