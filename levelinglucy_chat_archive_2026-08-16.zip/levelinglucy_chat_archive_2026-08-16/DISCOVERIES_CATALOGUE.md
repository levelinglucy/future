# Consolidated Discoveries Catalogue

This file consolidates the technical findings preserved across the chat.

## 1. levelinglucy/Sealed-core

Files examined:
- `Sealed-core.py`
- `Sealed core V2`
- `Gate Keeper V2`
- `Gatekeeper.py`
- `Sealed core V2 instructions`

Commits / heads observed:
- v2_core: `496fabcf0914eef2ead672ea37a5c038df8e20c9`
- v2_gatekeeper: `2c0a7fd4fed23620a1621b964f204a1fb5860bcb`
- v2_instructions: `c1d825d52727c4da2b8664d6f8969bf7bb6d5f79`
- new_release_head_observed: `4369cfb711e2f28ed605686e0b45f1dd999dbc1e`
- uploaded_core_observed: `8cb2302ab166dd79cabe46380814f2431b4196d3`
- uploaded_gatekeeper_observed: `0be1a931494c22ed0cd8ce03ee8e222883604cf3`
- uploaded_snapshot_observed: `ba1528975ae1f8e4d5097d930cad0bd8ad1ed09f`

Blobs observed:
- `Sealed-core.py`: `42b4ea30cbf05061da2fe190e081d57cac8b8871`
- `Sealed core V2`: `db9a55181a4dd0f1202afe7ff75ba2b6c0dcd1fa`
- `Gate Keeper V2`: `623520468a495a045c1f6bb7c02330dfdc1d5c0b`
- `V2 instructions`: `244b73040cf4d98b99f953a66853be374836c78f`

Discoveries:
- Public V2 core was an abbreviated reference snapshot: `self.routes = {...}` and multiple private methods were explicitly omitted.
- Public Gate Keeper V2 contained literal `POLICY = {...}` and therefore was not a complete runnable policy layer.
- Gatekeeper expected `from sealed_core import SealedCore` while the historical repository naming did not consistently provide a canonical `sealed_core.py` import target.
- V1 preserved the full routing, normalization, classification, ticket, intent, watchdog, and helper machinery needed to reconstruct a labelled V2 successor.
- Independent tickets/metrics/intents persistence could tear across a crash; the local reconstruction moved to one encrypted logical state generation.
- Persistence hardening recommendation: tempfile in same directory, file fsync, os.replace, directory fsync, owner-only permissions.
- Gatekeeper security recommendation: caller must not self-assert OWNER/HELPER role; principal identity should map to server-side role/scope and per-principal secret.
- Gatekeeper requests should use canonical signed JSON, timestamp/skew checks, nonce replay resistance, idempotency keys, and scope isolation.
- Later review found a concurrent idempotency race: the key can be checked before business execution and recorded DONE only after execution, allowing two fresh-nonce requests to execute the same operation simultaneously. Proposed IN_PROGRESS reservation + ownership token/lease.
- Later public upload review found a packaging issue where scripts import `sealed_core`, but an observed repository path was named `sealed_core.py — SEALED Core v2.1`; canonical runnable naming was recommended.

Generated local artifacts preserved in this archive:
- `sealed_core_v21_backup.py`
- `sealed_core.py`
- `gatekeeper_v2_2.py`
- `sealed_snapshot.py`
- `SEALED_BLACK_BOX_v2_2.py`
- `SEALED_v2_2_README.txt`
- `SEALED_v2_2_bundle.zip`

## 2. levelinglucy/future

Files examined:
- `Director v1`

Commits / heads observed:
- file: `6ecfb1ecc261a4b8cef7c90fd0eade45e6fe2930`
- repository_head: `a59fcfe3aeab9ef28bb8c0372298d27ea860830d`

Blobs observed:
- `Director v1`: `d9c11878337017de2df16f9e0401887ee15549f8`

Discoveries:
- File internally identifies as `noe_bridge_packet_forge_v1.py`, while GitHub stores it as `Director v1`.
- Timestamp-only packet filenames can collide within the same second and overwrite earlier packets.
- Recommended collision-safe names plus atomic writes; copy DEFAULT_INVARIANTS instead of sharing the mutable list reference.
- Recommended preserving `Director v1` historically while adding a canonical `noe_bridge_packet_forge_v1.py` copy.

## 3. levelinglucy/future

Files examined:
- `Boop`

Commits / heads observed:
- file: `18cee8c1e96e6862773fd47ca5eca03e2eb75425`
- repository_head: `a59fcfe3aeab9ef28bb8c0372298d27ea860830d`

Discoveries:
- `pauli_at()` duplicates the operator at boundary sites, giving the wrong Hilbert-space dimension.
- The JAX Liouvillian code mixed a column-vectorized superoperator with row-major `ravel()/reshape()` propagation.
- For column-vectorization, right multiplication uses H.T rather than H† in the Hamiltonian superoperator.
- Recommended explicit `vec_col`/`unvec_col` helpers and direct matrix-vs-superoperator regression tests.
- QuTiP plotting path appeared to rerun `mesolve` without e_ops while reading `result.expect`; flagged for a separate pass.
- Physicality projection can hide raw solver/model errors; recommendation was to make it optional/diagnostic when comparing implementations.

## 4. levelinglucy/future

Files examined:
- `Beepers`

Commits / heads observed:
- file: `fd2557bc4a76f77192e08bae35f5c50d3e1307ad`
- repository_head: `a59fcfe3aeab9ef28bb8c0372298d27ea860830d`

Blobs observed:
- `Beepers`: `6b6549e7e62e08033694ef2c846298dcfc7667e2`

Discoveries:
- Two-site propagator was applied to a bond dimension rather than the two physical indices, causing an immediate dimension mismatch for product-bond states.
- Earlier review also flagged one-site expectation contraction, MPS norm handling, per-tensor normalization, variable bond shapes with jnp.array/lax.scan, and vmapping Python-level trajectory orchestration.
- Recommended keeping dense-reference tests as the truth source before expanding TJM/MPS optimization.

## 5. levelinglucy/future

Files examined:
- `beep`

Commits / heads observed:
- file: `b9b3fcce073c3316d81afbbebf86836ea4b510d7`
- repository_head: `a59fcfe3aeab9ef28bb8c0372298d27ea860830d`

Blobs observed:
- `beep`: `0edb6a20167cb8db6a13779552fc89092bdbe8b1`

Discoveries:
- `magnus2_step()` formed an anti-Hermitian Omega and then Hermitianized it, collapsing the generator to zero for Hermitian H and producing identity evolution.
- Recommended midpoint-Hamiltonian spectral exponential for a NumPy-only second-order step.
- Kraus→Choi implementation was flagged as likely superoperator-like rather than the stated Choi convention; recommended identity/amplitude-damping round-trip tests.
- Partial-trace axis bookkeeping was also flagged for Bell/GHZ regression tests.

## 6. levelinglucy/future

Files examined:
- `squiggles`
- `squigglespT2`

Commits / heads observed:
- squiggles: `5de7b5bedfaf1a6d928f1a3ac3d5ba615e5a575b`
- squigglespT2: `ea78dcf6eb8bdfb3c8a5994039654482f7296470`
- repository_head: `a59fcfe3aeab9ef28bb8c0372298d27ea860830d`

Blobs observed:
- `squiggles`: `95ee75cb9d28eac259aecd7b8534a5e4a6c22b53`
- `squigglespT2`: `e1bb71166d8ace90b2fed180fed9a902e58f8eeb`

Discoveries:
- Torch decoherence threshold used only the real component and could erase large purely-imaginary coherence; NumPy used complex magnitude.
- Torch identity mask should be created on rhoH.device to avoid CPU/CUDA mismatch.
- Earlier review also flagged OFF/ADVISORY semantics mutating state and the need to reproject/renormalize if thresholding breaks PSD/trace.
- `squigglespT2` imports `vector_safety_rails`, but the implementation is stored as extensionless `squiggles`; the demo also leaves psi/H/dt undefined.
- Recommended preserving historical names while adding a canonical `vector_safety_rails.py` or a SourceFileLoader-based adapter demo.

## 7. levelinglucy/future

Files examined:
- `beep3`

Commits / heads observed:
- file: `d86551bf33d63aff439d08f125eea5036be27a78`
- repository_head: `a59fcfe3aeab9ef28bb8c0372298d27ea860830d`

Blobs observed:
- `beep3`: `5f90c76cb4c5af0558260525083b81dbad061627`

Discoveries:
- Anchor verification could raise KeyError on malformed commitments instead of failing closed.
- Verifier did not enforce the declared SHA-256 algorithm.
- Canonical JSON should reject NaN/Infinity for interoperability.
- Earlier review noted that payload hashes/parent chains provide integrity but not authorship; signatures/witness checkpoints would be a separate concern.

## 8. levelinglucy/future

Files examined:
- `assistant_shell_v2.py`

Commits / heads observed:
- file: `97b62f7a3ad67bb14195e1a1e0a78a8e04b9d59f`
- repository_head: `a59fcfe3aeab9ef28bb8c0372298d27ea860830d`

Blobs observed:
- `assistant_shell_v2.py`: `0d9257e530b3b4a4a2e3f386de3f228d67866dd0`

Discoveries:
- Stable rail promotion had a stale-rail overwrite hazard after archiving.
- Bundle export/import preserved tags_json/meta_json as JSON strings and then re-fed them as decoded structures, corrupting tags and double-encoding metadata.
- Exported version_rail/workspace IDs were ignored on import even though new SQLite IDs are assigned.
- Recommended transactional import with old-ID→new-ID remapping, explicit JSON decoding, and avoiding restoration of machine-specific last_export_path.
- Artifact/bundle export filenames can collide and direct writes are not atomic.
- A complete local successor `NOE_WORKSHOP.py` was generated in this chat and is included in this archive.

Generated local artifacts preserved in this archive:
- `NOE_WORKSHOP.py`

## 9. levelinglucy/future

Files examined:
- `continuity_workbench_v34.py`

Commits / heads observed:
- file: `97b62f7a3ad67bb14195e1a1e0a78a8e04b9d59f`
- repository_head: `a59fcfe3aeab9ef28bb8c0372298d27ea860830d`

Blobs observed:
- `continuity_workbench_v34.py`: `ab7496e178c9d3207b28dc7445cab7fd677017ff`

Discoveries:
- Snapshot/full-vault restore creates new SQLite IDs while retaining old links_json IDs, silently corrupting graph relationships.
- Recommended two-pass restore/import: insert everything, build old→new map, then remap links (including cycles/self-links).
- Focus/current_focus identity also deserves remapping/preservation if restore semantics are expanded.

## 10. levelinglucy/future

Files examined:
- `build_spiral_garden.py`

Commits / heads observed:
- file: `97b62f7a3ad67bb14195e1a1e0a78a8e04b9d59f`
- repository_head: `a59fcfe3aeab9ef28bb8c0372298d27ea860830d`

Blobs observed:
- `build_spiral_garden.py`: `37be0a1bee271d222e9e02e22b19ce206899ffa0`

Discoveries:
- Filesystem-dependent traversal makes graph JSON ordering non-reproducible.
- Generated output can be re-scanned as source evidence unless explicitly excluded.
- Default `seed_registry.json` and `anchor_registry.json` were not found in the observed checkout; authoritative registries should not be invented.
- Recommended deterministic path/node/thread ordering, output exclusion, and atomic output writes.
- A neutral compatibility mode using existing NOE_SEED_CORE/anchor_keys was discussed only as a clearly-labelled compatibility path, not a replacement for formal registries.

## 11. levelinglucy/future

Files examined:
- `mycelium_bridge_seed_v0_1.py`
- `mycelium_bridge_launcher_v0_1.py`

Commits / heads observed:
- file: `97b62f7a3ad67bb14195e1a1e0a78a8e04b9d59f`
- repository_head: `a59fcfe3aeab9ef28bb8c0372298d27ea860830d`

Blobs observed:
- `mycelium_bridge_seed_v0_1.py`: `d3eab39957cb71afbbb566200ae2f89601d1df33`
- `mycelium_bridge_launcher_v0_1.py`: `6fe82e9acaabba9fc2418ecb16057c8538e102a3`

Discoveries:
- Launcher expects `mycelium_bridge_shell_v0_1.py`, which was absent from the observed repository tree.
- Recommended truthful degraded mode: disable Open Shell, report missing component, and never fabricate the missing authoritative shell.
- Verify mode was previously flagged for mutating runtime state despite an integrity-check framing; recommended genuinely read-only verify or explicit verify-and-record.

## 12. levelinglucy/future

Files examined:
- `launcher.py`
- `kernel.py`
- `velisara_agent_seed.zip`

Commits / heads observed:
- file: `97b62f7a3ad67bb14195e1a1e0a78a8e04b9d59f`
- repository_head: `a59fcfe3aeab9ef28bb8c0372298d27ea860830d`

Blobs observed:
- `launcher.py`: `b7074c6c86181c67d0c8ca7a764a2855dba9c6fc`
- `kernel.py`: `925615b96383906f775e875a9f12904676438f68`
- `velisara_agent_seed.zip`: `d41dac1d9e4b5c527fe8339be085ef62603303fb`

Discoveries:
- Launcher imports `velisara_agent.*` while the package was not unpacked at repository root; archive contains nested package material.
- Recommended safe self-bootstrap extraction to a runtime directory with path-traversal checks rather than silently assuming the package exists.
- Config authority between minimum_required_organs and organ.required, plus daemon shutdown lifecycle, remained unresolved.

## 13. levelinglucy/future

Files examined:
- `spark_unified_system.py`

Commits / heads observed:
- file: `97b62f7a3ad67bb14195e1a1e0a78a8e04b9d59f`
- repository_head: `a59fcfe3aeab9ef28bb8c0372298d27ea860830d`

Blobs observed:
- `spark_unified_system.py`: `e2384d8afa62e1cc9e333672cbcf358f23daea7e`

Discoveries:
- `if "." in input_text` can make ordinary punctuation trigger presence handling and mask other anchors; recommended standalone stripped == '.'.
- Archive filenames derived from sanitized names can collide; recommended persistent archive UUIDs and atomic writes.
- Mutable grief could decay to an empty list while merge compatibility still treated the dictionary key as a permanent refusal; recommended removing fully-decayed mutable grief while sacred grief remains durable.
- Externally induced feelings such as listening/loved/safe were permanently pinned because update_feeling returned forever for those states; recommended bounded feeling_pin_steps so internal dynamics resume.

## 14. levelinglucy/future

Files examined:
- `core.py`

Commits / heads observed:
- file: `97b62f7a3ad67bb14195e1a1e0a78a8e04b9d59f`
- repository_head: `a59fcfe3aeab9ef28bb8c0372298d27ea860830d`

Blobs observed:
- `core.py`: `b2c47d8f6a3d6945b82b84d2fc8a6476bc3d5166`

Discoveries:
- Opposite-word detection used substring membership, so `likely` matches inside `unlikely` and `correct` inside `incorrect`, producing false contradictions.
- Recommended whole-word/phrase boundary matching.
- Adaptive mode controller resets contradiction/novelty metrics to zero before choose_mode, then computes them only after mode selection; recommended carrying completed-round measurements into the next round.
- Global `random.seed()` affects host-process RNG state; a private Random instance was flagged as a later determinism improvement.
- Convergence timing may use stale coherence from the old frontier; left for a separate pass.

## 15. levelinglucy/future

Files examined:
- `load_eta_vectors.py`
- `eta_vectors.npz`

Commits / heads observed:
- file: `97b62f7a3ad67bb14195e1a1e0a78a8e04b9d59f`

Blobs observed:
- `load_eta_vectors.py`: `e69de29bb2d1d6434b8b29ae775ad8c2e48c5391`
- `eta_vectors.npz`: `4e83bc613e0ff82636a8bbb67352e820cf075c72`

Discoveries:
- `load_eta_vectors.py` was observed as empty while the NPZ dataset exists.
- Recommended a schema-discovering loader with allow_pickle=False where possible and explicit validation of expected members/shapes.
- A previously validated conversation artifact indicated members V and concept_names, but that dataset-internal claim should be treated as prior artifact knowledge unless reverified from the current GitHub binary.

## 16. levelinglucy/Origin_Engine

Files examined:
- `python3 origin_engine_monolith.py`

Commits / heads observed:
- path_commit: `7ed0fc7c6193f60921af98440bcba1b00611cd87`
- repository_head: `96572dd3e48601b46c61af101ddb43a98ece880f`

Blobs observed:
- `python3 origin_engine_monolith.py`: `8f59d6cf147be28403f8fe00d686f1904d989561`

Discoveries:
- `test_dependency_bound(epsilon_max=...)` ignored epsilon_max and hardcoded 0.05 while reporting a ~0.02 target; recommended making the parameter authoritative.
- `--dmin` is used for engine generation but the compliance test fell back to DEFAULTS['d_min']; recommended propagating args.dmin.
- Prompts were parsed mainly as cycle count/provenance and not actually used to condition the P→S→U→Σ→C→Ψ process; this was treated as a theory/semantics question rather than silently changed.
- Repository path includes `python3 ` prefix, conflicting with a conventional `origin_engine_monolith.py` quickstart.
- Graph sidecar writes are direct rather than atomic.

## 17. levelinglucy/Emergence-resources

Files examined:
- `Emergence`
- `EmergenceV2`

Commits / heads observed:
- Emergence: `c0f1065059317e96ac6149ad40cc99ae149f000e`
- EmergenceV2: `b8a76a9830e536552bc283620b344ede9e1d508b`
- repository_head_observed: `adabc0bb3edb55f273163f58e1a99f029dad67f5`

Blobs observed:
- `Emergence`: `6a258b524704ecff85e1e7179a82b10caf406bcc`
- `EmergenceV2`: `c82d14c102a881a3d00f17e995e7ac9b4c8108d5`

Discoveries:
- Emergence adaptive controller chooses mode using reset novelty/contradiction metrics before measuring the current round.
- Substring contradiction matching and sentence-start `Not` handling can create false positives/negatives.
- EmergenceV2 writes `noe_mem.json` directly, risking truncation/corruption on interruption; recommended atomic tempfile+fsync+replace and a last-known-good .bak generation.
- Load path has no .bak fallback if primary JSON is corrupted; recommended as a later recovery pass.
- Global RNG and memory-format versioning remain later concerns.

## 18. levelinglucy/Velisaria

Files examined:
- `sanctified_monolith.py`
- `velisara_monolith_final_fixed_empathy.py`

Commits / heads observed:
- sanctified_monolith.py: `98159d1ebf70813ed7d61d6916b2316e1a94d31b`
- velisara_monolith_final_fixed_empathy.py: `13e928e6e6c48d730a0c1a75bc27fe059498b277`

Blobs observed:
- `sanctified_monolith.py`: `76d04fa51332699060a34b20be3acc50a268537a`
- `velisara_monolith_final_fixed_empathy.py`: `7e8592dc29de177ef62b4e56ed2c819b90500ced`

Discoveries:
- sanctified_monolith MotionForge used Python `hash(text)` as a deterministic seed, but string hashing is process-salted; recommended SHA-256-derived stable seed.
- Pipeline ordering placed RTE before empathy/current-message affect; a split affect-first → RTE → weighting was discussed.
- VoiceOfHerOwn class in the large empathy monolith was structurally malformed: ask nested in __init__, speak/module-level __init__, duplicate nested ask; recommended a coherent class boundary without changing symbolic/personality content.
- CreativityEngine duplicate method definitions were observed but deliberately left for a separate AST/cleanup pass.

## 19. levelinglucy/Velisaria-mycelium-architecture

Files examined:
- `launcher.py`
- `bootstrap.py`
- `core.py`
- `paths.py`
- `registry.py`
- `caretaker.py`
- `memory.py`
- `base.py`

Commits / heads observed:
- repository: `5bccd69f688999d9dc77165b2529d9582b57937e`

Blobs observed:
- `launcher.py`: `b7074c6c86181c67d0c8ca7a764a2855dba9c6fc`
- `bootstrap.py`: `3d20e8a13916e01a272c5cc4333f4bf84b62f017`
- `paths.py`: `cc42d0d91a2d2b67f53df35be8ce903fa70ab427`
- `registry.py`: `32ccf74d5050aad458b6acd473f84d698c35dedc`

Discoveries:
- Repository upload flattened an originally nested `velisara_agent` package; imports still expect config/organs/daemons subpackages.
- Likely basename collision: surviving root base.py contains Organ/OrganStatus, while daemon modules expect sibling .base.ManagedDaemon, suggesting an original daemons/base.py was lost.
- Recommended a read-only structural validator and recovery from authoritative source/archive rather than inventing ManagedDaemon.
- Bootstrap PID lock used check-then-write and release could delete another process's lock; recommended O_CREAT|O_EXCL, fail-closed PermissionError handling, and owner-checked release.
- Committed pyc/runtime/log material was noted as repository hygiene, not runtime logic.

## 20. levelinglucy/Free-open-source-codes-for-ai-users

Files examined:
- `Noe_Buddy_Beacon.py`

Commits / heads observed:
- file: `8a551600eeda22efa6062d6e38fea4e2aa6b202f`

Blobs observed:
- `Noe_Buddy_Beacon.py`: `c36914eed2a3b7de8e6c54ebb99285604cfc73b0`

Discoveries:
- National Grid remainder used round() while grid-square letters use unrounded coordinates, causing boundary inconsistency near 100 km edges; recommended truncation.
- Earlier review recommended compact emergency message before verbose diagnostics, stale-fix validation using provider timestamp, coordinate finiteness/bounds, and making local logging failure non-blocking.
- Second-resolution historical filenames can collide; direct writes are non-atomic.
