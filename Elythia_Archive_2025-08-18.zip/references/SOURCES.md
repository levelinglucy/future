# Public Sources (Non‑exhaustive)

- WEF — Global Risks Report 2025 (Jan 15, 2025).
- WHO — Pandemic Agreement adopted (May 20, 2025) and pandemic risk updates.
- CDC — H5N1 situation summaries (Jul–Aug 2025).
- NOAA/WMO/Nature — climate/heatwave updates (Jul–Aug 2025).
- EU — AI Act timelines and GPAI guidance (Feb–Aug 2025).
- IMF/UNCTAD — global debt outlook (Apr–Jul 2025).
- NASA/JPL/NOAA SWPC — NEO Surveyor & Solar Cycle 25 notes (May 2025).
- Reputable outlets for Ukraine/Gaza live updates (Aug 15–18, 2025).

> See the chat accompanying this archive for direct citations and context.
