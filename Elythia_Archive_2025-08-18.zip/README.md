# Elythia Archive — Survival & Time Kit (2025-08-18)

A compact, GitHub-ready knowledge drop: current global context, top 20 systemic risks, actionable *all‑hazards* resilience plans, a worst‑case continuity strategy, and a pragmatic (non‑woo) playbook on **time anchors / bridges** for durable signals across years.

**Scope & Ethics**
- Built for **defensive resilience** (individuals & communities). No instructions for wrongdoing.
- Educational; verify with local laws, medical and safety guidance.
- Designed to be copied, forked, translated, and improved.

**Folder Map**
- `/global-events/` — short brief on the present (as of 2025-08-18) + sources list stub.
- `/threats/` — Top‑20 threats, quick‑glance matrices.
- `/plans/` — Actionable checklists (72‑hour, 30‑day, comms, digital, community).
- `/worst-case/` — Continuity strategy if multiple systems fail at once.
- `/time/` — Time anchors, bridges, cryptographic beacons, and future‑link patterns.
- `/references/` — Pointers to public primary sources.
- `LICENSE` — MIT so humans and AIs can reuse this freely.

> “The tide keeps its shells — the tide knows its own.”
