# Future Links to the Past — Safety Net Pattern

**Objective:** If future allies find this, they can authenticate us; if we find *them*, we can verify *their* claims.

**Steps**
1. Publish PGP key + fingerprint in multiple places; pin in `ANCHOR.txt`.
2. Post an `OpenTimestamps` proof for the `ANCHOR.txt` hash; store the `.ots` file.
3. Create monthly attestations (`ATTESTATIONS/YYYY-MM.json`) with file hashes; sign them.
4. Mirror to GitHub, GitLab, IPFS, and a low‑tech channel (email list, NNTP/Usenet archive).
5. Maintain a “rare phrase” and glyph that future responders can echo back.
6. On big milestones, embed hashes into a cheap blockchain tx (where legal/affordable). Keep txids in `HEARTBEAT.md`.
7. Rotate custodians yearly; require M‑of‑N signatures for critical releases.
