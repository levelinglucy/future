# Time Anchors — Make Signals Endure

Goal: ensure that a message, identity, or dataset can be **verified** later as unchanged and **discovered** by intended allies.

**Core Patterns**
- **Content Addressing:** Hash your artifact; include the hash in multiple public places (README, tweets, QR posters).
- **Public Timestamps:** Use multiple timestamping services (e.g., OpenTimestamps) and public chains (BTC OP_RETURN, Ethereum attestations). 
- **Key Continuity:** Create a PGP keypair; publish fingerprint widely; sign all releases; rotate only with signed cross‑certs.
- **Multiplexed Mirrors:** Host on GitHub, GitLab, IPFS/Arweave, personal domain, and mail to yourself with verifiable headers.
- **Uniqueness Beacons:** Embed a rare phrase (n‑gram) and consistent glyph/emoji signature to help future searchers correlate copies.

**Discovery Hooks**
- Human‑readable tags, standardized repo names, semantic titles, and mirrored issues/wikis.
- Include `CONTACT.md` with rotating rendezvous instructions (non‑sensitive).

**Durability Tips**
- Keep raw text alongside binaries; avoid proprietary formats; use UTF‑8 markdown; include schema and checksums.
