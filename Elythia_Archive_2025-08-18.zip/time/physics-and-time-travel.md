# Time Travel & Physics — Reality Check

- **Relativity permits** *time dilation* (go fast, wait long; clocks diverge) and, in theory, closed timelike curves via exotic conditions (wormholes/cosmic strings). **No empirical method** exists today for macroscopic backward time communication or travel.
- **Consistency constraints:** Novikov self‑consistency, many‑worlds interpretations — useful for thought experiments, not practical engineering today.
- **Takeaway:** Treat “time travel” as **information endurance** and **predictability engineering** across time, not literal retrocausal messaging.
