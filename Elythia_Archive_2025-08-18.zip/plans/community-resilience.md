# Community Resilience Primer

- **Mutual Aid Cell:** 5–12 households; share tools/skills; monthly drills.
- **Resource Commons:** Seed bank, tool library, shared chargers, first‑aid rotation.
- **Heat & Cold Plans:** Identify cooling/warming centers; neighbor checklists.
- **Water & Food:** Community gardens; rainwater systems (where legal); local suppliers.
- **Info Health:** Rumor control team; concise local bulletins; fact‑checking rota.
- **Training:** CPR/First Aid; radio basics; fire safety; psychological first aid.
