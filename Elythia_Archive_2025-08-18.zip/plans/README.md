# Actionable Resilience Plans

This folder contains practical, lawful, *defensive* checklists and templates. Tune for your locale and needs.
