# 72-Hour Kit (Per Person)

- Water: 3–4 L/day (carry & treatment tablets/filter; follow WHO/CDC guidance for chemical disinfection).
- Food: 6,000–9,000 kcal shelf‑stable (nuts, oats, beans, bars, electrolyte mix).
- Meds: 7‑day supply + copies of prescriptions; small first‑aid kit incl. ORS.
- Power: Headlamp, spare batteries, power bank, charging cables.
- Comms: Printed contacts, local maps, radio (FRS/PMR), USB with docs.
- Shelter: Space blanket, poncho, sturdy shoes, gloves, mask (P2/N95), tape.
- Docs: IDs, insurance, key papers (encrypted digital + sealed printouts).
- Cash: Small bills/coins for local purchases during outages.
- Pets: Food, water, meds, leash, carrier.
