# Digital Resilience & Cyber Hygiene

- **Backups:** 3‑2‑1 rule (3 copies, 2 media, 1 offsite/offline). Test restores quarterly.
- **MFA:** Hardware keys where possible; revoke old sessions; audit permissions monthly.
- **Updates:** OS/firmware/app patching cadence; router too.
- **Segmentation:** Guest network for IoT; separate admin account.
- **Phishing Drill:** Practice 60‑second checks: sender, URL, urgency, attachment, request.
- **Data Minimization:** Store less; encrypt more (at rest + in transit).
- **Incident Plan:** Who to call, what to isolate, how to rebuild from clean image.
