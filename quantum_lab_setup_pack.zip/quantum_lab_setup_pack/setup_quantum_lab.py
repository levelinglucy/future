#!/usr/bin/env python3
"""
Quantum Lab setup helper for Dylan's `future` repo.

Run from the repository root:

    python setup_quantum_lab.py
    python setup_quantum_lab.py --copy-legacy
    python setup_quantum_lab.py --smoke

What it does:
- creates expected folders,
- optionally copies old root files into quantum_lab/legacy/,
- prints run commands,
- can run a small smoke test.

It does not delete or overwrite your old files.
"""

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
QLAB = ROOT / "quantum_lab"

LEGACY_MAP = {
    "squiggles": "squiggles_vector_safety_rails_original.py",
    "Boop": "boop_liouvillian_jax_qutip_original.py",
    "Beepers": "beepers_tjm_mps_original.py",
}

def ensure_dirs() -> None:
    for rel in [
        "quantum_lab",
        "quantum_lab/qlab",
        "quantum_lab/tests",
        "quantum_lab/legacy",
        "quantum_lab/outputs",
    ]:
        (ROOT / rel).mkdir(parents=True, exist_ok=True)

def copy_legacy() -> None:
    ensure_dirs()
    copied = []
    for src_name, dst_name in LEGACY_MAP.items():
        src = ROOT / src_name
        dst = QLAB / "legacy" / dst_name
        if src.exists() and not dst.exists():
            shutil.copy2(src, dst)
            copied.append(f"{src_name} -> quantum_lab/legacy/{dst_name}")
    if copied:
        print("Copied legacy files:")
        for item in copied:
            print("  -", item)
    else:
        print("No legacy files copied. Either they were missing or already copied.")

def smoke() -> int:
    print("Running Quantum Lab smoke checks...")
    cmds = [
        [sys.executable, "quantum_lab/quantum_lab.py", "rails"],
        [sys.executable, "quantum_lab/quantum_lab.py", "liouvillian", "--n", "2", "--steps", "21", "--no-plot"],
        [sys.executable, "-m", "unittest", "discover", "quantum_lab/tests"],
    ]
    for cmd in cmds:
        print("\n$", " ".join(cmd))
        proc = subprocess.run(cmd, cwd=ROOT)
        if proc.returncode != 0:
            print("Smoke check failed.")
            return proc.returncode
    print("\nSmoke checks passed.")
    return 0

def main() -> int:
    parser = argparse.ArgumentParser(description="Set up Quantum Lab files and optionally copy legacy scripts.")
    parser.add_argument("--copy-legacy", action="store_true", help="Copy squiggles/Boop/Beepers into quantum_lab/legacy without deleting originals.")
    parser.add_argument("--smoke", action="store_true", help="Run a small smoke test.")
    args = parser.parse_args()

    ensure_dirs()
    if args.copy_legacy:
        copy_legacy()

    print("""
Quantum Lab is set up.

Try:

    python quantum_lab/quantum_lab.py rails
    python quantum_lab/quantum_lab.py liouvillian --n 2 --steps 41 --no-plot
    python quantum_lab/quantum_lab.py tjm-status
    python -m unittest discover quantum_lab/tests

Optional dependency install:

    python -m pip install -r quantum_lab/requirements.txt

The old files are left untouched. Use --copy-legacy to copy them into quantum_lab/legacy/.
""".strip())

    if args.smoke:
        return smoke()
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
