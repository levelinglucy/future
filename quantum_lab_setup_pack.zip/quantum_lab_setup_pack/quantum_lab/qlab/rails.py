from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any

import numpy as np

try:
    import torch
    _HAS_TORCH = True
except Exception:
    torch = None
    _HAS_TORCH = False


class RailMode(Enum):
    OFF = "off"           # return raw results where possible
    ADVISORY = "advisory" # report only, no correction
    ENFORCE = "enforce"   # project gently back to valid numerical manifolds


@dataclass
class RailConfig:
    eps: float = 1e-12
    kappa_max: float = 1e12
    trace_tol: float = 1e-9
    lorentz_tol: float = 1e-8
    min_eig_clip: float = 0.0
    decohere_floor: float = 0.0
    backend: str = "numpy"  # "numpy", "torch", or "auto"


def _use_torch(cfg: RailConfig) -> bool:
    if cfg.backend == "torch":
        if not _HAS_TORCH:
            raise RuntimeError("Torch backend requested but torch is not installed.")
        return True
    if cfg.backend == "auto":
        return _HAS_TORCH
    return False


def _arr(x: Any, *, complex_dtype: bool, use_torch: bool):
    if use_torch:
        t = x if torch.is_tensor(x) else torch.as_tensor(x)
        return t.to(torch.complex128 if complex_dtype else torch.float64)
    a = np.asarray(x)
    return a.astype(np.complex128 if complex_dtype else np.float64, copy=False)


def _dagger(A, use_torch: bool):
    if use_torch:
        return A.conj().transpose(-1, -2)
    return np.conjugate(np.swapaxes(A, -1, -2))


def _trace(A, use_torch: bool):
    if use_torch:
        return torch.diagonal(A, dim1=-2, dim2=-1).sum(-1)
    return np.trace(A, axis1=-2, axis2=-1)


def _project_hermitian(A, use_torch: bool):
    return 0.5 * (A + _dagger(A, use_torch))


def _eigh(A, use_torch: bool):
    return torch.linalg.eigh(A) if use_torch else np.linalg.eigh(A)


def _psd_clip(A, use_torch: bool, floor: float):
    w, V = _eigh(A, use_torch)
    if use_torch:
        w = torch.clamp(w.real, min=floor)
        return (V * w.unsqueeze(-2)) @ _dagger(V, use_torch)
    w = np.clip(w.real, a_min=floor, a_max=None)
    return (V * w[..., None, :]) @ np.conjugate(np.swapaxes(V, -1, -2))


def _norm(x, use_torch: bool) -> float:
    if use_torch:
        return float(torch.linalg.vector_norm(x).detach().cpu().item())
    return float(np.linalg.norm(x))


def _nan_to_num(x, use_torch: bool):
    if use_torch:
        return torch.nan_to_num(x, nan=0.0, posinf=1e38, neginf=-1e38)
    return np.nan_to_num(x, nan=0.0, posinf=1e38, neginf=-1e38)


class VectorSafetyRails:
    """Numerical integrity rails for quantum/vector simulations.

    OFF: return raw or minimally computed outputs.
    ADVISORY: report invariant status without modifying the user's object.
    ENFORCE: apply gentle corrections.
    """

    def __init__(self, mode: RailMode = RailMode.OFF, cfg: RailConfig | None = None):
        self.mode = mode
        self.cfg = cfg or RailConfig()
        self.use_torch = _use_torch(self.cfg)

    def normalize_state(self, psi):
        psi = _arr(psi, complex_dtype=True, use_torch=self.use_torch)
        pre = _norm(psi, self.use_torch)
        report = {"mode": self.mode.value, "pre_norm": pre, "post_norm": pre}
        if self.mode == RailMode.ENFORCE:
            denom = max(self.cfg.eps, pre)
            psi = psi / denom
            report["post_norm"] = _norm(psi, self.use_torch)
        return psi, report

    def hermiticity_residual(self, A) -> float:
        A = _arr(A, complex_dtype=True, use_torch=self.use_torch)
        resid = A - _dagger(A, self.use_torch)
        return _norm(resid, self.use_torch)

    def density_psd_trace1(self, rho):
        rho = _arr(rho, complex_dtype=True, use_torch=self.use_torch)
        rhoH_for_report = _project_hermitian(rho, self.use_torch)
        w, _ = _eigh(rhoH_for_report, self.use_torch)

        if self.use_torch:
            min_eig = float(w.real.min().detach().cpu().item())
            trace_pre = float(_trace(rho, self.use_torch).real.detach().cpu().item())
        else:
            min_eig = float(np.min(w.real))
            trace_pre = float(np.real(_trace(rho, self.use_torch)))

        report = {
            "mode": self.mode.value,
            "hermiticity_residual": self.hermiticity_residual(rho),
            "min_eig_reported_on_hermitian_part": min_eig,
            "trace_pre": trace_pre,
            "corrected": False,
        }

        if self.mode != RailMode.ENFORCE:
            report["trace_post"] = trace_pre
            return rho, report

        rho2 = _psd_clip(rhoH_for_report, self.use_torch, self.cfg.min_eig_clip)
        tr = _trace(rho2, self.use_torch).real

        if self.use_torch:
            rho2 = rho2 / torch.clamp(tr, min=self.cfg.eps)
            if self.cfg.decohere_floor > 0.0:
                n = rho2.shape[-1]
                eye = torch.eye(n, dtype=torch.bool, device=rho2.device)
                small = (rho2.abs() < self.cfg.decohere_floor) & (~eye)
                rho2 = torch.where(small, torch.zeros_like(rho2), rho2)
            trace_post = float(_trace(rho2, self.use_torch).real.detach().cpu().item())
        else:
            rho2 = rho2 / max(float(tr), self.cfg.eps)
            if self.cfg.decohere_floor > 0.0:
                n = rho2.shape[-1]
                offdiag = ~np.eye(n, dtype=bool)
                small = (np.abs(rho2) < self.cfg.decohere_floor) & offdiag
                rho2 = np.where(small, np.zeros_like(rho2), rho2)
            trace_post = float(np.real(_trace(rho2, self.use_torch)))

        report.update({"trace_post": trace_post, "corrected": True})
        return _nan_to_num(rho2, self.use_torch), report

    def minkowski_inner(self, x, y, eta):
        x = _arr(x, complex_dtype=False, use_torch=self.use_torch)
        y = _arr(y, complex_dtype=False, use_torch=self.use_torch)
        eta = _arr(eta, complex_dtype=False, use_torch=self.use_torch)
        return x @ (eta @ y)

    def check_metric_signature(self, eta, expected_neg: int = 1):
        eta = _arr(eta, complex_dtype=False, use_torch=self.use_torch)
        w, _ = _eigh(eta, self.use_torch)
        w_np = w.detach().cpu().numpy() if self.use_torch else w
        neg = int((w_np < -self.cfg.eps).sum())
        pos = int((w_np > self.cfg.eps).sum())
        zero = int((np.abs(w_np) <= self.cfg.eps).sum())
        return {"ok": neg == expected_neg, "neg": neg, "pos": pos, "zero": zero, "eigvals": w_np.tolist()}

    def lorentz_invariance_residual(self, L, eta) -> float:
        L = _arr(L, complex_dtype=False, use_torch=self.use_torch)
        eta = _arr(eta, complex_dtype=False, use_torch=self.use_torch)
        resid = L.T @ eta @ L - eta
        return _norm(resid, self.use_torch)

    def cond_and_route(self, A):
        A = _arr(A, complex_dtype=False, use_torch=self.use_torch)
        if self.use_torch:
            s = torch.linalg.svdvals(A)
            smin = torch.clamp(s.min(), min=self.cfg.eps)
            kappa = float((s.max() / smin).detach().cpu().item())
        else:
            s = np.linalg.svd(A, compute_uv=False)
            kappa = float(s.max() / max(float(s.min()), self.cfg.eps))
        route = "cg_or_cholesky" if kappa < self.cfg.kappa_max else "qr_or_svd"
        return {"kappa": kappa, "route": route}


def demo_report():
    rails = VectorSafetyRails(mode=RailMode.ENFORCE)
    rho = np.array([[0.8, 0.4], [0.2, 0.1]], dtype=np.complex128)
    rho2, report = rails.density_psd_trace1(rho)
    return {
        "density_report": report,
        "rho_corrected": np.asarray(rho2).round(6).tolist(),
        "metric": rails.check_metric_signature(np.diag([-1.0, 1.0, 1.0, 1.0])),
    }
