"""
Experimental TJM/MPS backend notes.

This preserves the purpose of Beepers while refusing to pretend it is stable.

The old Beepers script explored:
- hardened tensor jump method sampling,
- MPS utilities,
- 2-site TDVP,
- exact norm loss from sum <c†c>,
- Poisson-correct jump sampling,
- adaptive timestep,
- streamed observables.

Why it is not the default backend:
- JAX transforms do not like Python list mutation inside @jit.
- vmap over a Python while loop with tqdm and append-heavy trajectory state is brittle.
- a real refactor should represent MPS as pytrees or padded tensor containers.

Use the dense Liouvillian backend first. Return here when the small demo is stable.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict


@dataclass
class TJMStatus:
    name: str = "tjm_mps_experimental"
    status: str = "preserved_not_default"
    default_backend: str = "liouvillian"
    reason: str = "Needs pytree/padded tensor refactor before reliable JAX transforms."
    next_steps: tuple[str, ...] = (
        "Separate pure tensor kernels from Python orchestration.",
        "Represent MPS tensors as a pytree with stable static structure.",
        "Remove tqdm and append loops from transformed functions.",
        "Add tiny n=2 or n=4 tests before scaling to n=30.",
        "Compare against dense Liouvillian or QuTiP for small systems.",
    )


def status_report():
    return asdict(TJMStatus())


def print_status():
    report = status_report()
    for key, value in report.items():
        print(f"{key}: {value}")
