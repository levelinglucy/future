from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np

try:
    import jax
    import jax.numpy as jnp
    from jax import jit, vmap, lax
    from jax.scipy.linalg import expm
    jax.config.update("jax_enable_x64", True)
    HAS_JAX = True
except Exception:
    jax = None
    jnp = None
    jit = None
    vmap = None
    lax = None
    expm = None
    HAS_JAX = False

try:
    import qutip as qt
    HAS_QUTIP = True
except Exception:
    qt = None
    HAS_QUTIP = False


@dataclass
class LiouvillianConfig:
    n: int = 2
    gamma: float = 0.1
    t_end: float = 2.0
    steps: int = 41
    enforce_physical: bool = True
    compare_qutip: bool = False


def require_jax():
    if not HAS_JAX:
        raise RuntimeError("JAX is not installed. Install with: python -m pip install jax jaxlib")


def dagger(A):
    return jnp.conjugate(jnp.swapaxes(A, -1, -2))


def pauli_at(op, idx: int, n: int):
    """Dense operator placing `op` at qubit index `idx`.

    Not jitted, because idx and n are Python-static construction arguments.
    """
    require_jax()
    ops = []
    for i in range(n):
        ops.append(op if i == idx else jnp.eye(op.shape[0], dtype=op.dtype))
    out = ops[0]
    for item in ops[1:]:
        out = jnp.kron(out, item)
    return out


def build_dense_problem(n: int, gamma: float):
    require_jax()
    sz = jnp.array([[1, 0], [0, -1]], dtype=jnp.complex128)
    sm = jnp.array([[0, 1], [0, 0]], dtype=jnp.complex128)

    dim = 2 ** n
    H = jnp.zeros((dim, dim), dtype=jnp.complex128)
    for i in range(n - 1):
        H = H + 0.5 * pauli_at(sz, i, n) @ pauli_at(sz, i + 1, n)

    c_ops = jnp.stack([jnp.sqrt(gamma) * pauli_at(sm, i, n) for i in range(n)])
    z_ops = jnp.stack([pauli_at(sz, i, n) for i in range(n)])
    rho0 = jnp.zeros((dim, dim), dtype=jnp.complex128).at[0, 0].set(1.0)

    return H, c_ops, z_ops, rho0


@jit
def liouvillian(H, c_ops):
    d = H.shape[0]
    I = jnp.eye(d, dtype=jnp.complex128)
    L_H = -1j * (jnp.kron(I, H) - jnp.kron(dagger(H), I))

    def single_dissipator(Lk):
        Lk_dag = dagger(Lk)
        Lk_conj = jnp.conj(Lk)
        return (
            jnp.kron(Lk_conj, Lk)
            - 0.5 * jnp.kron(I, Lk_dag @ Lk)
            - 0.5 * jnp.kron(Lk.T @ Lk_conj, I)
        )

    L_D = jnp.sum(vmap(single_dissipator)(c_ops), axis=0)
    return L_H + L_D


@jit
def enforce_physicality(rho):
    rho_h = (rho + dagger(rho)) / 2
    w, V = jnp.linalg.eigh(rho_h)
    w = jnp.clip(w.real, a_min=0.0)
    rho_phys = (V * w[None, :]) @ dagger(V)
    tr = jnp.trace(rho_phys).real
    return jnp.where(tr > 1e-14, rho_phys / tr, rho_phys)


def propagate_liouvillian(rho0, L, t_list, enforce: bool = True):
    """Constant-step dense Liouvillian propagation.

    Uses one expm for fixed dt. If enforce=True, projects states to Hermitian PSD trace-one.
    """
    require_jax()
    rho_vec = rho0.ravel()
    dt = t_list[1] - t_list[0]
    U_dt = expm(L * dt)

    def scan_body(carry, _):
        next_vec = U_dt @ carry
        next_rho = next_vec.reshape(rho0.shape)
        return next_vec, next_rho

    _, states = lax.scan(scan_body, rho_vec, jnp.arange(len(t_list) - 1))
    states = jnp.concatenate([rho0[None, ...], states], axis=0)
    if enforce:
        states = vmap(enforce_physicality)(states)
    return states


@jit
def jax_expectation(states, ops):
    def per_time_step(rho):
        return vmap(lambda op: jnp.real(jnp.trace(rho @ op)))(ops)
    return vmap(per_time_step)(states)


def solve_qutip_reference(n: int, gamma: float, t_np: np.ndarray):
    if not HAS_QUTIP:
        raise RuntimeError("QuTiP is not installed. Install with: python -m pip install qutip")

    sz = qt.sigmaz()
    sm = qt.sigmam()
    eye = qt.qeye(2)

    def qt_pauli_at(op, idx):
        ops = [eye] * n
        ops[idx] = op
        return qt.tensor(ops)

    H = sum(0.5 * qt_pauli_at(sz, i) * qt_pauli_at(sz, i + 1) for i in range(n - 1))
    c_ops = [np.sqrt(gamma) * qt_pauli_at(sm, i) for i in range(n)]
    rho0 = qt.basis(2 ** n, 0).proj()
    z_ops = [qt_pauli_at(sz, i) for i in range(n)]
    zz_ops = [qt_pauli_at(sz, i) * qt_pauli_at(sz, i + 1) for i in range(n - 1)]
    e_ops = z_ops + zz_ops

    result = qt.mesolve(H, rho0, t_np, c_ops=c_ops, e_ops=e_ops, options={"store_states": True})
    return result


def run_demo(cfg: LiouvillianConfig):
    require_jax()
    t_np = np.linspace(0, cfg.t_end, cfg.steps)
    t_jax = jnp.asarray(t_np)

    H, c_ops, z_ops, rho0 = build_dense_problem(cfg.n, cfg.gamma)
    L = liouvillian(H, c_ops)
    states = propagate_liouvillian(rho0, L, t_jax, enforce=cfg.enforce_physical)
    jax_exps = jax_expectation(states, z_ops)

    report = {
        "backend": "jax_dense_liouvillian",
        "n": cfg.n,
        "gamma": cfg.gamma,
        "steps": cfg.steps,
        "enforce_physical": cfg.enforce_physical,
        "final_trace": float(jnp.trace(states[-1]).real),
        "final_z_expectations": np.asarray(jax_exps[-1]).round(8).tolist(),
        "qutip_compared": False,
    }

    if cfg.compare_qutip and HAS_QUTIP:
        qres = solve_qutip_reference(cfg.n, cfg.gamma, t_np)
        qutip_z = np.array(qres.expect[:cfg.n]).T
        diff = np.max(np.abs(np.asarray(jax_exps) - qutip_z))
        report["qutip_compared"] = True
        report["max_abs_z_diff_vs_qutip"] = float(diff)
    elif cfg.compare_qutip and not HAS_QUTIP:
        report["qutip_warning"] = "QuTiP not installed; skipped comparison."

    return report


def plot_jax_expectations(t_np, jax_exps, save_path=None):
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(10, 6))
    for i in range(jax_exps.shape[1]):
        ax.plot(t_np, jax_exps[:, i], label=f"JAX site {i}")
    ax.set_xlabel("Time")
    ax.set_ylabel("⟨σ_z⟩")
    ax.set_title("JAX dense Liouvillian σ_z expectations")
    ax.grid(True, alpha=0.3)
    ax.legend()
    if save_path:
        fig.savefig(save_path, dpi=200, bbox_inches="tight")
    return fig, ax
