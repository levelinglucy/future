#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from qlab.rails import demo_report
from qlab.liouvillian import LiouvillianConfig, run_demo
from qlab.tjm_mps_experimental import status_report


def cmd_rails(args):
    print(json.dumps(demo_report(), indent=2, ensure_ascii=False))
    return 0


def cmd_liouvillian(args):
    cfg = LiouvillianConfig(
        n=args.n,
        gamma=args.gamma,
        t_end=args.t_end,
        steps=args.steps,
        enforce_physical=not args.raw,
        compare_qutip=args.compare_qutip,
    )
    report = run_demo(cfg)
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0


def cmd_tjm_status(args):
    print(json.dumps(status_report(), indent=2, ensure_ascii=False))
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Quantum Lab: rails, Liouvillian demo, and TJM/MPS experimental notes.")
    sub = parser.add_subparsers(dest="command", required=True)

    rails = sub.add_parser("rails", help="Run a small VectorSafetyRails demo.")
    rails.set_defaults(func=cmd_rails)

    liouv = sub.add_parser("liouvillian", help="Run dense JAX Liouvillian demo.")
    liouv.add_argument("--n", type=int, default=2, help="Number of qubits. Keep small for dense simulation.")
    liouv.add_argument("--gamma", type=float, default=0.1)
    liouv.add_argument("--t-end", type=float, default=2.0)
    liouv.add_argument("--steps", type=int, default=41)
    liouv.add_argument("--raw", action="store_true", help="Disable physicality projection.")
    liouv.add_argument("--compare-qutip", action="store_true", help="Compare against QuTiP if installed.")
    liouv.add_argument("--no-plot", action="store_true", help="Accepted for compatibility; this CLI is headless by default.")
    liouv.set_defaults(func=cmd_liouvillian)

    tjm = sub.add_parser("tjm-status", help="Explain the preserved experimental TJM/MPS backend.")
    tjm.set_defaults(func=cmd_tjm_status)

    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
