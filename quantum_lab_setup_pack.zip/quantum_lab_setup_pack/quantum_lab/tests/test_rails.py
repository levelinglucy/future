import unittest
import numpy as np

from qlab.rails import VectorSafetyRails, RailMode


class TestRails(unittest.TestCase):
    def test_enforce_density_trace_one(self):
        rho = np.array([[0.8, 0.4], [0.2, 0.1]], dtype=np.complex128)
        rails = VectorSafetyRails(mode=RailMode.ENFORCE)
        rho2, report = rails.density_psd_trace1(rho)
        self.assertTrue(report["corrected"])
        self.assertAlmostEqual(float(np.trace(rho2).real), 1.0, places=8)

    def test_advisory_does_not_modify(self):
        rho = np.array([[0.8, 0.4], [0.2, 0.1]], dtype=np.complex128)
        rails = VectorSafetyRails(mode=RailMode.ADVISORY)
        rho2, report = rails.density_psd_trace1(rho)
        self.assertFalse(report["corrected"])
        self.assertTrue(np.allclose(rho, rho2))


if __name__ == "__main__":
    unittest.main()
