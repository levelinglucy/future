import unittest

try:
    from qlab.liouvillian import LiouvillianConfig, run_demo, HAS_JAX
except Exception:
    HAS_JAX = False


@unittest.skipUnless(HAS_JAX, "JAX not installed")
class TestLiouvillian(unittest.TestCase):
    def test_small_demo_runs(self):
        report = run_demo(LiouvillianConfig(n=2, steps=11, t_end=0.5))
        self.assertEqual(report["backend"], "jax_dense_liouvillian")
        self.assertAlmostEqual(report["final_trace"], 1.0, places=6)
        self.assertEqual(len(report["final_z_expectations"]), 2)


if __name__ == "__main__":
    unittest.main()
