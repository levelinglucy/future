# Quantum Lab

A unified, lazy-friendly quantum simulation toolbox assembled from three older repo creatures:

```text
squiggles = vector safety rails
Boop      = dense JAX Liouvillian + QuTiP comparison demo
Beepers   = advanced TJM/MPS experimental prototype
```

This folder turns them into one cleaner tool:

```bash
python quantum_lab.py rails
python quantum_lab.py liouvillian --n 2 --steps 41 --no-plot
python quantum_lab.py tjm-status
```

## What changed?

### 1. Squiggles became `qlab/rails.py`

The old vector safety rails were cleaned into a numerical integrity module.

Main fix:
- `OFF` now avoids corrections.
- `ADVISORY` reports without modifying.
- `ENFORCE` applies Hermitian projection, PSD clipping, trace normalization, and state normalization.

### 2. Boop became `qlab/liouvillian.py`

The old dense JAX + QuTiP demo became the default runnable backend.

Main fix:
- `pauli_at` is no longer incorrectly jitted with dynamic Python args.
- physicality enforcement is optional.
- QuTiP comparison is optional.
- plotting is optional.
- CLI can run headless with `--no-plot`.

### 3. Beepers became `qlab/tjm_mps_experimental.py`

The TJM/MPS idea is preserved but quarantined as experimental.

Reason:
- the old version used JAX transforms around Python lists, list mutation, tqdm loops, and trajectory loops.
- that needs a real pytree/padded-tensor refactor before it should be treated as a reliable backend.

## Install

Core:

```bash
python -m pip install numpy matplotlib tqdm
```

Optional heavy science stack:

```bash
python -m pip install jax jaxlib qutip
```

## Run

```bash
python quantum_lab.py rails
python quantum_lab.py liouvillian --n 2 --steps 41 --no-plot
python quantum_lab.py tjm-status
```

## Tests

```bash
python -m unittest discover tests
```

## Recommended repo placement

```text
future/
  setup_quantum_lab.py
  quantum_lab/
    README.md
    requirements.txt
    quantum_lab.py
    qlab/
      rails.py
      liouvillian.py
      tjm_mps_experimental.py
    tests/
    legacy/
```

## Translation for tired Dylan

`rails` = math seatbelt.  
`liouvillian` = practical quantum demo.  
`tjm-status` = tells you why Beepers is preserved but not default yet.
