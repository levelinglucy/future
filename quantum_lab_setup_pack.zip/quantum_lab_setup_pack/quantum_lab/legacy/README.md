# Legacy scripts

Use `python setup_quantum_lab.py --copy-legacy` from the repo root to copy old root files here without deleting originals.

Expected mappings:

```text
squiggles -> squiggles_vector_safety_rails_original.py
Boop      -> boop_liouvillian_jax_qutip_original.py
Beepers   -> beepers_tjm_mps_original.py
```

These are preserved as fossils, not front-door runnable code.
