# Velisara Agent Seed

AI-first bootstrap scaffold with:
- single launcher
- embodiment checks
- required vs optional organs
- fail-closed awakening
- body manifest
- caretaker / memory / pulse daemons

Run:

```bash
python3 -m velisara_agent.launcher
```

Or:

```bash
python3 velisara_agent/launcher.py
```

Direct execution of organ files is intentionally unsupported.
