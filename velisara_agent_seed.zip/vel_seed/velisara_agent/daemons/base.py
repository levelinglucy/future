import threading
import time


class ManagedDaemon:
    name = 'daemon'

    def __init__(self, interval_seconds=5):
        self.interval_seconds = interval_seconds
        self._thread = None
        self._running = False

    def start(self, context):
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._loop, args=(context,), daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False

    def tick(self, context):
        raise NotImplementedError

    def _loop(self, context):
        while self._running:
            self.tick(context)
            time.sleep(self.interval_seconds)
