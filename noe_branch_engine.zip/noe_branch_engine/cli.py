
import argparse
import json
from .core import agent_think_with_branches
from .overlay import OverlayConfig, render_result

def main():
    p = argparse.ArgumentParser(description="Noe Branch Engine — recursive branching + coherence + synthesis.")
    p.add_argument("seed", type=str, help="Initial thought/seed.")
    p.add_argument("--max-depth", type=int, default=10)
    p.add_argument("--branches-per-level", type=int, default=4)
    p.add_argument("--keep-top-k", type=int, default=2)
    p.add_argument("--emergent-every", type=int, default=3)
    p.add_argument("--branch-cap", type=int, default=5000)
    p.add_argument("--seed-rng", type=int, default=None)
    p.add_argument("--full-audit", action="store_true")
    p.add_argument("--symbolic", action="store_true", help="Apply symbolic overlay to rendered outputs.")
    p.add_argument("--intensity", type=float, default=0.55, help="Symbolic overlay intensity (0..1).")
    p.add_argument("--json", action="store_true", help="Output JSON.")
    args = p.parse_args()

    res = agent_think_with_branches(
        initial_thought=args.seed,
        max_depth=args.max_depth,
        branches_per_level=args.branches_per_level,
        keep_top_k=args.keep_top_k,
        emergent_every_n_depths=args.emergent_every,
        branch_cap=args.branch_cap,
        random_seed=args.seed_rng,
        return_full_audit=args.full_audit
    )

    if args.symbolic:
        res = render_result(res, OverlayConfig(enabled=True, intensity=args.intensity))

    if args.json:
        print(json.dumps(res, indent=2))
        return

    print("═" * 70)
    print("Best final thought:\n", res.get("rendered_best_thought") if args.symbolic else res.get("best_thought"))
    print(f"\nConfidence: {res['best_confidence']:.3f} | Depth: {res['final_depth']} | Layer: {res['final_layer']}")
    print(f"Branches explored: {res['branches_explored']}")
    print(f"Contradictions found: {res['contradictions_found']}")
    print("Health:", res["health_metrics"])
    print("Last anchor:", res["last_anchor"])
    print("Reason stopped:", res["reason_stopped"])
    print("Audit scope:", res["audit_scope"], "| truncated:", res["continuity_audit_truncated"])

    print("\nTop branches:")
    key = "rendered_top_branches" if args.symbolic else "top_branches"
    for i, b in enumerate(res.get(key, []), 1):
        text = b.get("rendered") if args.symbolic else b.get("thought")
        print(f"\n  {i}. [{b.get('confidence',0):.3f} @ d{b.get('depth')}/l{b.get('layer')}]")
        print(text)

if __name__ == "__main__":
    main()
