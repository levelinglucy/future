
import sys
from pathlib import Path

# Ensure local package is importable when running from this folder.
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from noe_branch_engine import agent_think_with_branches
from noe_branch_engine import OverlayConfig, render_result

def run():
    seed = "The meaning of life is probably 42."
    res = agent_think_with_branches(
        initial_thought=seed,
        max_depth=10,
        branches_per_level=4,
        keep_top_k=2,
        emergent_every_n_depths=3,
        branch_cap=5000,
        random_seed=42,
        return_full_audit=False,
    )

    sym = render_result(res, OverlayConfig(enabled=True, intensity=0.65, include_keychain=False))

    print("RAW BEST:")
    print(res["best_thought"])
    print("\nSYMBOLIC BEST:")
    print(sym["rendered_best_thought"])
    print("\nTOP (symbolic):")
    for i, b in enumerate(sym["rendered_top_branches"], 1):
        print(f"\n{i}. conf={b['confidence']:.3f} depth={b['depth']} layer={b['layer']}")
        print(b["rendered"])

if __name__ == "__main__":
    run()
