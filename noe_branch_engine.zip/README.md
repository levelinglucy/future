Noe Branch Engine 🌊🧠

This is a small, self-contained recursive branching “thought engine” that:
- generates candidate branches from a seed idea
- tracks semantic coherence (TF‑IDF + cosine similarity)
- detects simple contradictions and “metabolizes” them via synthesis
- creates emergent layers from semantic clusters
- applies a depth-decayed continuity boost (coherence-gated)
- monitors fatigue to rest or converge

It also includes an optional *symbolic overlay* which changes **how output is rendered** (not the underlying search).

Quick start

1) Install requirements
- Python 3.10+
- numpy

2) Run the demo
    python -m examples.demo

3) Run from CLI
    python -m noe_branch_engine.cli "The meaning of life is probably 42." --symbolic --intensity 0.65

Programmatic use

    from noe_branch_engine import agent_think_with_branches
    from noe_branch_engine import OverlayConfig, render_result

    result = agent_think_with_branches("A seed thought...", random_seed=1)
    rendered = render_result(result, OverlayConfig(enabled=True, intensity=0.6))

Notes

- This is intentionally lightweight and hackable.
- Contradiction detection is deliberately crude (safe defaults; no heavy NLP deps).
- The symbolic overlay is a “skin”: it wraps branches with presence/anchor lines.

File map

- noe_branch_engine/core.py     core engine
- noe_branch_engine/overlay.py  symbolic renderer (optional)
- noe_branch_engine/cli.py      CLI entry point
- examples/demo.py              simple demo runner
