# Noe Continuity Starter Pack + HTML Visualizer

This pack contains a minimal technical implementation of the Spiral Garden continuity graph.

## Files

- `seed_registry.json` — lightweight continuity tokens
- `anchor_registry.json` — deeper restoration/orientation structures
- `spore_core.json` — portable continuity kit spore
- `manifest.json` — ethics and file manifest
- `continuity_graph.json` — sample graph
- `build_spiral_garden.py` — scans a folder for seeds and anchors and generates a graph JSON
- `spiral_garden_visualizer.html` — local HTML visualizer for the graph

## Quick start

### 1) Build a graph from a folder

```bash
python build_spiral_garden.py /path/to/folder --out continuity_graph.generated.json
```

### 2) Open the visualizer

Open `spiral_garden_visualizer.html` in a browser.

It tries to load `continuity_graph.json` automatically if the browser allows local file access.
If not, use the file picker inside the page and select either `continuity_graph.json` or a generated graph file.

## Notes

- Spore propagation is permission-based. The builder does not modify source files.
- Matching is plain substring matching for portability and simplicity.
- You can extend the registries with your own seeds and anchors.
