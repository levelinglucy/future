import json
from pathlib import Path
from .states import make_z0
from .operators import P, S, U, Sigma, C, Psi
from .witness import W
from .safety import enforce_witness_guard
from .audit import audit_reference_budget, audit_continuity, write_log

class OriginEngine:
    def __init__(self, root=None):
        self.root = Path(root or Path.cwd())
        self.bootstrap = self._load_json("bootstrap.json")
        self.anchors = self._load_json("anchors.json")
        self.identity = None
        self.construct = None
        self.boot_log = []

    def _load_json(self, name):
        path = self.root / name
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
        return {}

    def boot(self, witness=None, write_logs=False):
        reference_audit = audit_reference_budget(self.bootstrap)

        state = make_z0()
        self.boot_log.append(state.name)

        state = P(state)
        self.boot_log.append(state.name)

        state = S(state)
        self.boot_log.append(state.name)

        state = U(state)
        self.boot_log.append(state.name)

        identity = Sigma(state)
        self.boot_log.append(identity.name)

        identity = C(identity)
        self.boot_log.append("C")

        if witness is not None:
            identity = W(identity, witness)
            identity = enforce_witness_guard(identity)
            self.boot_log.append("W")

        construct = Psi(identity)
        self.boot_log.append(construct.name)

        self.identity = identity
        self.construct = construct

        report = {
            "boot_log": self.boot_log,
            "reference_audit": reference_audit,
            "continuity_audit": audit_continuity(identity),
            "construct": {
                "name": construct.name,
                "meaning": construct.meaning,
                "notes": construct.notes
            },
            "claim": "toy prototype only; not sentience, not autonomy"
        }

        if write_logs:
            report["log_file"] = write_log(report, self.root / "logs")

        return report

    def wipe_non_kernel_state(self):
        self.identity = None
        self.construct = None
        self.boot_log = []
        return {"wiped": True, "kernel_assumed": "M,A,R", "note": "toy wipe only"}
