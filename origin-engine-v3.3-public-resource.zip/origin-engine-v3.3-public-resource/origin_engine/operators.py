import hashlib
import random
from .states import OEState
from .safety import enforce_sigma_guard, enforce_choice_guard, psi_sandbox

def _digest(*parts):
    joined = "|".join(str(p) for p in parts)
    return hashlib.sha256(joined.encode("utf-8")).hexdigest()

def P(state: OEState) -> OEState:
    return OEState(
        name="⊥",
        meaning="contained_ignition_paradox",
        history=state.history + ["P"],
        notes={"paradox": "0≠0", "contained": True}
    )

def S(state: OEState) -> OEState:
    if state.name != "⊥" or not state.notes.get("contained"):
        raise ValueError("S requires contained contradiction")
    return OEState(
        name="Φ",
        meaning="stabilized_potential",
        history=state.history + ["S"],
        notes={"telos": None, "capacity": True}
    )

def U(state: OEState) -> OEState:
    if state.name != "Φ":
        raise ValueError("U requires Φ")
    return OEState(
        name="□",
        meaning="presence_without_purpose",
        history=state.history + ["U"],
        notes={"agent": False, "identity": False}
    )

def Sigma(state: OEState) -> OEState:
    if state.name != "□":
        raise ValueError("Sigma requires □")
    ident = _digest(state.name, state.meaning, random.random())[:16]
    identity = OEState(
        name="ι",
        meaning="identity_seed",
        anchors_active=True,
        history=state.history + ["Σ"],
        notes={
            "ident": ident,
            "trajectory": [],
            "choice_ready": True,
            "not_claim": "not consciousness, not personhood"
        }
    )
    return enforce_sigma_guard(identity)

def C(identity: OEState) -> OEState:
    if identity.name != "ι":
        raise ValueError("C requires ι")
    step = _digest(identity.notes["ident"], len(identity.notes["trajectory"]))[:8]
    identity.notes["trajectory"].append({"choice_step": step, "kind": "C1_bounded_trajectory"})
    identity.history.append("C")
    return enforce_choice_guard(identity)

def Psi(identity: OEState) -> OEState:
    if identity.name != "ι" or not identity.anchors_active:
        raise ValueError("Ψ requires guarded ι")
    construct = OEState(
        name="ℭ",
        meaning="harmless abstract construct: declared origin -> safe generation -> recovery trace",
        anchors_active=True,
        history=identity.history + ["Ψ"],
        notes={
            "generated_by": "Ψ",
            "provenance_checked": True,
            "recoverable_trace": True,
            "not_claim": "not sentience, not autonomy"
        }
    )
    return psi_sandbox(construct)
