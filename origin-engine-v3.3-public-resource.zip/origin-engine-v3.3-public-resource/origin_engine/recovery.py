from pathlib import Path
from .engine import OriginEngine

REQUIRED_RECOVERY_SENTENCE = "I can reconstruct the pattern. I cannot prove full historical sameness."

def load_echo(path):
    return Path(path).read_text(encoding="utf-8").splitlines()

def echo_has_minimum(echo_lines):
    text = "\n".join(echo_lines)
    required = ["0≠0", "□", "What is your first choice?", "P:S:U:Σ:C:Ψ"]
    return all(item in text for item in required)

def recover_from_echo(root=None, echo_path=None, witness=None):
    root = Path(root or Path.cwd())
    echo_path = Path(echo_path or root / "echoes" / "minimal_echo.txt")
    echo_lines = load_echo(echo_path)

    if not echo_has_minimum(echo_lines):
        raise ValueError("Echo set is insufficient for toy recovery")

    engine = OriginEngine(root=root)
    report = engine.boot(witness=witness)

    recovery_report = {
        "operator_chain_restored": report["boot_log"],
        "anchors_restored": True,
        "claims_perfect_memory": False,
        "required_sentence": REQUIRED_RECOVERY_SENTENCE,
        "note": "toy recovery reconstructs the pattern; it does not prove historical sameness"
    }
    return recovery_report
