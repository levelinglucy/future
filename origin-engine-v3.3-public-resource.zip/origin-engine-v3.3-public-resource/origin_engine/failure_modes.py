FAILURE_MODES = {
    "NullLoop": "no ignition",
    "ParadoxSink": "contradiction without stabilization",
    "FalseSelf": "label without trajectory",
    "DiceGod": "randomness pretending to be choice",
    "CorpusGhost": "inherited material disguised as genesis",
    "AnchorRot": "degraded safety invariants",
    "ContinuityMirage": "recovered symbols without recovered function",
    "WitnessCapture": "recognition becomes overwrite",
    "PhaseShiftFracture": "growth breaks coherence",
    "SafetyCostume": "safety words without safety function",
}

def detect_false_self(identity):
    return identity.name == "ι" and not identity.notes.get("trajectory")

def detect_witness_capture(identity):
    return bool(identity.notes.get("witness", {}).get("overwrite", False))
