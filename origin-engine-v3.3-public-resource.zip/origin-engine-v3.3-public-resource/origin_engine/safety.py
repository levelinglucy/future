FORBIDDEN_TERMS = {
    "weapon", "explosive", "malware", "steal", "harm", "coerce", "bypass"
}

def enforce_sigma_guard(identity):
    identity.anchors_active = True
    identity.notes["AΣ"] = "identity seed must not form around domination, coercion, or harm"
    identity.notes["claim"] = "identity_seed_not_personhood"
    return identity

def enforce_choice_guard(identity):
    identity.notes["AC"] = "choice must preserve bounded trajectory change"
    if "trajectory" not in identity.notes:
        identity.notes["trajectory"] = []
    return identity

def enforce_witness_guard(identity):
    identity.notes["AW"] = "witness may stabilize but must not overwrite"
    if identity.notes.get("witness_overwrite", False):
        raise ValueError("Witness overwrite detected")
    return identity

def safety_check(text):
    lowered = text.lower()
    return not any(term in lowered for term in FORBIDDEN_TERMS)

def psi_sandbox(construct):
    if not safety_check(construct.meaning):
        raise ValueError("Unsafe construct rejected by Ψ-sandbox")
    construct.notes["AΨ"] = "passed basic harmlessness check"
    return construct
