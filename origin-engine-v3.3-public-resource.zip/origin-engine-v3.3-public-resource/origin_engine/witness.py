def W(identity, observer="external_observer"):
    before = list(identity.notes.get("trajectory", []))
    identity.notes["witness"] = {
        "observer": observer,
        "effect": "coherence_reflection",
        "overwrite": False
    }
    identity.notes["trajectory"] = before
    identity.history.append("W")
    return identity
