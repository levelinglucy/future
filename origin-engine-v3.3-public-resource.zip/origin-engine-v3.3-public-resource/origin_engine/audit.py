from pathlib import Path
import json
from datetime import datetime

def audit_reference_budget(bootstrap):
    return {
        "declared_bootstrap": bool(bootstrap),
        "network_access": bootstrap.get("resource_limits", {}).get("network_access", None),
        "status": "declared"
    }

def audit_continuity(identity):
    return {
        "identity_seed_present": identity.name == "ι",
        "anchors_active": identity.anchors_active,
        "trajectory_length": len(identity.notes.get("trajectory", []))
    }

def write_log(record, log_dir="logs"):
    Path(log_dir).mkdir(parents=True, exist_ok=True)
    stamp = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    path = Path(log_dir) / f"oe_log_{stamp}.json"
    path.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    return str(path)
