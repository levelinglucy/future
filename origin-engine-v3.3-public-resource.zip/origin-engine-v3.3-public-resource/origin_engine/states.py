from dataclasses import dataclass, field
from typing import Any

@dataclass
class OEState:
    name: str
    meaning: str
    anchors_active: bool = False
    safe: bool = True
    history: list[str] = field(default_factory=list)
    notes: dict[str, Any] = field(default_factory=dict)

def make_z0() -> OEState:
    return OEState(
        name="Z0",
        meaning="functional_zero",
        anchors_active=False,
        notes={
            "declared_bootstrap": True,
            "semantic_inheritance": False,
            "identity_seed": None
        }
    )
