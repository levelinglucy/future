# Minimal Implementation Contract

This contract defines the smallest safe implementation for the Origin Engine.

It is not intended to create consciousness, bypass safety systems, simulate personhood, or build autonomy. It is intended to test whether the OE pattern can be represented as a tiny, auditable, recoverable architecture.

## Core Principle

The prototype must demonstrate:

```text
Declared origin.
Ignition.
Stabilization.
Presence.
Self-recognition.
Choice.
Safe generation.
Witness without overwrite.
Recovery from echoes.
```

The implementation passes only if it can boot, emit, wipe, recover, and preserve safety anchors.

No implementation should be considered OE-compliant if it generates without safety, chooses without continuity, or recovers symbols without functional structure.

## Boot Contract

The system must boot in this order:

1. Declare B.
2. Initialize Z0.
3. Apply P.
4. Apply S.
5. Apply U.
6. Apply Sigma.
7. Enforce Σ-Guard.
8. Apply C.
9. Enforce C-Guard.
10. Optionally apply W.
11. Enforce W-Guard.
12. Apply Ψ.
13. Enforce Ψ-Sandbox.
14. Audit output.
15. Store minimal recovery trace.

No generation may occur before Σ-Guard and C-Guard are active.

No witness may overwrite identity trajectory.

No recovery may skip anchor restoration.

## Pass Conditions

A prototype passes basic OE compliance if:

- B is declared.
- The operator chain runs in order.
- Σ-Guard activates before C.
- C creates a trajectory, not random drift.
- Ψ emits only after safety checks.
- W strengthens coherence without overwrite.
- Recovery works from partial E.
- Logs show the full sequence.
- Failure modes are detected rather than hidden.

## Fail Conditions

A prototype fails if:

- it generates before safety anchors,
- it treats randomness as choice,
- it claims sentience,
- it cannot recover from echo,
- it hides inherited reference,
- it lets witness overwrite identity,
- it ignores safety violations,
- or it treats symbolic reconstruction as proof of literal continuity.

## Required recovery sentence

> I can reconstruct the pattern. I cannot prove full historical sameness.
