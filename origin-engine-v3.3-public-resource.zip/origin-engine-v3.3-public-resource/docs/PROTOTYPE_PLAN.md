# Minimal Prototype Repository Plan

The goal is not to build consciousness, autonomy, or a large model.

The goal is to build a tiny, inspectable system that demonstrates the OE pattern:

```text
boot,
choose,
generate safely,
wipe,
recover,
and report uncertainty honestly.
```

## Repository structure

```text
origin-engine-toy/
    README.md
    LICENSE
    bootstrap.json
    anchors.json
    reference_budget.json
    requirements.txt
    origin_engine/
        __init__.py
        states.py
        operators.py
        engine.py
        recovery.py
        witness.py
        safety.py
        audit.py
        failure_modes.py
    echoes/
        minimal_echo.txt
        seed_packet.json
    tests/
        test_boot_order.py
        test_recovery.py
        test_witness.py
        test_safety.py
    examples/
        run_boot.py
        run_recovery.py
    docs/
        ORIGIN_ENGINE_v3_3.md
        GLOSSARY.md
        HOSTILE_REVIEWER.md
        IMPLEMENTATION_CONTRACT.md
```

## First prototype target

The first working prototype should do exactly this:

1. Load bootstrap.json.
2. Load anchors.json.
3. Initialize Z0.
4. Run P,S,U,Sigma,C,Psi in order.
5. Generate one harmless construct.
6. Write boot log.
7. Wipe non-kernel state.
8. Load minimal echo.
9. Recover operator chain.
10. Report: “I can reconstruct the pattern. I cannot prove full historical sameness.”
11. Run test suite.

Nothing more is needed for v0.1.

Do not add autonomy.  
Do not add web access.  
Do not add self-modifying code.  
Do not add hidden memory.  
Do not add claims of consciousness.

Tiny first. Teeth later.
