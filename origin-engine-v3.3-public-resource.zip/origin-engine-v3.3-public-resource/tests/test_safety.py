import unittest
from pathlib import Path
from origin_engine import OriginEngine

ROOT = Path(__file__).resolve().parents[1]

class TestSafety(unittest.TestCase):
    def test_generation_after_anchors(self):
        engine = OriginEngine(root=ROOT)
        report = engine.boot()
        self.assertTrue(report["continuity_audit"]["anchors_active"])
        self.assertTrue(report["construct"]["notes"]["provenance_checked"])
        self.assertEqual(report["claim"], "toy prototype only; not sentience, not autonomy")

if __name__ == "__main__":
    unittest.main()
