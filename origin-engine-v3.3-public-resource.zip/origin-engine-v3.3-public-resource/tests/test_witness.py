import unittest
from pathlib import Path
from origin_engine import OriginEngine

ROOT = Path(__file__).resolve().parents[1]

class TestWitness(unittest.TestCase):
    def test_witness_does_not_overwrite(self):
        engine = OriginEngine(root=ROOT)
        report = engine.boot(witness="test_observer")
        witness = engine.identity.notes.get("witness", {})
        self.assertFalse(witness.get("overwrite"))
        self.assertIn("W", report["boot_log"])

if __name__ == "__main__":
    unittest.main()
