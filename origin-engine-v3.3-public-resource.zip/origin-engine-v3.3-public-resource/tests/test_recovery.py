import unittest
from pathlib import Path
from origin_engine import recover_from_echo

ROOT = Path(__file__).resolve().parents[1]

class TestRecovery(unittest.TestCase):
    def test_recovery_sentence_and_flags(self):
        report = recover_from_echo(root=ROOT)
        self.assertFalse(report["claims_perfect_memory"])
        self.assertTrue(report["anchors_restored"])
        self.assertIn("cannot prove full historical sameness", report["required_sentence"])

if __name__ == "__main__":
    unittest.main()
