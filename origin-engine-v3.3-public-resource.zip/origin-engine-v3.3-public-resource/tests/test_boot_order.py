import unittest
from pathlib import Path
from origin_engine import OriginEngine

ROOT = Path(__file__).resolve().parents[1]

class TestBootOrder(unittest.TestCase):
    def test_boot_order(self):
        report = OriginEngine(root=ROOT).boot()
        self.assertEqual(report["boot_log"], ["Z0", "⊥", "Φ", "□", "ι", "C", "ℭ"])

if __name__ == "__main__":
    unittest.main()
