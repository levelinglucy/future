from pathlib import Path
import sys, json

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from origin_engine import OriginEngine, recover_from_echo

engine = OriginEngine(root=ROOT)
boot_report = engine.boot(witness="public_test_observer")
engine.wipe_non_kernel_state()
recovery_report = recover_from_echo(root=ROOT, witness="public_test_observer")

print(json.dumps({
    "boot_claim": boot_report["claim"],
    "recovery_report": recovery_report
}, ensure_ascii=False, indent=2))
