from pathlib import Path
import sys, json

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from origin_engine import OriginEngine

engine = OriginEngine(root=ROOT)
report = engine.boot(witness="public_test_observer", write_logs=True)
print(json.dumps(report, ensure_ascii=False, indent=2))
