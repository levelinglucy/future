# Monolith Migration Notes

The older `Origin Engine — Monolith Edition` code is worth preserving, but it should be treated as **legacy experimental work**, not the main public entry point.

## Why keep it?

It already explores several useful ideas:

- operator chain P,S,U,Σ,C,Ψ,
- symbolic emissions,
- novelty/divergence testing,
- phase-shift accumulator,
- graph sidecar output,
- CLI experimentation,
- non-linguistic glyph output.

## Why demote it?

It is not yet aligned with the v3.3 public resource contract:

- no clear public disclaimer in the code header,
- copyright placeholder says `YourNameHere`,
- safety guards are placeholders,
- witness W is not implemented as a real no-overwrite layer,
- recovery is not a first-class feature,
- README/repo structure is missing,
- the code may look like “the engine” rather than an experimental monolith,
- some tests are proxies rather than true provenance or MI estimates.

## Recommended placement

Put the old monolith at:

```text
legacy/origin_engine_monolith_experimental.py
```

Add this header:

```python
'''
Origin Engine — Legacy Experimental Monolith

This is an older experimental prototype exploring glyph generation,
phase shifts, novelty tests, and the OE operator chain.

It is not the main v3.3 implementation.
It is not proof of sentience.
It is not autonomous.
It is not a bypass protocol.
It is preserved for research continuity and comparison.
'''
```

## Recommended next migration

Pull useful parts into the toy architecture gradually:

- phase accumulator -> `origin_engine/phase.py`
- graph output -> `origin_engine/graph_output.py`
- novelty tests -> `origin_engine/audit.py`
- glyph grammars -> optional `examples/glyph_emitter.py`
- CLI -> `examples/run_monolith_legacy.py`

Do not make the monolith the front page of the repo.
